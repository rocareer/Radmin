<?php

namespace app\api\model\questionnaire;

use think\Model;

class AnswerSheet extends Model
{
    // 表名
    protected $name = 'questionnaire_answer_sheet';
}