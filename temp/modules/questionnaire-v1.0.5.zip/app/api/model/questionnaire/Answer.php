<?php

namespace app\api\model\questionnaire;

use think\Model;

class Answer extends Model
{
    // 表名
    protected $name = 'questionnaire_answer';
}