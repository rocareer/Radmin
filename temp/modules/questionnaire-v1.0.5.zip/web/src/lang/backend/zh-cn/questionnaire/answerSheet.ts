export default {
    id: 'ID',
    title: '标题',
    platform: '平台',
    'platform 0': '网页',
    'platform 1': '公众号',
    'platform 2': '小程序',
    user: '答题者',
    eid: '问卷ID',
    update_time: '修改时间',
    create_time: '创建时间',
    'quick Search Fields': 'ID',
    look: '查阅',
}
