export default {
    id: 'id',
    title: 'title',
    platform: 'platform',
    'platform 0': 'platform 0',
    'platform 1': 'platform 1',
    'platform 2': 'platform 2',
    user: 'user',
    eid: 'eid',
    update_time: 'update_time',
    create_time: 'create_time',
    'quick Search Fields': 'id',
    look: 'look',
}
