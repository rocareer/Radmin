export interface User {
    id: string
    avatar: string
    gender: number
    nickname: string
    motto: string
    birthday: string
    join_time: string
}
