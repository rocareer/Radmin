export default {
    'Official account': 'Official account',
    'Registration in': 'Registration in ',
    Male: 'male',
    Female: 'female',
    Secrecy: 'secrecy',
    Chat: 'chat',
    messageCenter: 'message center',
    'Joined us': 'Joined us',
}
