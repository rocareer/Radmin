export default {
    'Message Center': 'Message Center',
    'All read': 'All read',
    'User nickname fuzzy search': 'User nickname fuzzy search',
    'Message content fuzzy search': 'Message content fuzzy search',
    'Official account': 'Official account',
    'Mark read': 'Mark read',
    'Speak civilly, ask questions sincerely, please enter what you want to send':
        'Speak civilly, ask questions sincerely, please enter what you want to send',
    Send: 'send',
    'Select all': 'select all',
    Delete: 'delete',
    'Batch delete message': 'Batch delete message',
    'Delete message': 'Delete message',
    'Are you sure to delete it?': 'Are you sure to delete it?',
}
