export default {
    'Official account': '官方账号',
    'Registration in': '注册于',
    Male: '男',
    Female: '女',
    Secrecy: '保密',
    Chat: '私信',
    messageCenter: '消息中心',
    'Joined us': '加入了我们',
}
