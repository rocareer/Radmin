export default {
    id: 'id',
    user_id: 'user_id',
    user__username: 'username',
    content: 'content',
    weigh: 'weigh',
    status: 'status',
    'status 0': 'status 0',
    'status 1': 'status 1',
    create_time: 'create_time',
    'quick Search Fields': 'id',
}
