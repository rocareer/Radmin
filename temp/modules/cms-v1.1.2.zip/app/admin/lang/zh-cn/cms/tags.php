<?php
return [
    'name' => '名称'
];