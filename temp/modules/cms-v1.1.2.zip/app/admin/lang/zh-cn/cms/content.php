<?php
return [
    'The model cannot be found' => '模型找不到啦！',
];