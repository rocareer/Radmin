<?php

namespace app\admin\model\cms;

use think\Model;

class Config extends Model
{
    protected $name = 'cms_config';
}