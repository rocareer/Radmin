export default {
    'Account information': 'Account information',
    'Personal data': 'personal data',
    'Filled in': 'Filled in',
    'Not filled in': 'Not filled in',
    Mobile: 'Mobile',
    Email: 'Email',
    'Last login IP': 'Last login IP',
    'Last login': 'Last login',
    'Growth statistics': 'Growth statistics',
}
