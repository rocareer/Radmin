export default {
    title: '欢迎使用 BuildAdmin-WebNuxt！',
}
