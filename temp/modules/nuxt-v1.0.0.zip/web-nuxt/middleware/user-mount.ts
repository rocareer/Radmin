// 通常用于会员中心初始化时接受各种回调或收参跳转等
export default defineNuxtRouteMiddleware(() => {})
