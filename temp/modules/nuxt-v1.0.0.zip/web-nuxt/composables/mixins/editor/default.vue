<template>
    <div class="tips">{{ $t('utils.Please install editor') }}</div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.tips {
    color: var(--el-text-color-placeholder);
}
</style>
