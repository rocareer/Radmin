interface anyObj {
    [key: string]: any
}

interface ApiResponse<T = any> {
    code: number
    data: T
    msg: string
    time: number
}

type Writeable<T> = { -readonly [P in keyof T]: T[P] }

type NavigateType = 'navigateTo' | 'redirectTo' | 'reLaunch' | 'switchTab' | 'navigateBack'
