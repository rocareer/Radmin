import uni from '@dcloudio/vite-plugin-uni'
import type { UserConfig } from 'vite'

// https://vitejs.dev/config/
const viteConfig = (): UserConfig => {
    return {
        plugins: [uni()],
        build: {
            cssCodeSplit: false,
            sourcemap: false,
            chunkSizeWarningLimit: 1500,
        },
    }
}

export default viteConfig
