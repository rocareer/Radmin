<template>
    <view class="content-list">
        <template v-for="(item, idx) in props.contents" :key="idx">
            <!-- 单图布局 -->
            <navigator
                v-if="item.images.length < 3"
                @longpress="onLongpress(item.id)"
                :url="`/pages/info/info?id=${item.id}`"
                class="content-item"
                :class="mode"
            >
                <view class="content-item-box">
                    <view class="content-content">
                        <view class="content-title">{{ item.title }}</view>
                        <view class="content-info">
                            <text v-if="item.cmsChannel" class="content-tag">{{ item.cmsChannel.name }}</text>
                            <template v-for="(tag, tk) in item.cmsTags.name" :key="`tag-${tk}`">
                                <text v-if="!item.cmsChannel || (item.cmsChannel && tag != item.cmsChannel.name)" class="content-tag">{{ tag }}</text>
                            </template>
                        </view>
                    </view>
                    <view class="content-imgs">
                        <image class="content-img" :src="getFirstImage(item.images)" mode="aspectFill"></image>
                    </view>
                </view>
                <slot name="contentItemFooter" :content="item"></slot>
            </navigator>

            <!-- 多图布局 -->
            <navigator v-else @longpress="onLongpress(item.id)" :url="`/pages/info/info?id=${item.id}`" class="content-item" :class="mode">
                <view class="content-item-box content-item-triple">
                    <view class="content-title">{{ item.title }}</view>
                    <view class="content-triple-imgs">
                        <image
                            v-for="(img, ik) in item.images.slice(0, 3)"
                            :key="ik"
                            class="content-triple-img"
                            :src="fullUrl(img)"
                            mode="aspectFill"
                        ></image>
                    </view>
                    <view class="content-info">
                        <text v-if="item.cmsChannel" class="content-tag">{{ item.cmsChannel.name }}</text>
                        <template v-for="(tag, tk) in item.cmsTags.name" :key="`tag-${tk}`">
                            <text v-if="!item.cmsChannel || (item.cmsChannel && tag != item.cmsChannel.name)" class="content-tag">{{ tag }}</text>
                        </template>
                    </view>
                </view>
                <slot name="contentItemFooter" :content="item"></slot>
            </navigator>
        </template>
    </view>
</template>

<script lang="ts" setup>
import { fullUrl, getFirstImage } from '@/utils/common'

interface Props {
    mode?: 'tiled' | 'card' // tiled=平铺card=卡片
    contents: anyObj[]
}

const props = withDefaults(defineProps<Props>(), {
    mode: 'tiled',
    contents: () => {
        return []
    },
})

const emits = defineEmits<{
    (e: 'contentLongpress', id: string): void
}>()

const onLongpress = (id: string) => {
    emits('contentLongpress', id)
}
</script>

<style lang="scss" scoped>
.content-list {
    overflow: hidden;
}
.content-item {
    -webkit-touch-callout: none;
    background-color: $uni-bg-color;
    .content-item-box {
        position: relative;
        display: flex;
        padding: 20rpx;
    }
    .content-item-triple {
        display: block;
        padding: 20rpx;
    }
    &:active {
        background-color: $uni-bg-color-grey;
    }
}

.content-item.card {
    margin: 20rpx;
    border-radius: 16rpx;
}

.content-content {
    position: relative;
    flex: 1;
    margin-right: 20rpx;
}
.content-title {
    font-size: 16px;
    color: $uni-text-color;
    line-height: 22px;
    height: 44px;
    margin-bottom: 20rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    line-clamp: 2;
}
.content-info {
    display: flex;
    align-items: center;
    font-size: 12px;
    color: $uni-text-color-grey;
    flex-wrap: wrap;
}
.content-tag {
    position: relative;
    padding-right: 16rpx;
}
.content-imgs {
    width: 200rpx;
    height: 150rpx;
}
.content-img {
    width: 100%;
    height: 100%;
    border-radius: 8rpx;
}
.content-item-triple .content-title {
    height: auto;
}
.content-triple-imgs {
    display: flex;
    gap: 16rpx;
    margin-bottom: 16rpx;
    .content-triple-img {
        flex: 1;
        height: 160rpx;
        border-radius: 8rpx;
    }
}
</style>
