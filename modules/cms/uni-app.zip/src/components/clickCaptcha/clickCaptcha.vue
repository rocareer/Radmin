<template>
    <view>
        <view
            v-if="model"
            class="ba-click-captcha"
            :style="{
                top: `calc(50% - ${(state.captcha.height + 100) / 2}px)`,
                left: `calc(50% - ${state.captcha.width / 2}px)`,
            }"
        >
            <view
                class="loading"
                v-if="state.loading"
                :style="{
                    width: `${state.captcha.width}px`,
                    lineHeight: `${state.captcha.height}px`,
                }"
            >
                加载中...
            </view>

            <view v-else class="captcha-img-box">
                <image
                    class="captcha-img"
                    @click.prevent="onRecord($event)"
                    :src="state.captcha.base64"
                    alt="验证码加载失败，请点击刷新按钮"
                    :style="{
                        width: `${state.captcha.width}px`,
                        height: `${state.captcha.height}px`,
                    }"
                />
                <text
                    v-for="(item, index) in state.xy"
                    :key="index"
                    class="step"
                    @click="onCancelRecord(index)"
                    :style="`left:${parseFloat(item.split(',')[0]) - 13}px;top:${parseFloat(item.split(',')[1]) - 13}px`"
                >
                    {{ index + 1 }}
                </text>
            </view>

            <view class="captcha-prompt">
                <template v-if="state.tip">{{ state.tip }}</template>
                <template v-else-if="!state.loading">
                    <text>请依次点击</text>
                    <text
                        v-for="(text, index) in state.captcha.text"
                        :key="index"
                        class="clicaptcha-prompt-text"
                        :class="state.xy.length > index ? 'clicaptcha-prompt-clicked' : ''"
                    >
                        {{ text }}
                    </text>
                </template>
            </view>

            <view class="captcha-refresh-box">
                <view class="captcha-refresh-line captcha-refresh-line-l"></view>
                <uni-icons class="captcha-refresh-btn" type="refresh-filled" size="32" color="#909399" @click="load"></uni-icons>
                <view class="captcha-refresh-line captcha-refresh-line-r"></view>
            </view>
        </view>

        <!-- 遮罩层和关闭按钮 -->
        <view v-if="model" class="other">
            <view class="shade"></view>
            <uni-icons class="close-icon" type="closeempty" size="24" color="#fff" @click="onClose"></uni-icons>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { checkClickCaptcha, getCaptchaData } from '@/api/common'
import { getCurrentInstance, reactive, watch } from 'vue'

interface Props {
    uuid: string
    callback?: (captchaInfo: string) => void
    unset?: boolean
    error?: string
    success?: string
}

const model = defineModel()
const instance = getCurrentInstance()
const props = withDefaults(defineProps<Props>(), {
    uuid: '',
    callback: () => {},
    unset: false,
    error: '未点中正确区域，请重试！',
    success: '验证成功！',
})

const state: {
    loading: boolean
    xy: string[]
    tip: string
    captcha: {
        id: string
        text: string
        base64: string
        width: number
        height: number
    }
} = reactive({
    loading: true,
    xy: [],
    tip: '',
    captcha: {
        id: '',
        text: '',
        base64: '',
        width: 350,
        height: 200,
    },
})

const onRecord = (event: TouchEvent) => {
    if (state.xy.length >= state.captcha.text.length) return

    uni.createSelectorQuery()
        .in(instance?.proxy)
        .select('.captcha-img')
        .boundingClientRect((data: UniApp.NodeInfo | UniApp.NodeInfo[]) => {
            const nodeInfo = data as UniApp.NodeInfo
            if (!nodeInfo || nodeInfo.top === undefined || nodeInfo.left === undefined) {
                uni.showToast({
                    title: '找不到验证码图片节点！',
                    icon: 'none',
                })
                return
            }

            state.xy.push(`${event.touches[0].pageX - nodeInfo.left},${event.touches[0].pageY - nodeInfo.top}`)
            if (state.xy.length == state.captcha.text.length) {
                const captchaInfo = [state.xy.join('-'), state.captcha.width, state.captcha.height].join(';')
                checkClickCaptcha(props.uuid, captchaInfo, props.unset)
                    .then(() => {
                        state.tip = props.success
                        setTimeout(() => {
                            props.callback?.(captchaInfo)
                            onClose()
                        }, 1500)
                    })
                    .catch(() => {
                        state.tip = props.error
                        setTimeout(() => {
                            load()
                        }, 1500)
                    })
            }
        })
        .exec()
}

const onCancelRecord = (index: number) => {
    state.xy.splice(index, 1)
}

const onClose = () => {
    model.value = false
}

const load = () => {
    state.loading = true
    getCaptchaData(props.uuid)
        .then((res) => {
            state.xy = []
            state.tip = ''
            state.loading = false
            state.captcha = res.data
        })
        .catch(() => {
            onClose()
        })
}

watch(
    () => model.value,
    (newVal) => {
        if (newVal) load()
    }
)
</script>

<style lang="scss" scoped>
.other {
    .shade {
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 100vw;
        background-color: $uni-bg-color-mask;
        z-index: 990;
    }
    .close-icon {
        position: absolute;
        bottom: 30px;
        left: calc(50% - 12px);
        z-index: 992;
    }
}
.ba-click-captcha {
    background-color: $uni-bg-color;
    position: fixed;
    z-index: 991;
    box-shadow:
        0 0 0 1px hsla(0, 0%, 100%, 0.3) inset,
        0 0.5em 1em rgba(0, 0, 0, 0.6);

    .loading {
        color: #909399;
        text-align: center;
    }
    .captcha-img-box {
        position: relative;
        .captcha-img {
            display: block;
            border: none;
        }
        .step {
            box-sizing: border-box;
            position: absolute;
            width: 20px;
            height: 20px;
            line-height: 20px;
            font-size: 13px;
            font-weight: bold;
            text-align: center;
            color: $uni-text-color-inverse;
            border: 1px solid $uni-border-color;
            background-color: $uni-color-primary;
            border-radius: 30px;
            box-shadow: 0 0 10px $uni-bg-color;
            user-select: none;
            cursor: pointer;
        }
    }
    .captcha-prompt {
        height: 40px;
        line-height: 40px;
        font-size: 14px;
        text-align: center;
        color: $uni-text-color-grey;
        .clicaptcha-prompt-text {
            margin-left: 10px;
            font-size: 16px;
            font-weight: bold;
            color: $uni-color-error;
            &.clicaptcha-prompt-clicked {
                color: $uni-color-primary;
            }
        }
    }
    .captcha-refresh-box {
        position: relative;
        margin-bottom: 10px;
        .captcha-refresh-line {
            position: absolute;
            top: 16px;
            width: 140px;
            height: 1px;
            background-color: $uni-text-color-grey;
        }
        .captcha-refresh-line-l {
            left: 5px;
        }
        .captcha-refresh-line-r {
            right: 5px;
        }
        .captcha-refresh-btn {
            cursor: pointer;
            display: block;
            margin: 0 auto;
            width: 32px;
            height: 32px;
            font-size: 32px;
            color: #909399;
        }
    }
}
</style>
