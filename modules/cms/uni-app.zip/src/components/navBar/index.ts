import { getStatusBarHeight } from '@/utils/common'

export interface Props {
    boxShadow?: string | boolean
    backBtn?: boolean
    searchInputKeywords?: string
    handleSearch?: (...args: any[]) => any
}

/**
 * 顶部导航栏高度（不含状态栏的、它是一个固定值）
 */
export const navBarNetHeight = 44

/**
 * 获取顶部导航栏高度（含状态栏）
 */
export const getNavBarHeight = () => {
    return (getStatusBarHeight() ?? 0) + navBarNetHeight
}
