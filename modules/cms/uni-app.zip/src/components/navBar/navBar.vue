<template>
    <view>
        <view class="nav-bar-fixed-placeholder" :style="{ height: `${getStatusBarHeight()! + navBarNetHeight}px` }"></view>

        <view
            class="nav-bar"
            :style="{
                boxShadow: props.boxShadow ? (typeof boxShadow === 'string' ? boxShadow : '0 2px 4px rgba(0, 0, 0, 0.1)') : 'none',
            }"
        >
            <!-- 状态栏 -->
            <view class="status-bar" :style="{ height: `${getStatusBarHeight()}px` }"></view>

            <!-- 顶部导航栏 -->
            <view class="header" :style="{ height: `${navBarNetHeight}px` }">
                <!-- 返回按钮 -->
                <view
                    v-if="props.backBtn"
                    class="back-btn"
                    :style="{
                        height: `${menuButtonHeight}px`,
                        width: `${backBtnWidth}px`,
                        top: `${menuButtonTop}px`,
                    }"
                    @click="onBack"
                >
                    <uni-icons class="back-icon" type="back" size="24" color="#000"></uni-icons>
                </view>

                <!-- 搜索框 -->
                <view
                    class="search-box"
                    :style="{
                        height: `${menuButtonHeight}px`,
                        width: `${searchBoxWidth - (backBtn ? backBtnWidth : 0)}px`,
                        marginLeft: `${backBtn ? backBtnWidth : menuMargin}px`,
                        top: `${menuButtonTop}px`,
                    }"
                >
                    <uni-icons class="search-icon" type="search" size="16" color="#999"></uni-icons>
                    <input
                        v-model="state.keywords"
                        class="search-input"
                        type="text"
                        placeholder="搜索其实很简单..."
                        placeholder-style="color: #999;"
                        confirm-type="search"
                        @confirm="onSearch"
                    />
                </view>
            </view>
        </view>
    </view>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
import { getStatusBarHeight, getWindowWidth } from '@/utils/common'
import { navBarNetHeight, type Props } from './index'

const props = withDefaults(defineProps<Props>(), {
    boxShadow: true,
    backBtn: false,
    searchInputKeywords: '',
    handleSearch: () => {},
})

const state = reactive({
    keywords: props.searchInputKeywords,
})

const windowWidth = getWindowWidth()

let menuMargin = 7
let menuButtonHeight = 32
let searchBoxWidth = windowWidth - menuMargin * 2
let menuButtonTop = (navBarNetHeight - menuButtonHeight) / 2 + getStatusBarHeight()!
const backBtnWidth = 42

// #ifndef APP-PLUS	|| WEB || MP-LARK || MP-HARMONY
const menuButtonInfo = uni.getMenuButtonBoundingClientRect()
menuMargin = windowWidth - menuButtonInfo.right
menuButtonHeight = menuButtonInfo.height
searchBoxWidth = menuButtonInfo.left - menuMargin * 2
menuButtonTop = menuButtonInfo.top
// #endif

// #ifdef MP
if (props.backBtn) {
    searchBoxWidth = searchBoxWidth + menuMargin
}
// #endif

const onBack = () => {
    if (getCurrentPages().length === 1) {
        uni.switchTab({
            url: '/pages/index/index',
        })
    } else {
        uni.navigateBack()
    }
}

const onSearch = () => {
    if (props.handleSearch(state.keywords) === false) {
        return
    }

    if (state.keywords) {
        uni.navigateTo({
            url: '/pages/filter/filter?keywords=' + state.keywords,
        })
    }
}
</script>

<style lang="scss" scoped>
.nav-bar-fixed-placeholder {
    display: block;
    width: 100%;

    /*  #ifdef  H5  */
    border-bottom: 1rpx solid transparent;
    /*  #endif  */
}

.nav-bar {
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 999;

    /*  #ifdef  H5  */
    background-color: $uni-bg-color;
    border-bottom: 1rpx solid $uni-bg-color-grey;
    /*  #endif  */

    /*  #ifndef  H5  */
    background-size: cover;
    background-position: center;
    background-image: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAcFBQYFBAcGBQYIBwcIChELCgkJChUPEAwRGBUaGRgVGBcbHichGx0lHRcYIi4iJSgpKywrGiAvMy8qMicqKyr/2wBDAQcICAoJChQLCxQqHBgcKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKir/wgARCADIBEADAREAAhEBAxEB/8QAGwABAQEBAQEBAQAAAAAAAAAAAAECAwQFBwb/xAAaAQEBAQEBAQEAAAAAAAAAAAAAAQIDBgUE/9oADAMBAAIQAxAAAAD96/X82ggSaQlRmURWSBBVBIUGpBYVYjWpa0NKzRtUalsAFq2Ck01CkhVjIqxpShNVYhdBBFKSggAIVYVJQElAFoBNUBaC5FoINAyAACAXQAICVCEBNMkrGmahKlZZmrEhLJWVHpz8+AyVJrORZCEqBJYgAAUpSwl1IBVLqUtW5GtFlsopZDQoEtaABQKSKaaAKgACqABCgEJbZFhIFqDJVNamgAXUqAKIooAFRAUAAAEJUIQDTJmoZszWbRKztCESUIdJ80QWRZcwlmQKiLBAAI0KRSiNRYFC1bKa0M2rZRqWwBpQCooAIVapRZS0FUCRVCgAAAQqJYIQ0RKsSzdaFBVuaBYqkqwAFESggKAAEJUIQaDJkmmSVmoSlZ0hElQFfNEJRjJLJQlgJCUKICrALYpSliyWUVqrVstKXNhpqwilWwAWkKkUWCmqACzRaAAAAAACAAlJRQVLNmhQaVmopRLbKSUCgEFSFAADJayCEFSoZJpklSoSBNMkrOqBnXy4RmWQVEEqEsBMgoS6MhqWgqoqalpYRWqtaslKpaM2yimoqoUKFEEUS0LVASlqgCgAEUgFBCBogiaBVTVaFC6zUClWxQACkAArIAICVAQEJoiVlZqQlQhCWrMktlSS28OnyY0uc2RFsEktmoQRBC5l0DNoSlirSlguoqalSlq6g1Vq3IFGoFC0i2ApFLKBVSma0AaAACQq6IABCqWMkA1NCtJqlLLZUUoNSigAAgArIBAQlCALEmgyRVSyEqAxaICEFePv8vLKpc8bONnGznqcrnFgAp1Omb1l7S9ctW0uVSrTUUNWSmstBU1V1NClKrNKQtLLQRaCwKtgAIoaIKohQApYAAAFJAUspdTRS00tzbFAl0UFIAIEoDNAQhBUACzUEMglolRJUWVCUIQh8r9Px/NqebWfPqc6zcxJpWSFBKCqLm9T04365fTlqVJVqWNLRLqNRQtWy1UVK1ZSpaoFlpK1BUUFWwAAALNKgigKAAIAFUgCrqDVEum7mjUUCNLQUQFQEBDNUhAQlUhArUiS2AS5oKyi2VDNCUgfxH0fhLIRJUQRFkCClgVatTSUsvfG/oY16c3UaBostWxY0US1UuiwC0q1qtMgUahaixaSigogAGoAUBSBKKSoALQiyVqwapZa3VuWoGiRpaCgQJQgMkqkIQEoQDSBM2gSUShKlCAzUopP4P6fwBKiSokoRlQqRUWNLU0VdZDUmpr0y/S577y0uWguiwjUVaWWyiqUWNFbZtANQDVUFFkKBYCpBrTMapkoALKM6EUlhVsgs1SzVLLVrVzdCKF1FKIAVAQGahTJABUINIgWwgIsAIogIKLmifnn1/PBWbBEBJUqwRVLFilWyblsajoDedfQxv3c9aq5a0ubTUJaakpVLZRYLqC1pLYFBZdKUpQAgCtIAICgAATQAFRSxWklm9Kk0Vqt6yRQuoFKACAgM1KsZIQUJoiWKBYQigQBRCAGSrD83+15yVBUshEE0qAWSltZaLGjWWo3LTZqNtennr6fPXRqpcqaKtixYGqsFS2WxStGqXNLQtgtSqAgFKAI0RVlEKQChQCAstirSzdlsVKtaudaLBbFANEABDIqEBkFrJNQBQLCLAAQBRCABR+X/c83KCySkmkKlACCrpmmsqbmtRrLa6NRs1HfG/q89dZq5zdauWirYokpVFl1Kl0JqtEq0ZtE0KCqhYgtJbmtRFharSQQSTTU1CAA0Jaalqmrm0smlLW7lqLakstAAABmoDJTIFDOooAFBckKAQigCFIo/Kfu+amkIWIBZQDQKUsK2zrKmzeNaja2Nmyy9sa+vy10a0XKmirYJYpVRqK0VLpqyCtUZpoEoVC1ACigoAAAgK0AAjQmqVausi6iwXTdVlY0JRQCghLIohCAgqDUUAtCBFgAAM2oAEtR+S/f8zkgoBVBSwJGgbNJczS6NS7N5aNS7jRuKvoxr63Le10zStayol1IWlRFXUqUumi1UVUWmaGjNaMqsWFFkLSVKQCAasSyFWGtY0NTWkRbu5US6WzWlZtLAstAFCmQkUQEIBTSIoBaAgFyAASgUFgj8g9B5mEoQoSkWlBY1FKU2aN5U1G43Go3Lo0bjS+rnr6nPWjRTTTLUURSlLKVLoTWlNWAKrNADVALCFACgAQAIBUNXO9RZqlitagtWxYrVauFKCgBQBEigQgFCWKUCqAQCjJoysAAtCDX436HysqEKCgpSxWjNKbLnVNly0dI1GzUbjcU0u42e7lv6GNaaqaUms3UpBYojSl0JUtKoLZopQAWAiAVZYgtWAAFAAXWbWrFW5aU1oTVkpZa1qaQilAChUgUhAQUGkQKKAABFFAWALTIDQ/FvR+UlUAogqNGooNA1GizWzWW42U3GosdI0U2u5NzX0+e/ZjdKly0tEUpYLYFCo0BKaLVi0KiKAsEBVAKlBAVQFgVrWdagWXS0pZtFlGizVVm2WpQoEEKhABQmhAooAABYChQAUQplofinpPJhUWliiKUsU0tLFNTWop0y1prN1majZuNLosbNmo6Zv1uXX0S0pS5agCliwWgBQLLQsWrCRVEWVVkKKQWUKiiwANLYRbdZupoVrUI01Zqgsaki1q41QoApACACxpAKKAAAC0kUBQCwFahD8S9N5OF0sWzSDctjUFKysF0WNTWmd51o6S2Ta2NyaXRY0dCmo7c9fY576NUpcKUFLAsooAUIC2KBFBTRIBbCwCgKLRALZdRYZulrW0N6yLTUtlLS5LK1cbstIWAoQAU1BABRQACgIoACsqFVJqkB+Ieq8hrSpS2VbGjUu41HSa1LZZCMTck2uhl0l1GzUqNybKaNlNRo9PLX1efTdtLlRFKWBVCKARRAsCwoIoKajK0oQoChSIKNNWWxqC6b0zrO0laq2Lm1rUQqWWzVzsUUEKAIpUAoFABRQIAYCqBVgFJoD8Q9h43UCkLNWtxqNxuNL0xrcu43m7gvPOuZoubo3Gosuipo0aimjRrN9XPf08a3bckUpSiKpCgCLAAsUSkBbAsQCrAQArQRSxVs1osuoNaK1rKylq2XUtlsUNIrVkWlqMlBVJQABQAUCwALlIFC0LQQNAfh3r/ABumiFrNasbNRuNy7XeL1jUvWNZu295ajkvGBuEuyxqBsqaKaLm6PZjX0eXTYigpYoBVJFiwAVFEIFEBBULBYUgWgBpGyqmtGoS6WzdTWbqBpqrZbLVFmkagyuzWpAFIUAAUAAtgAUZIFAKtUAsUD8N9f42gpWqWNRs3G5embuXrG863L0jbXTLWXSWxwXlFKupBSlk0WqXN2U9PPX0+e9S0ApRAW2IRVRBCUKYlWxGqzCwE1asgFTVBYpIq7C6VFjUamq3SmstTRdS6EqtZ2LCotECqgKFC0AAoEVWVIIFBQVRVgaEB+Gew8aKWNNUsbjZ0jcvTN6Zu46zW5dzXTLcbl3HTNsRfMZqRS5XRmaNDU1m0Gj0Y19LlvpKBSiAthCkBCGbCiaRRAM2EWaFhzsykXK01JZdr0l6S6lq2XUU1NaXU1QazdQa0XNVZrTQSkAsGkBRQKUoBRFCzClAKUAqgoAjQ/8QAIhABAAICAgMAAwEBAAAAAAAAAQARAhASIAMEMAUTQBQV/9oACAEBAAECAO1y5d2oy7uXcOxo6GzZ1qVXQ2fA+fLT9j70HW+9Vt6JKlxbtZa3LvXLtcHqbIME1i7uXd3LuzR8ru7dmzbu5UOpDodK+7t7PWu3K75XLizla3L7DYjsdjBg2bHu6qXDpd33uVUt+FGjYdKr+C49Xo9aiJqo6u7W1u7vlfS9CNjZs6XLNEsYS73dw2O7v7Xd9CVs0dCV2r42sV7MYypSap1Uq1vld3cuXa8ru71ZBsbG4PS9Xog3d3d3cGxh1Jeru7tZd/Abho0dK7V1el6tZcd2x6pKSpUvlyW+XK+S3yuXLu4MGCNwSG7JcNDLG9GrvRL0N3/SbGGjrX8V9q0jt6Vq75OWXs5fksvyz+VfyT7n+r/R/pPbx97H8jj+Sw9syuWI2IjBGXORLGx1euXKXDpZ1G7GX8ru+h0IdDYbqq738b3UpOqarP2vJ+Uz/JZ+e7u+XLly58h5WOHm8X5Hxe2I8oI2Njex2N30JY9SDfY1er7Ld3d2IkuENGjZ810Rly+jq9sI7SqZVVyvly5c+V8r5cr5chseQj4fb8PvDobgjBGxEdch0MGEu75avV3d3eyXd3fxIbIQlwYaNV8HTCPyTT0TrWuXLly5crvly5XfKxERGCPg9vwe0IjYiJDKWQ1d2Mu5d9zd9rvrd3d3BNDcIaGGjR83T93s6qt8nLlfLlyu+XLlyMrHkZCIiI45+v7wiJLESDq5dw1Y7Gztd3DV3d3d/MSGiWaNGjRoe7u+r8qSVp3UJbly5cuXLlyuzLkPIy5CJkIjiiPr+3h5BEYNjLuDCWS5Z0JcvpfW7vV6uX0NiMIbETR0NXu9383q9nVacufPlyvly5Xyu+XIyEREcURER9f2PF5hE2Js2QhutGiGz4Xs+xoho0QhCHQ7Xb/KFdK6cnLly5cuXLlyMr5DLERMhHFEREfB5/F5RESEuXLg46Op2u7u7lry73u9mjYmhhDR8Ll9yP0OiQ0dLXlyMuRly5Xd2JkIiIjiiIiIj63n8fkERETZo2JDqaO63pdXLu9WdCWQhCENmiXo7rpl9CMfnXxqrXldjyG9XdiaEyEcUcURERH1PZxSDCWTGWQYOzRL0dnd6u7u7vd6HRCXCWSyXBh8r6n3DtWiXyljBsbG7scXGYuLi4pBIIiQRJ6PsEIJCEGGjpY3eyXLu7u7u5d2N3fJdiAyyGxGCaNXLu7u+j/Bd7qut3LHlyuxEauglkqBjBxSCQREcX0/ZhBIaNEO43fIb5Xy5crl3y5Xd3d3d3dwbmMs0MIMsRuWS7u/5arvW7lyyGq0OLRCYwMHBwgkHFIQhCEJhl6/nIaNGjRDV9ruWOjdrrlLu+xlBxeQiOyXu9GV3dy7v+GpVdKgSpc4mJgYfrPCeD9B4eIVQEAKJiExmMAhCEITwebxZmjRo0Q73LvXK7u73y6ctXd3BIIiN3cGx2JB6Wsv+U+JiYBoRIOLi4pOH6H1v0hiYzCAQSXjAACEIT1vYwyIdDRDpd3u1l8uV3d6vrfLkN2JogwRhL73q7u+t/E+JKDjVVXEbHeMJjCYwmMJiYmOL4MvVfGGJiY4mAAAExhCEJ6vs4pohLh8LIur5au+S3ay75cuV2IwRERGCMsbGGzV2P8AEaOx8+RLITGYzGYwmMxMQMYGI4Zeq44BMDFEgAAENE9T2sUhs1fVSXFu5d3FuDd3L3diJCCMESGiEIdB/jCMDqdCV1o2aIQmMxmJiYmJiBiGOJiA+PP1eAEAKCiEIaJ63tYZGjQy7u5dy5dy75Ld8pfK7u7l6sYI3iiSxg2N3Zq7u7u7u5d9ztWgrVdbNCQhMQmJiYgYmJiYgYmJiAGfgz9dMDGVRshohPB7Pi8uq631uXd6u75XpyfP/u/6H/QPyB7572Pt4ebFgkERG4JBG931PgQ2aPgdKO//xAA6EAABAgMFBgMHAgUFAAAAAAABABECITEDIDBBYRBAUFGBkRIycSJCobHB0fBS4RMjQ2KSBFNggtL/2gAIAQEAAz8AxX4cb+u/nCPADdHBgghsCCCF0IYmqGyW0XApcSldlhS2HBCG5i8Lw3IbQg2MeFHacWWEENgwxtkghdHO4OPDaMCW8hC4ELo2hAIbBhhBBBBC4NgQKCF4XAgggghu53GW0YUsWV7W5LY+MN+biUt/12AKyg80YCsIXYxRHkAh7tmepVqfLCAv9QfeAVua2pVsa2kXdWv+5F3VqP6hVuP6hVuPedR+/ACrM+aEwqyj8sY6oGm5DaNwfdRv0tzlh2VmPajAVmH8EPiOslbxUPhVpH5oydrX3267I7OcERCjDC0Hi1CsrSkTHkUOBNwGZ4JLEfNHM4GuEUytLL3nGqs7RgfZOqGU8Mop9yOM27vslxbVHCKjspGY5FWdsPZPqDuJ3k7icCXCAhh67iQXhLEUKdoLXugQ4L3RebEOAUUdh3ovust7OAee5xWR8MReHXJC0hEUJcHcTgG+MHX/AIHPFGPFYxOJhC1hEUBcHCPE57xLFG4BDaENxisY3ExmELWARQlwd6OA2KcSXCWxCjr32HJ+6iHPoUc/Eeq5v2Cy8XxIXr0IKIq49ZI8k9JjTFNjH/aahQ2kAihLjGlug2NjDDHAThi5I3dNjV+RQ07sjSZ7FDkB6wpj7L/9S6D5fEJpxFtYvuFLMBDENjExnAUCAQa4QwRgjcBtkhslhjhjDBFJIZH4lHmehBWjeoTZ9iyJqP8AII5OfSYU5D/Eog/avZE0+Ej2RBYZVAkeyd+YzCk74RH8uI+hO4BDAFwIbAn2vsF1xihkLsuC6Y4R1KLTB7BNp6EhE1c9imMm6FkR5mHqG+SNT3KBAemswnH1qEJEimZ/9IvoZB6qsnPxF43CCCKia/iQ+CPzDbLbK4wvyw33TO8OGNjaI6o8u4TZB9HCNAejgpq92ZE8z2KI8rv/AGlHxV7SKLyExykUSZV7FEH2Q/pI9lEXcfbsnHyeh9EC5eVCTN02RGbZYJgIihLEIWsD0N6VyWKOEjgRwNEUea1Wq1+C1HZRZMo2oehRGR6hEU7Asjn3IZSrSrzCDSp3CDcxkTMINIS7hAijjIxU7ouCSXy8Ve6PrmSR8x9Ua9AealpqJfssxnPmCjcncNjaAhC0gEUJcHiA3Rt80vPmhsGAdkMVYQeigyeH0KPun5gqIOSCGzDFMXEzzhqiS/ifn4ZFEGXUw/ZCZLM9RMI6g5F3HQouXp6fMfVMZieRBn+6MVRJ6VBUqmj7C182MTGcJQihBhLg70cMC9K8ylsljvwqWAFBHMwh+Ykv0zA/VUIgtECGPvV7qbAkxasIlIlnyJb5hUqOvyP0Rbryl15eqID1lMGZI+qBAqJSIQatNKlNgfwYhBF5TL0TwggyO/Pv0+NiLzB9Cg38sADlkjDF7YPiFCKgfVEgkRfBx1GSIPtAuaEGZ+/onzkTIGQf6FSIq1Xr1+6zoc3n+DVESn+fPBNm0MflKBDihwm3U4TYpuHgQ3yGIMQD6ogvDNs6FeFxFIPMGn7eqAczEmesvqFDlIgVE5fZNoKyn1GmiGUnaWSOAyNkRDGfFCfghFD4oZg3X2FFHeTelcN84RuFFFHYOJiOtRQiqNmRKT/jIgOzjsx+nqi7/tP8zRhkaVUnp8fwYRsTzhUNrD4oTvoGaghrGFZCXidWeUJUGUJPVQ/oKg/Se6gzBCsj7zHUKCKkQK5cAO9f/8QAHhEBAAEFAQEBAQAAAAAAAAAAEQEAECAwQFASAmD/2gAIAQIBAQIAOs4yg7ADWHVF2o2GZ78dC4LhHBGUXA2BiWNRoVV2BxzmuS3LHI4LgXDANRpAoqfLnwoxjRGZuDjLBQAag4ijxTYrkHgB1BxzU8EZx0gfPyfPz8h8/J8hmFFwzDSYB3TzxpLun5+Y/Mfk1hP5n8/JMcIdABkFg0TsDGMI5wADAAxmJiYLFy4BRwBynjmpXEAAAC4WD5mNoeGBpnfHUtlUADIAAsFT+QwCjWWNj6hyFwXAMZowJ/MxrLz0AAHjR0AG+YMpg3H8oYmIGicZqYxmpiY6ALhoD2gCwWDTMbZg3mJrCjQGbuAOg8Qn8/yUYRyG4u6pg3hsAMA3mBMdTZp1AGQcZMcYBqDiLTvjxCjoJiYweULGQFBd4FbnIusoD5+QMp0TomJjwgoMS5jOc5R1KuAAYlFp45icHwjhLM6SixqdxRwO+YKnkLFjgNBYqYoAoDxDumJjlO+fUne5rebT+ZjhDUAcc4TY8YCzU3nc6ypicXoA+fkAMjinqMf/xAAUEQEAAAAAAAAAAAAAAAAAAACw/9oACAECAQM/AFSP/8QAHBEBAQACAwEBAAAAAAAAAAAAEQEgMAAQQFAS/9oACAEDAQECAND4nYyqq9LyYTtfGukNQB5DRPPcGVfPPa4T6VzXwvgVVXqVcVVVV48XCcnzwwfbMTyM9U+4ZLx4vbkvke5XSaV4cma/DPEuS6FxmqZTQqqs0twnU0zzzzr+v0qq/pXJcHi9LK+ReL3OKuDhOM4+6ZAdGa/r9WvaqqrL+nW4Mqz5M6nwJ43F48eK9qyrhMle1lcns9k6nUzPsr2q63JlV6Xpdy4Lx0L3PhgGToFdDK9OiVV6l1mkPDMJ633rqnFl2yvU1OC9PF8MwnJ7J4JuDbK+CdOhdYGmYvc5MJ552+J7vjXc8XCaZ1O3twmD1O5lOTtPkLuvQaZXfOjXN7xZjOTKYPxnNfNL4F6XS9rrnbyZy4L6Z8h7l6OTU8lV6e3BeldLkvc5OTzHqeLsumWXq8m94rxVXgYL0q7Dk5Kzq771Nk8z45ZdLg9vHiq6XbMJnNzw9a/r9Kvmll869K8cVXRNN6nJfjTj+njkr26DOWb3S4OyYTqdzTNS6T2zbNa+NcFV4q4zqdr3OOhZfbNLlOp6ZyZuk2vRjOp2To6Zx5M54XebJ1PVLL5l3TOYzk6nHsOL82eYwll3u5f0qvJxynbhM5y+tx//xAAUEQEAAAAAAAAAAAAAAAAAAACw/9oACAEDAQM/AFSP/9k=);
    /*  #endif  */
}

.status-bar {
    height: 20px;
    width: 100%;
}
.back-btn {
    position: absolute;
    height: 60rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    .back-icon:active {
        color: #666 !important;
    }
}
.search-box {
    position: absolute;
    display: flex;
    align-items: center;
    height: 60rpx;
    background-color: #fbfbfb;
    border-radius: 30rpx;
    padding: 0 20rpx;
    box-sizing: border-box;
    border: 1rpx solid $uni-bg-color-grey;
}
.search-icon {
    margin-right: 10rpx;
}
.search-input {
    flex: 1;
    height: 100%;
    font-size: 14px;
    color: $uni-text-color;
}
</style>
