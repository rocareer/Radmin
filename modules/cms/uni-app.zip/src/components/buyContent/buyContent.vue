<template>
    <view>
        <view class="pay-description">{{ getPriceDescription() }}</view>
        <view v-if="props.content.currency == 'RMB'" class="pay-buttons">
            <button
                @click="onPay('wx')"
                v-if="canPayWithWechat()"
                :loading="state.loading"
                :disabled="state.loading"
                class="pay-button"
                size="mini"
                type="primary"
            >
                微信支付
            </button>
            <button @click="onPay('balance')" class="pay-button" :loading="state.loading" :disabled="state.loading" size="mini" type="default">
                余额支付
            </button>
        </view>
        <view v-else class="pay-buttons">
            <button @click="onPay('score')" class="pay-button" :loading="state.loading" :disabled="state.loading" size="mini" type="default">
                积分支付
            </button>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { check, create } from '@/api/content/pay'
import { isWeixinBrowser, refresh } from '@/utils/common'
import { reactive } from 'vue'

interface Props {
    content: anyObj
}

const props = withDefaults(defineProps<Props>(), {
    content: () => {
        return {}
    },
})

const state = reactive({
    loading: false,
})

const canPayWithWechat = () => {
    // #ifdef MP-WEIXIN
    return true
    // #endif

    // #ifdef WEB
    return isWeixinBrowser()
    // #endif

    return false
}

const getPriceDescription = () => {
    if (props.content.currency == 'RMB') {
        return '你需要支付 ￥' + props.content.price + ' 元后才能查看付费内容'
    } else {
        return '你需要支付 ' + props.content.price + ' 积分后才能查看内容'
    }
}

const onPay = (type: string) => {
    if (['balance', 'score'].includes(type)) {
        uni.showModal({
            title: '提示',
            content: `确定支付 ${type == 'balance' ? '￥' : ''}${props.content.price} ${type == 'balance' ? '' : '积分'}查看内容？`,
            success: (res) => {
                if (res.confirm) {
                    onCreatePay(type)
                }
            },
        })
    } else if (type == 'wx') {
        // #ifdef MP-WEIXIN
        return wx.login({
            success: (res) => {
                if (res.code) {
                    // 总是获取 code，避免服务端没有用户 openid
                    onCreatePay('uni-wx-mini', res.code)
                } else {
                    uni.showToast({
                        title: `拉起微信登录失败：${res.errMsg}`,
                        icon: 'none',
                    })
                }
            },
            fail: (err) => {
                uni.showToast({
                    title: `拉起微信登录失败：${err.errMsg}`,
                    icon: 'none',
                })
            },
        })
        // #endif

        // #ifdef WEB
        if (isWeixinBrowser()) {
            return onCreatePay('uni-wx-mp')
        }
        // #endif

        uni.showModal({
            title: '提示',
            content: '请使用微信客户端打开页面',
        })
    }
}

let timer: null | number = null

/**
 * 轮询检测支付状态
 * @param payLogId 支付日志 ID 号
 */
const checkPayStatus = (payLogId: string) => {
    timer = setInterval(() => {
        check({ id: payLogId }).then((res) => {
            if (res.code == 1) {
                clearInterval(timer!)

                state.loading = false

                refresh()
            }
        })
    }, 3000)
}

const onCreatePay = (type: string, code = '') => {
    state.loading = true
    create({
        project: 'content',
        object: props.content.id,
        type,
        code,
    })
        .then((res) => {
            if (['balance', 'score'].includes(type)) {
                uni.showToast({
                    title: '支付成功',
                    icon: 'none',
                })

                state.loading = false

                refresh()
            } else if (type == 'uni-wx-mini') {
                const info = res.data.info
                const pay = res.data.pay
                uni.requestPayment({
                    provider: 'wxpay',
                    orderInfo: '',
                    timeStamp: pay.timeStamp,
                    nonceStr: pay.nonceStr,
                    package: pay.package,
                    signType: pay.signType,
                    paySign: pay.paySign,
                    success: function () {
                        checkPayStatus(info.id)
                    },
                    fail: function (err) {
                        let errMsg = err.errMsg || err.err_msg
                        if (errMsg == 'requestPayment:fail cancel') {
                            errMsg = '取消支付'
                        } else {
                            errMsg = `支付失败：${errMsg}`
                        }
                        uni.showToast({
                            title: errMsg,
                            icon: 'none',
                        })
                        state.loading = false
                    },
                })
            } else if (type == 'uni-wx-mp') {
                const info = res.data.info
                const pay = res.data.pay
                onWeixinJSBridgePay(pay, info)
            }
        })
        .catch(() => {
            state.loading = false
        })
}

const onWeixinJSBridgePay = (pay: anyObj, info: anyObj) => {
    if (!isWeixinBrowser()) {
        uni.showToast({
            title: '请使用微信客户端发起支付',
            icon: 'none',
        })
        return
    }

    const onBridgeReady = () => {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            {
                appId: pay.appId,
                timeStamp: pay.timeStamp,
                nonceStr: pay.nonceStr,
                package: pay.package,
                signType: pay.signType,
                paySign: pay.paySign,
            },
            function (res: anyObj) {
                const errMsg = res.err_msg || res.errMsg
                if (errMsg == 'get_brand_wcpay_request:ok') {
                    checkPayStatus(info.id)
                    return
                }

                let newMsg = errMsg
                if (errMsg == 'get_brand_wcpay_request:cancel') {
                    newMsg = '取消支付'
                } else if (errMsg == 'get_brand_wcpay_request:fail') {
                    newMsg = '支付失败'
                } else if (errMsg == 'chooseWXPay:fail, the permission value is offline verifying') {
                    newMsg = '请使用真机发起支付：' + errMsg
                }

                uni.showToast({
                    title: newMsg,
                    icon: 'none',
                })

                state.loading = false
            }
        )
    }

    if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
            document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false)
        }
    } else {
        onBridgeReady()
    }
}
declare let WeixinJSBridge: any
</script>

<style lang="scss" scoped>
.pay-buttons {
    display: flex;
    margin: 30rpx;
    margin-top: 0;
    .pay-button {
        margin: 0 20rpx 0 0;
    }
}
.pay-description {
    padding: 25rpx;
    font-weight: bold;
}
</style>
