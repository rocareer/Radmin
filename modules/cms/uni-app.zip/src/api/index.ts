import request from '@/utils/request'

export const initialize = () => {
    return request({
        url: '/api/cms.Index/unInit',
    })
}

export const index = (data: anyObj = {}) => {
    return request({
        url: '/api/cms.Index/unIndex',
        data,
    })
}

export const news = (data: anyObj = {}) => {
    return request({
        url: '/api/cms.Index/uniNews',
        data,
    })
}

export const product = (data: anyObj = {}) => {
    return request({
        url: '/api/cms.Index/uniProduct',
        data,
    })
}
