import { useSiteConfig } from '@/stores/siteConfig'
import { useUserInfo } from '@/stores/userInfo'
import request, { uploadFile, type RequestOptions, type UploadFileOption } from '@/utils/request'

export const apiUploadUrl = '/api/ajax/upload'
export const refreshTokenUrl = '/api/common/refreshToken'
export const clickCaptchaUrl = '/api/common/clickCaptcha'
export const checkClickCaptchaUrl = '/api/common/checkClickCaptcha'

export const upload = (filePath: string, fileType: 'image' | 'video' | 'audio') => {
    const siteConfig = useSiteConfig()
    return uploadFile({
        url: apiUploadUrl,
        filePath,
        fileType,
        name: 'file',
        formData: {
            driver: siteConfig.upload.mode,
        },
    })
}

/**
 * 发送短信
 */
export function sendSms(mobile: string, templateCode: string, extend: anyObj = {}) {
    return request({
        url: templateCode == 'user_mobile_verify' ? '/api/cms.Sms/send' : '/api/Sms/send',
        method: 'POST',
        data: {
            mobile: mobile,
            template_code: templateCode,
            ...extend,
        },
        showSuccessMessage: true,
        showLoading: true,
    })
}

/**
 * 获取验证码数据
 */
export function getCaptchaData(id: string) {
    return request({
        url: clickCaptchaUrl,
        method: 'GET',
        data: { id },
    })
}

/**
 * 校验验证码以显示提示（服务端有复验）
 */
export function checkClickCaptcha(id: string, info: string, unset: boolean) {
    return request({
        url: checkClickCaptchaUrl,
        method: 'POST',
        data: { id, info, unset },
        showCodeMessage: false,
    })
}

/**
 * 刷新 token
 */
export function refreshToken() {
    const userInfo = useUserInfo()
    return request({
        url: refreshTokenUrl,
        method: 'POST',
        data: {
            refreshToken: userInfo.getToken('refresh'),
        },
        __isRefreshToken: true,
    })
}

/**
 * 是否为刷新 token 请求
 */
export function isRefreshTokenRequest(options: RequestOptions | UploadFileOption) {
    return options.__isRefreshToken
}
