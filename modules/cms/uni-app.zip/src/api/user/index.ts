import { useUserInfo } from '@/stores/userInfo'
import request from '@/utils/request'

export const indexUrl = '/api/cms.User/'
export const accountUrl = '/api/account/'

export const index = () => {
    return request({
        url: indexUrl + 'index',
        method: 'GET',
    })
}

export function postLogout() {
    const userInfo = useUserInfo()
    return request({
        url: '/api/user/logout',
        method: 'POST',
        data: {
            refreshToken: userInfo.getToken('refresh'),
        },
    })
}

/**
 * 我的文章列表
 */
export function content(data: anyObj = {}) {
    return request({
        url: indexUrl + 'content',
        method: 'GET',
        data,
    })
}

/**
 * 我的评论列表
 */
export function comment(data: anyObj = {}) {
    return request({
        url: indexUrl + 'comment',
        method: 'GET',
        data,
    })
}

/**
 * 文章统计信息
 */
export function contentStatistics(id: string) {
    return request({
        url: indexUrl + 'contentStatistics',
        method: 'GET',
        data: { id },
        showLoading: true,
    })
}

export function delContent(id: string) {
    return request({
        url: indexUrl + 'delContent',
        method: 'GET',
        data: { id },
        showLoading: true,
    })
}

export function delComment(id: string) {
    return request({
        url: indexUrl + 'delComment',
        method: 'GET',
        data: { id },
        showLoading: true,
        showSuccessMessage: true,
    })
}

export function order(data: anyObj = {}) {
    return request({
        url: indexUrl + 'order',
        method: 'GET',
        data,
    })
}

/**
 * 操作【收藏、点赞、浏览】记录
 */
export function operateRecord(data: anyObj = {}) {
    return request({
        url: indexUrl + 'operateRecord',
        method: 'GET',
        data,
    })
}

/**
 * 获取余额日志
 */
export function getBalanceLog(page: number, pageSize: number) {
    return request({
        url: accountUrl + 'balance',
        method: 'GET',
        data: {
            page: page,
            limit: pageSize,
        },
    })
}

/**
 * 获取积分日志
 */
export function getIntegralLog(page: number, pageSize: number) {
    return request({
        url: accountUrl + 'integral',
        method: 'GET',
        data: {
            page: page,
            limit: pageSize,
        },
    })
}

export function postProfile(data: anyObj) {
    return request({
        url: accountUrl + 'profile',
        method: 'POST',
        data,
        showSuccessMessage: true,
    })
}
