import request from '@/utils/request'

/**
 * 登录和注册
 * @param method 请求方式
 * @param data 请求数据
 * @param mobileQuickLogin 手机号快捷登录注册，请求 CMS 模块增加的专属接口
 */
export const checkIn = (method: 'GET' | 'POST' = 'GET', data: anyObj = {}, mobileQuickLogin = false) => {
    return request({
        url: mobileQuickLogin ? '/api/cms.User/mobileQuickLogin' : '/api/user/checkIn',
        method: method,
        data: data,
    })
}

/**
 * 获取服务条款或隐私政策
 */
export const agreement = (type: string) => {
    return request({
        url: '/api/cms.User/agreement',
        data: { type },
        showLoading: true,
    })
}

/**
 * 找回密码
 */
export function retrievePassword(data: anyObj) {
    return request({
        url: '/api/account/retrievePassword',
        method: 'POST',
        data,
    })
}

/**
 * 用户同意微信登录（微信公众号）
 */
export function loginAgent(code: string, state: string) {
    return request({
        url: '/api/OAuthLogin/loginAgent',
        method: 'GET',
        data: {
            code: code,
            state: state,
        },
        showLoading: true,
    })
}

/**
 * 微信小程序登录
 */
export function wechatMiniProgramLogin(code: string) {
    return request({
        url: '/api/OAuthLogin/wechatMiniProgram',
        method: 'POST',
        data: { code },
        showLoading: true,
    })
}
