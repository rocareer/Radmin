import request from '@/utils/request'

const contentUrl = '/api/cms.Content/'

export const info = (id: string) => {
    return request({
        url: contentUrl + 'info',
        data: { id },
        showLoading: true,
    })
}

export function collect(id: string) {
    return request({
        url: contentUrl + 'collect',
        method: 'POST',
        data: { id },
        showSuccessMessage: true,
    })
}

export function like(id: string) {
    return request({
        url: contentUrl + 'like',
        method: 'POST',
        data: { id },
        showSuccessMessage: true,
    })
}

export function comment(id: string, content: string, atUser: string[]) {
    return request({
        url: contentUrl + 'comment',
        method: 'POST',
        data: {
            id,
            content,
            atUser,
        },
        showSuccessMessage: true,
    })
}

export function loadComments(id: string, page: number) {
    return request({
        url: contentUrl + 'loadComments',
        method: 'GET',
        data: {
            id,
            page,
        },
    })
}

/**
 * 文章列表（频道、搜索等）
 */
export function articleList(data: anyObj) {
    return request({
        url: '/api/cms.Index/articleList',
        method: 'GET',
        data,
    })
}
