import request from '@/utils/request'

const indexUrl = '/api/cms.Pay/'

export function create(data: anyObj = {}) {
    return request({
        url: indexUrl + 'create',
        method: 'GET',
        data,
    })
}

export function check(data: anyObj = {}) {
    return request({
        url: indexUrl + 'check',
        method: 'GET',
        data,
        showCodeMessage: false,
    })
}
