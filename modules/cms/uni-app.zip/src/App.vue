<script setup lang="ts">
import { initialize } from '@/api/index'
import '@/static/scss/index.scss'
import { useSiteConfig } from '@/stores/siteConfig'
import { onHide, onLaunch, onShow } from '@dcloudio/uni-app'

onLaunch(() => {
    initialize().then((res) => {
        const siteConfig = useSiteConfig()
        siteConfig.dataFill(res.data.site)
    })
})
onShow(() => {
    console.log('App Show')
})
onHide(() => {
    console.log('App Hide')
})
</script>
<style></style>
