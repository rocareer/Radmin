<template>
    <view>
        <NavBar :back-btn="true" />

        <view class="article-header" v-if="!state.loading">
            <view
                class="title"
                :style="{
                    color: state.content.title_style['color'],
                    fontWeight: state.content.title_style.bold ? 'bold' : 'normal',
                }"
            >
                {{ state.content.title }}
            </view>
            <view class="author-info">
                <image class="avatar" v-if="state.content.author" :src="fullUrl(state.content.author.avatar)" mode="aspectFill" />
                <view class="author-detail">
                    <view class="author-name" v-if="state.content.author">{{ state.content.author.nickname }}</view>
                    <view class="publish-info"> {{ state.content.cmsChannel.name }} · {{ state.content.publish_time }} </view>
                </view>
            </view>
        </view>

        <!-- 内容展示区域，区分不同的详情模板进行显示 -->
        <template v-if="!state.loading">
            <Default v-if="state.template == 'default'" :content="state.content" />
            <Carousel v-else-if="state.template == 'carousel'" :content="state.content" />
            <Download v-else-if="state.template == 'download'" :content="state.content" />
            <view v-else> 未找到指定的详情模板，请检查 /src/pages/info/template/ 目录</view>
        </template>

        <!-- 文章评论区域 -->
        <view class="comments">
            <view class="comments-title">评论 {{ state.content.comments ? state.content.comments : '' }}</view>
            <view class="comment-item" v-for="(tItem, idx) in state.comments.data" :key="idx">
                <image class="avatar" v-if="tItem.user" :src="fullUrl(tItem.user.avatar)" mode="aspectFill" />
                <view class="comment-detail">
                    <view class="comment-nickanme" v-if="tItem.user">{{ tItem.user.nickname }}</view>
                    <view class="comment-content">
                        <mp-html :selectable="true" class="ba-uni-markdown" :content="tItem.content" />
                    </view>
                    <view class="comment-footer">
                        <text class="comment-time">{{ tItem.create_time }}</text>
                        <text class="comment-divider-circle">•</text>
                        <text class="comment-reply" @click="onAt(tItem.user.id, tItem.user.nickname)">回复TA</text>
                    </view>
                </view>
            </view>
            <uni-load-more class="ba-load-more" :status="state.loadingCommentStatus"></uni-load-more>
        </view>

        <!-- 底栏 -->
        <view class="interaction-bar-box">
            <view class="interaction-bar" :style="{ marginBottom: getInteractionBarMarginBottom() }">
                <view class="comment-btn">
                    <view class="comment-input" @click="onCommentModel(true)">
                        <uni-icons type="chatbubble" size="22" />
                        <text>写跟帖</text>
                    </view>
                    <view class="comment-divider"></view>
                    <view class="comment-count" @click="goToComments">
                        <uni-badge size="small" absolute="rightTop" :offset="[0, 6]" :text="state.content.comments">
                            <uni-icons type="chat" size="22" />
                        </uni-badge>
                    </view>
                </view>
                <view class="stats">
                    <view class="stat-item like-count" @click="onLike">
                        <uni-icons type="hand-up" size="22" :color="state.content.likeed ? '#409eff' : '#666666'" />
                        <text :style="{ color: state.content.likeed ? '#409eff' : '#666666' }">{{ state.content.likes }}</text>
                    </view>
                    <view class="stat-item star" @click="onCollect">
                        <uni-icons type="star" size="22" :color="state.content.collected ? '#409eff' : '#666666'" />
                        <text :style="{ color: state.content.collected ? '#409eff' : '#666666' }">{{ state.content.collects }}</text>
                    </view>
                    <button open-type="share" class="stat-item share" v-if="shareBtnStatus" @click="onShare">
                        <uni-icons type="redo" size="22" color="#666666" />
                    </button>
                </view>
            </view>

            <!-- #ifndef WEB -->
            <view class="safe-area"></view>
            <!-- #endif -->
        </view>

        <!-- 评论输入框 -->
        <view v-if="state.commentModelStatus" class="comment-textarea-box" :style="{ top: `${getStatusBarHeight()! + navBarNetHeight}px` }">
            <textarea
                :fixed="true"
                :focus="true"
                :maxlength="-1"
                :adjust-position="false"
                class="comment-textarea"
                placeholder="请输入评论内容"
                v-model="state.comment"
            ></textarea>
            <button
                class="comment-textarea-send-btn"
                @click="onSubmitComment"
                size="mini"
                type="primary"
                :disabled="state.commentSubmit"
                :loading="state.commentSubmit"
            >
                评论
            </button>
        </view>

        <!-- 遮罩层 -->
        <view v-if="shadeIsShow" @click="onCloseShade()" class="shade"></view>
    </view>
</template>

<script lang="ts" setup>
import { collect, comment, info, like, loadComments } from '@/api/content/index'
import { navBarNetHeight } from '@/components/navBar/index'
import NavBar from '@/components/navBar/navBar.vue'
import { useSiteConfig } from '@/stores/siteConfig'
import { useUserInfo } from '@/stores/userInfo'
import { fullUrl, getFirstImage, getStatusBarHeight } from '@/utils/common'
import { onLoad, onReachBottom, onShareAppMessage } from '@dcloudio/uni-app'
import { computed, nextTick, reactive } from 'vue'
import Carousel from './template/carousel.vue'
import Default from './template/default.vue'
import Download from './template/download.vue'

const userInfo = useUserInfo()
const state: {
    id: string
    loading: boolean
    content: anyObj
    comments: {
        data: anyObj[]
        total: number
        current_page: number
    }
    template: string
    comment: string
    commentSubmit: boolean
    commentModelStatus: boolean
    atUsers: Map<string, { id: string; nickname: string }>
    loadingCommentStatus: string
    pageSize: number
} = reactive({
    id: '0',
    loading: true,
    content: {},
    comments: {
        data: [],
        total: 0,
        current_page: 1,
    },
    template: 'default',
    comment: '',
    commentSubmit: false,
    commentModelStatus: false,
    atUsers: new Map(),
    loadingCommentStatus: 'more',
    pageSize: 15,
})

const shadeIsShow = computed(() => {
    return state.commentModelStatus
})

const onCloseShade = () => {
    onCommentModel(false)
}

const onCommentModel = (status: boolean) => {
    state.commentModelStatus = status
}

const goToComments = () => {
    uni.pageScrollTo({
        selector: '.comments',
    })
}

const onAt = (id: string, nickname: string) => {
    state.atUsers.set(id, {
        id: id,
        nickname: nickname,
    })
    onCommentModel(true)
    state.comment = `@${nickname} `
}

const onSubmitComment = () => {
    if (!state.comment) {
        uni.showToast({
            title: '请输入评论内容',
            icon: 'none',
        })
        return
    }

    state.commentSubmit = true

    const atUsers: string[] = []
    for (const [key, value] of state.atUsers) {
        if (state.comment.search('@' + value.nickname + ' ') !== -1) {
            atUsers.push(key)
        }
    }

    comment(state.id, state.comment, atUsers)
        .then((res) => {
            if (res.code == 1) {
                // 评论后才可下载的内容？
                if (state.template == 'download' && !state.content.commented) {
                    getInfo()
                }

                if (res.data.commentsReview == 'no') {
                    // 渲染评论
                    state.comments.data.unshift({
                        content: state.comment,
                        create_time: '刚刚',
                        user: {
                            id: userInfo.id,
                            avatar: userInfo.avatar,
                            nickname: userInfo.nickname,
                        },
                    })

                    nextTick(() => {
                        goToComments()
                    })
                }

                state.atUsers.clear()
                onCommentModel(false)
                state.comment = ''
            }
        })
        .finally(() => {
            state.commentSubmit = false
        })
}

const onLike = () => {
    like(state.id).then((res) => {
        if (res.code == 1) {
            state.content.likes++
            state.content.likeed = true
        }
    })
}

const onCollect = () => {
    collect(state.id).then((res) => {
        if (res.code == 1) {
            state.content.collected = res.data.collected
            state.content.collects = state.content.collected ? state.content.collects + 1 : state.content.collects - 1
        }
    })
}

const shareBtnStatus = computed(() => {
    // #ifdef WEB
    return !!navigator.share
    // #endif

    // #ifdef APP-PLUS || MP
    return true
    // #endif

    return false
})

const onShare = async () => {
    if (shareBtnStatus.value) {
        // #ifdef MP
        return true
        // #endif

        // #ifdef WEB
        try {
            await navigator.share({
                title: state.content.title,
                text: state.content.description,
                url: document.location.href,
            })
        } catch (err) {
            uni.showToast({
                title: '分享失败：' + err,
                icon: 'none',
            })
        }
        return true
        // #endif

        // #ifdef APP-PLUS
        const siteConfig = useSiteConfig()
        uni.shareWithSystem({
            summary: state.content.title,
            href: `${siteConfig.h5Domain}/#/pages/info/info?id=${state.id}`,
        })
        // #endif
    }
}

const getInfo = () => {
    state.loading = true
    info(state.id)
        .then((res) => {
            state.content = res.data.content
            state.template = res.data.template
            state.comments = res.data.comments
        })
        .finally(() => {
            state.loading = false
            state.loadingCommentStatus = state.comments.total > state.pageSize * state.comments.current_page ? 'more' : 'noMore'
        })
}

onReachBottom(() => {
    if (state.loadingCommentStatus == 'noMore') {
        return
    }

    state.loadingCommentStatus = 'loading'
    loadComments(state.id, state.comments.current_page + 1)
        .then((res) => {
            if (res.data.current_page > 1) {
                state.comments.total = res.data.total
                state.comments.current_page = res.data.current_page
                state.comments.data = [...state.comments.data, ...res.data.data]
            }
        })
        .finally(() => {
            state.loadingCommentStatus = state.comments.total > state.pageSize * state.comments.current_page ? 'more' : 'noMore'
        })
})

onLoad((query) => {
    if (query && query.id) {
        state.id = query.id
        getInfo()
    }
})

onShareAppMessage(() => {
    return {
        title: state.content.title,
        path: '/pages/info/info?id=' + state.id,
        imageUrl: getFirstImage(state.content.images),
        desc: state.content.description,
    }
})

/**
 * 底部有安全区域时，取消下边距
 */
const getInteractionBarMarginBottom = () => {
    // #ifdef APP-PLUS || WEB || MP-WEIXIN
    return uni.getWindowInfo().safeAreaInsets.bottom > 0 ? '0' : ''
    // #endif

    const safeAreaInsets = uni.getSystemInfoSync().safeAreaInsets
    return safeAreaInsets && safeAreaInsets!.bottom > 0 ? '0' : ''
}
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style lang="scss" scoped>
.comments {
    padding: 0 30rpx 0 30rpx;
    padding-bottom: calc(100rpx + env(safe-area-inset-bottom));
    .comments-title {
        line-height: 80rpx;
        font-size: 16px;
        font-weight: bold;
    }
    .comment-item {
        display: flex;
        padding: 20rpx 0;
        border-bottom: 1px solid $uni-border-color;
        .avatar {
            width: 60rpx;
            height: 60rpx;
            min-width: 60rpx;
        }
        .comment-detail {
            .comment-nickanme {
                font-size: 14px;
                color: $uni-text-color;
            }
            .comment-content {
                color: $uni-text-color;
                margin: 10rpx 0;
                margin-left: -2rpx;
            }
            .comment-footer {
                display: flex;
                align-items: center;
                font-size: 13px;
                color: $uni-text-color-grey;
                .comment-divider-circle {
                    margin: 0 5rpx;
                }
                .comment-reply {
                    color: $uni-text-color;
                }
            }
        }
    }
}
.shade {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: $uni-bg-color-mask;
    z-index: 990;
}
.comment-textarea-box {
    position: fixed;
    width: 100%;
    top: 0;
    display: flex;
    align-items: flex-end;
    background-color: $uni-bg-color;
    padding: 20rpx;
    overflow: hidden;
    box-sizing: border-box;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    z-index: 991;
    .comment-textarea {
        flex: 1;
        font-size: 13px;
        height: 200rpx;
        padding: 10rpx;
        background-color: $uni-bg-color-grey;
    }
    .comment-textarea-send-btn {
        display: block;
        margin-left: 20rpx;
        margin-bottom: 20rpx;
    }
    .comment-textarea-send-btn:after {
        border: none;
    }
}
.article-header {
    padding: 30rpx;
    padding-bottom: 0;
    background-color: $uni-bg-color;
}
.title {
    font-size: 20px;
    font-weight: bold;
    line-height: 1.4;
    color: $uni-text-color;
    margin-bottom: 30rpx;
}
.author-info {
    display: flex;
    align-items: center;
    margin-left: -4rpx;
}
.avatar {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    margin-right: 16rpx;
    border: 1px solid rgba(0, 0, 0, 0.1);
}
.author-detail {
    display: flex;
    flex-direction: column;
}
.author-name {
    display: flex;
    align-items: center;
    font-size: 16px;
    line-height: 16px;
    color: $uni-text-color;
    margin-bottom: 6rpx;
}
.publish-info {
    font-size: 12px;
    color: $uni-text-color-grey;
}
.interaction-bar-box {
    position: fixed;
    width: 100%;
    bottom: 0;
    background-color: $uni-bg-color;
    box-sizing: border-box;
    box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.1);
    .interaction-bar {
        display: flex;
        align-items: center;
        padding: 0 20rpx;
        margin: 16rpx 0;
    }
    .safe-area {
        height: env(safe-area-inset-bottom);
    }
}
.comment-btn {
    display: flex;
    align-items: center;
    background-color: #f0f2f5;
    border-radius: 36rpx;
    transition: all 0.2s ease;
    flex: 1;
    margin-right: 10rpx;
}
.comment-input {
    display: flex;
    align-items: center;
    flex: 1;
    padding: 10rpx 20rpx;
    border-top-left-radius: 36rpx;
    border-bottom-left-radius: 36rpx;
    text {
        font-size: 14px;
        color: $uni-text-color;
        margin-left: 12rpx;
    }
    &:active {
        background-color: #e6e8eb;
    }
}
.comment-divider {
    width: 1px;
    height: 32rpx;
    background-color: #e0e0e0;
}
.comment-count {
    display: flex;
    align-items: center;
    padding: 10rpx 30rpx 10rpx 20rpx;
    border-top-right-radius: 36rpx;
    border-bottom-right-radius: 36rpx;
    &:active {
        background-color: #e6e8eb;
    }
}
.stats {
    display: flex;
    justify-content: flex-end;
    align-items: center;
}
.stat-item {
    display: flex;
    align-items: center;
    padding: 12rpx;
    border-radius: 50%;
    transition: all 0.2s ease;
}
.stat-item text {
    font-size: 14px;
    font-weight: 500;
    margin-left: 4rpx;
}
.stat-item .uni-icons {
    display: flex;
    align-items: center;
    justify-content: center;
}
.share {
    line-height: 1;
    background-color: transparent;
}
.share:after {
    border: none;
    content: unset;
}
</style>
