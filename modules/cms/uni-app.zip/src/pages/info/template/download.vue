<template>
    <view>
        <view class="article-content">
            <!-- 轮播图 -->
            <swiper
                v-if="content.images && content.images.length >= 3"
                class="swiper-section"
                autoplay
                circular
                indicator-dots
                :interval="3000"
                indicator-color="rgba(255, 255, 255, .3)"
                indicator-active-color="rgba(255, 255, 255, .6)"
            >
                <swiper-item v-for="(carousel, cIdx) in props.content.images" :key="cIdx">
                    <image class="swiper-img" :src="fullUrl(carousel)" mode="aspectFill"></image>
                </swiper-item>
            </swiper>
            <mp-html :selectable="true" class="ba-uni-markdown" :content="props.content.content" />
        </view>

        <!-- 下载链接 -->
        <view class="download-urls">
            <view class="download-title">下载链接</view>
            <view v-if="parseFloat(content.price) <= 0">
                <view v-if="content.commented">
                    <button
                        @click="onDownload(item.value)"
                        class="download-button"
                        type="primary"
                        v-for="(item, idx) in content.downloads"
                        :key="idx"
                    >
                        {{ item.key }}
                    </button>
                </view>
                <view class="download-tips" v-else>您需要评论后，才能查阅下载链接。</view>
            </view>
            <view v-else>
                <BuyContent :content="content" />
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import BuyContent from '@/components/buyContent/buyContent.vue'
import { fullUrl } from '@/utils/common'

interface Props {
    content: anyObj
}

const props = withDefaults(defineProps<Props>(), {
    content: () => {
        return {}
    },
})

const onDownload = (url: string) => {
    // #ifdef WEB
    window.open(url)
    return true
    // #endif

    uni.setClipboardData({
        data: url,
        success: function () {
            uni.showToast({
                title: '链接复制成功~',
                icon: 'none',
            })
        },
    })
}
</script>

<style scoped lang="scss">
.article-content {
    padding: 10rpx 30rpx;
}
.swiper-section {
    position: relative;
    height: 400rpx;
    overflow: hidden;
    margin-top: 10rpx;
}
.swiper-img {
    width: 100%;
    height: 100%;
}
.download-urls {
    padding: 10rpx 30rpx;
    .download-title {
        line-height: 80rpx;
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 10rpx;
    }
    .download-tips {
        font-weight: bold;
    }
    .download-button {
        margin-bottom: 20rpx;
    }
}
</style>
