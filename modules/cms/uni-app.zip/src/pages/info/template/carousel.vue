<template>
    <view>
        <view v-if="parseFloat(content.price) <= 0" class="article-content">
            <!-- 轮播图 -->
            <swiper
                class="swiper-section"
                autoplay
                circular
                indicator-dots
                :interval="3000"
                indicator-color="rgba(255, 255, 255, .3)"
                indicator-active-color="rgba(255, 255, 255, .6)"
            >
                <swiper-item v-for="(carousel, cIdx) in props.content.images" :key="cIdx">
                    <image class="swiper-img" :src="fullUrl(carousel)" mode="aspectFill"></image>
                </swiper-item>
            </swiper>
            <mp-html :selectable="true" class="ba-uni-markdown" :content="props.content.content" />
        </view>
        <view v-else>
            <BuyContent :content="content" />
        </view>
    </view>
</template>

<script lang="ts" setup>
import BuyContent from '@/components/buyContent/buyContent.vue'
import { fullUrl } from '@/utils/common'

interface Props {
    content: anyObj
}

const props = withDefaults(defineProps<Props>(), {
    content: () => {
        return {}
    },
})
</script>

<style scoped lang="scss">
.article-content {
    padding: 10rpx 30rpx;
}
.swiper-section {
    position: relative;
    height: 400rpx;
    overflow: hidden;
    margin-top: 10rpx;
}
.swiper-img {
    width: 100%;
    height: 100%;
}
</style>
