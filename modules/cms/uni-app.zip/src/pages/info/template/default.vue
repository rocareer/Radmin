<template>
    <view>
        <view v-if="parseFloat(content.price) <= 0" class="article-content">
            <mp-html :selectable="true" class="ba-uni-markdown" :content="props.content.content" />
        </view>
        <view v-else>
            <BuyContent :content="content" />
        </view>
    </view>
</template>

<script lang="ts" setup>
import BuyContent from '@/components/buyContent/buyContent.vue'

interface Props {
    content: anyObj
}

const props = withDefaults(defineProps<Props>(), {
    content: () => {
        return {}
    },
})
</script>

<style scoped lang="scss">
.article-content {
    padding: 10rpx 30rpx;
}
</style>
