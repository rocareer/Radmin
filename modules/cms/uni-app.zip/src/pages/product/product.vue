<template>
    <view>
        <NavBar />

        <!-- #ifndef WEB -->
        <view class="refresh-box" :style="{ marginTop: `${state.refreshBoxMarginTop}px` }">
            {{ state.isRefreshing ? '刷新中...' : '继续下拉刷新内容' }}
        </view>
        <!-- #endif -->

        <!-- 内容列表不使用 scroll-view，为了H5下的最好表现效果，特别是大部分手机浏览器在滑动后才能全屏（scroll-view 的滑动不能触发全屏） -->
        <!-- 自定义导航栏后下拉刷新微信小程序内不好用，自行实现 -->
        <view
            @mousedown="onSwitchStart"
            @mousemove="onSwitchMove"
            @mouseup="onSwitchEnd"
            @touchstart="onSwitchStart"
            @touchmove="onSwitchMove"
            @touchend="onSwitchEnd"
            @touchcancel="onSwitchEnd"
        >
            <view class="product-list">
                <view class="product-card" v-for="(item, index) in state.contents.data" :key="index" @click="goToDetail(item.id)">
                    <image class="product-image" :src="getFirstImage(item.images)" mode="widthFix" lazy-load />
                    <view class="product-info">
                        <text class="product-title">{{ item.title }}</text>
                        <text class="product-desc">{{ item.description }}</text>
                    </view>
                </view>

                <uni-load-more class="ba-load-more" :status="state.loadingStatus"></uni-load-more>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { product } from '@/api/index'
import NavBar from '@/components/navBar/navBar.vue'
import { useSiteConfig } from '@/stores/siteConfig'
import { getFirstImage, onTabBarPageLoad } from '@/utils/common'
import { onLoad, onPageScroll, onReachBottom, onShareAppMessage, onShow } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const siteConfig = useSiteConfig()
const refreshBoxDefaultMarginTop = -50
const state: {
    scrollTop: number
    isRefreshing: boolean
    refreshBoxMarginTop: number
    pageSize: number
    contents: {
        total: number
        data: anyObj[]
        current_page: number
    }
    loadingStatus: string
} = reactive({
    scrollTop: 0,
    isRefreshing: false,
    refreshBoxMarginTop: refreshBoxDefaultMarginTop,
    pageSize: 10,
    contents: {
        total: 0,
        data: [],
        current_page: 1,
    },
    loadingStatus: 'more',
})

let isDragging = false
let touchStartY = 0

/**
 * PS：e 的类型在 H5 是 TouchEvent，同时微信小程序等平台，没有 MouseEvent 类型
 */
const onSwitchStart = (e: TouchEvent | MouseEvent | any) => {
    if (state.isRefreshing) return

    touchStartY = e.clientY || e.touches[0].clientY
    isDragging = true
}

const onSwitchMove = (e: TouchEvent | MouseEvent | any) => {
    if (!isDragging) return

    const deltaY = (e.clientY || e.touches[0].clientY) - touchStartY

    // #ifndef WEB
    if (state.scrollTop < 10 || state.refreshBoxMarginTop != refreshBoxDefaultMarginTop) {
        let top = refreshBoxDefaultMarginTop + deltaY
        state.refreshBoxMarginTop = top > 0 ? 0 : top < refreshBoxDefaultMarginTop ? refreshBoxDefaultMarginTop : top
    }
    // #endif
}

const onSwitchEnd = () => {
    if (!isDragging) return
    isDragging = false

    if (state.refreshBoxMarginTop >= 0) {
        state.isRefreshing = true
        onInit()
    } else {
        state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
    }
}

const goToDetail = (id: number) => {
    uni.navigateTo({
        url: `/pages/info/info?id=${id}`,
    })
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    loadData(state.contents.current_page + 1)
}

/**
 * 刷新/初始化
 */
const onInit = () => {
    state.loadingStatus = 'more'
    state.contents = {
        total: 0,
        data: [],
        current_page: 1,
    }
    state.scrollTop = 0
    loadData(1)
}

const loadData = (page: number) => {
    state.loadingStatus = 'loading'
    product({ page, limit: state.pageSize })
        .then((res) => {
            if (page > 1) {
                state.contents.total = res.data.contents.total
                state.contents.current_page = res.data.contents.current_page
                state.contents.data = [...state.contents.data, ...res.data.contents.data]
            } else {
                state.contents = res.data.contents
            }

            // 下拉刷新重置
            state.isRefreshing = false
            state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
        })
        .finally(() => {
            state.loadingStatus = state.contents.total > state.pageSize * state.contents.current_page ? 'more' : 'noMore'
        })
}

onLoad(() => {
    onTabBarPageLoad()
})

onShow(() => {
    onTabBarPageLoad()
})

onPageScroll((e) => {
    state.scrollTop = e.scrollTop
})

onReachBottom(() => {
    loadMore()
})

onInit()

onShareAppMessage(() => {
    return {
        title: siteConfig.siteName,
        path: '/pages/product/product',
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style lang="scss" scoped>
.refresh-box {
    font-size: 14px;
    color: $uni-text-color-grey;
    text-align: center;
    padding-top: 10px;
    line-height: 40px;
}
.product-list {
    display: block;
    overflow: hidden;
    padding: 20rpx 20rpx 0 20rpx;
}
.product-card {
    margin-bottom: 20rpx;
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    overflow: hidden;
    box-shadow: 0 4rpx 16rpx rgba(0, 0, 0, 0.08);
}
.product-image {
    display: block;
    width: 100%;
    border-radius: 16rpx 16rpx 0 0;
}
.product-info {
    padding: 24rpx;
}
.product-title {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: $uni-text-color;
    margin-bottom: 16rpx;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.product-desc {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    overflow: hidden;
    font-size: 14px;
    color: $uni-text-color-grey;
    line-height: 1.4;
}
</style>
