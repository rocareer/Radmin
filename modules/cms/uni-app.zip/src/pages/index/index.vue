<template>
    <view>
        <NavBar :box-shadow="false" />

        <!-- 频道导航 -->
        <view class="channel-nav-fixed-placeholder"></view>
        <view
            class="channel-nav"
            :style="{
                top: `${getStatusBarHeight()! + navBarNetHeight}px`,
                boxShadow: state.scrollTop > 20 ? '0 2px 4px rgba(0, 0, 0, 0.1)' : 'none',
            }"
        >
            <scroll-view class="channel-nav-scroll-view" scroll-x>
                <view
                    v-for="(item, idx) in state.channels"
                    :key="idx"
                    @click="changeTabIndex(idx)"
                    class="nav-item"
                    :class="{ active: state.currentTabIndex === idx }"
                >
                    {{ item.channel.name }}
                </view>
            </scroll-view>
        </view>

        <!-- #ifndef WEB -->
        <view class="refresh-box" :style="{ marginTop: `${state.refreshBoxMarginTop}px` }">
            {{ state.isRefreshing ? '刷新中...' : '继续下拉刷新内容' }}
        </view>
        <!-- #endif -->

        <!-- 内容列表不使用 scroll-view，为了H5下的最好表现效果，特别是大部分手机浏览器在滑动后才能全屏（scroll-view 的滑动不能触发全屏） -->
        <!-- tabs 左右切换不使用 swiper，为了最佳性能，以及不固定高度（原因同上） -->
        <!-- 自定义导航栏后下拉刷新微信小程序内不好用，自行实现 -->
        <view
            class="content-carousel"
            @mousedown="onSwitchStart"
            @mousemove="onSwitchMove"
            @mouseup="onSwitchEnd"
            @touchstart="onSwitchStart"
            @touchmove="onSwitchMove"
            @touchend="onSwitchEnd"
            @touchcancel="onSwitchEnd"
        >
            <view
                class="content-carousel-track"
                :style="{
                    transform: `translateX(${-(state.currentTabIndex * 100) + state.slideTransformX}%)`,
                    marginBottom: `${state.contentCarouselTrackMarginBottom}px`,
                }"
            >
                <view class="content-carousel-slide" v-for="(channel, idx) in state.channels" :key="idx" :class="'content-carousel-slide-' + idx">
                    <!-- 新闻列表 -->
                    <view class="news-list">
                        <!-- 轮播图 -->
                        <swiper
                            v-if="idx === 0"
                            class="swiper-section"
                            autoplay
                            circular
                            indicator-dots
                            :interval="3000"
                            indicator-color="rgba(255, 255, 255, .3)"
                            indicator-active-color="rgba(255, 255, 255, .6)"
                        >
                            <swiper-item
                                v-for="(carousel, cIdx) in state.indexCarousel"
                                :key="cIdx"
                                @click="
                                    navigate(carousel.target as NavigateType, {
                                        url: carousel.link,
                                    })
                                "
                            >
                                <image class="swiper-img" :src="fullUrl(carousel.image)" mode="aspectFill"></image>
                                <view class="swiper-title">{{ carousel.title }}</view>
                            </swiper-item>
                        </swiper>

                        <ContentList :contents="channel.content.data" mode="tiled" />

                        <uni-load-more v-if="channel.content.data.length" class="ba-load-more" :status="state.loadingStatus"></uni-load-more>

                        <!-- 无内容使用有足够高度的单独 empty 块，避免不能左右滑动 -->
                        <view
                            v-else
                            class="empty-content"
                            :style="{
                                // 防止出现滚动条
                                height: `calc(${get100vh()} - ${getStatusBarHeight()! + navBarNetHeight + 38}px)`,
                            }"
                        >
                            <view class="empty-text">暂无内容</view>
                        </view>
                    </view>
                    <view class="support"></view>
                </view>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { index } from '@/api/index'
import ContentList from '@/components/contentList/contentList.vue'
import { navBarNetHeight } from '@/components/navBar/index'
import NavBar from '@/components/navBar/navBar.vue'
import { useSiteConfig } from '@/stores/siteConfig'
import { fullUrl, get100vh, getStatusBarHeight, getWindowWidth, navigate, onTabBarPageLoad } from '@/utils/common'
import { onLoad, onPageScroll, onReachBottom, onShareAppMessage, onShow } from '@dcloudio/uni-app'
import { nextTick, reactive } from 'vue'

const siteConfig = useSiteConfig()
const refreshBoxDefaultMarginTop = -50
const state: {
    scrollTop: number
    isRefreshing: boolean
    currentTabIndex: number
    slideTransformX: number
    contentCarouselTrackMarginBottom: number
    refreshBoxMarginTop: number
    channels: anyObj[]
    indexCarousel: anyObj[]
    loadingStatus: string
    pageSize: number
} = reactive({
    scrollTop: 0,
    isRefreshing: false,
    currentTabIndex: 0,
    slideTransformX: 0,
    contentCarouselTrackMarginBottom: 0,
    refreshBoxMarginTop: refreshBoxDefaultMarginTop,
    channels: [],
    indexCarousel: [],
    loadingStatus: 'more',
    pageSize: 10,
})

let isDragging = false
let touchStartX = 0
let touchStartY = 0

/**
 * PS：e 的类型在 H5 是 TouchEvent，同时微信小程序等平台，没有 MouseEvent 类型
 */
const onSwitchStart = (e: TouchEvent | MouseEvent | any) => {
    if (state.isRefreshing) return

    touchStartX = e.clientX || e.touches[0].clientX
    touchStartY = e.clientY || e.touches[0].clientY
    isDragging = true
}

const onSwitchMove = (e: TouchEvent | MouseEvent | any) => {
    if (!isDragging) return

    const deltaX = (e.clientX || e.touches[0].clientX) - touchStartX
    const deltaY = (e.clientY || e.touches[0].clientY) - touchStartY

    // #ifndef WEB
    if (state.scrollTop < 10 || state.refreshBoxMarginTop != refreshBoxDefaultMarginTop) {
        let top = refreshBoxDefaultMarginTop + deltaY
        state.refreshBoxMarginTop = top > 0 ? 0 : top < refreshBoxDefaultMarginTop ? refreshBoxDefaultMarginTop : top
    }
    // #endif

    // 明显的上下滑动，而不是左右（设备通常竖长横短，所以横方向乘2）
    if (Math.abs(deltaX) < Math.abs(deltaY) * 2) {
        return
    }

    const offset = deltaX / (getWindowWidth() / 2)
    let slideTransformX = offset * 100

    // 左右滑动达到一定距离才返馈
    state.slideTransformX = Math.abs(slideTransformX) > 10 ? slideTransformX : 0
}

const onSwitchEnd = () => {
    if (!isDragging) return
    isDragging = false

    if (state.refreshBoxMarginTop >= 0) {
        state.isRefreshing = true
        onInit()
    } else {
        state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
    }

    if (Math.abs(state.slideTransformX) >= 20) {
        const nextIndex = state.slideTransformX > 0 ? state.currentTabIndex - 1 : state.currentTabIndex + 1
        if (nextIndex >= 0 && nextIndex < state.channels.length) {
            changeTabIndex(nextIndex)
        } else if (nextIndex >= state.channels.length) {
            changeTabIndex(0)
        } else if (nextIndex < 0) {
            changeTabIndex(state.channels.length - 1)
        }
    }

    state.slideTransformX = 0
}

const changeTabIndex = (newIndex: number) => {
    state.currentTabIndex = newIndex

    const channelContent = state.channels[state.currentTabIndex].content
    state.loadingStatus = channelContent.total > state.pageSize * channelContent.current_page ? 'more' : 'noMore'

    // 滚动条拉至顶部
    uni.pageScrollTo({
        scrollTop: 0,
        duration: 100,
    })

    carouselTrackMarginBottom()
}

/**
 * 页面高度取值最高 tab 高度
 * 切换 tab 后，需确保：页面高度不高于当前 tab 内容最大高度
 */
const carouselTrackMarginBottom = () => {
    uni.createSelectorQuery()
        .select('.content-carousel-track')
        .boundingClientRect((trackData: any) => {
            uni.createSelectorQuery()
                .select('.content-carousel-slide-' + state.currentTabIndex)
                .boundingClientRect((data: any) => {
                    const newMarginBottom = data.height - trackData.height
                    state.contentCarouselTrackMarginBottom = newMarginBottom >= 0 ? 0 : newMarginBottom
                })
                .exec()
        })
        .exec()
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    loadData(state.channels[state.currentTabIndex].content.current_page + 1)
}

/**
 * 刷新/初始化
 */
const onInit = () => {
    state.loadingStatus = 'more'
    state.channels = []
    state.scrollTop = 0
    loadData(1)
}

const loadData = (page: number) => {
    state.loadingStatus = 'loading'
    index({
        page: page,
        limit: state.pageSize,
        channel: page > 1 ? state.channels[state.currentTabIndex].channel.id : 'all',
    })
        .then((res) => {
            if (page > 1) {
                state.channels[state.currentTabIndex].content.total = res.data.content.total
                state.channels[state.currentTabIndex].content.current_page = res.data.content.current_page
                state.channels[state.currentTabIndex].content.data = [...state.channels[state.currentTabIndex].content.data, ...res.data.content.data]

                nextTick(() => {
                    carouselTrackMarginBottom()
                })
            } else {
                state.channels = res.data.channels
                state.indexCarousel = res.data.indexCarousel
            }

            state.isRefreshing = false
            state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
        })
        .finally(() => {
            const content = state.channels[state.currentTabIndex].content
            state.loadingStatus = content.total > state.pageSize * content.current_page ? 'more' : 'noMore'
        })
}

onLoad(() => {
    onTabBarPageLoad()
})

onShow(() => {
    onTabBarPageLoad()
})

onPageScroll((e) => {
    state.scrollTop = e.scrollTop
})

onReachBottom(() => {
    loadMore()
})

onInit()

onShareAppMessage(() => {
    return {
        title: siteConfig.siteName,
        path: '/pages/index/index',
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style scoped lang="scss">
.refresh-box {
    font-size: 14px;
    color: $uni-text-color-grey;
    text-align: center;
    padding-top: 10px;
    line-height: 40px;
}
.channel-nav-fixed-placeholder {
    display: block;
    width: 100%;
    height: 36px;
}
.channel-nav {
    position: fixed;
    display: flex;
    align-items: center;
    height: 36px;
    width: 100%;
    background-color: $uni-bg-color;
    border-bottom: 1px solid $uni-border-color;
    box-sizing: border-box;
    z-index: 999;
}
.channel-nav-scroll-view {
    flex: 1;
    white-space: nowrap;
}
.nav-item {
    display: inline-block;
    padding: 0 20rpx;
    font-size: 14px;
    color: $uni-text-color;
    line-height: 72rpx;
}
.nav-item.active {
    color: $uni-color-primary;
    font-weight: bold;
}
.content-carousel {
    overflow: hidden;
}
.content-carousel-track {
    display: flex;
    transition: 0.3s;
}
.content-carousel-slide {
    display: block;
    width: 100%;
    height: 100%;
    .support {
        width: 100vw;
    }
}
.swiper-section {
    position: relative;
    height: 400rpx;
    // 数值上的统一为 20px，但轮播通常为大图显得很宽，为了视觉上的统一，额外加了 2px
    margin: 20rpx 22rpx 10rpx 22rpx;
    border-radius: 12rpx;
    overflow: hidden;
}
.swiper-img {
    width: 100%;
    height: 100%;
    border-radius: 12rpx;
}
.swiper-title {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 20rpx;
    color: $uni-text-color-inverse;
    font-size: 16px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
}
.news-list {
    display: block;
    width: 100%;
}
.empty-content {
    display: flex;
    justify-content: center;
    align-items: center;
}
.empty-text {
    font-size: 14px;
    color: $uni-text-color-grey;
}
</style>
