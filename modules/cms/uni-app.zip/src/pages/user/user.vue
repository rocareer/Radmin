<template>
    <view :style="{ height: get100vh() }">
        <!-- #ifdef H5 -->
        <view class="nav-support" :style="{ height: '50rpx' }"></view>
        <!-- #endif -->

        <!-- #ifndef H5 -->
        <view class="nav-support" :style="{ height: `${getStatusBarHeight()! + navBarNetHeight}px` }"></view>
        <!-- #endif -->

        <view class="bg-image"></view>
        <view class="container">
            <!-- 用户信息区 -->
            <view class="user-info">
                <view class="user-header" v-if="userInfo.isLogin()">
                    <image class="avatar" :src="fullUrl(userInfo.avatar)" />
                    <view class="user-detail">
                        <view class="name-wrap">
                            <text class="nickname">{{ userInfo.nickname }}</text>
                            <view class="badge-wrap">
                                <image class="gender" :src="userInfo.getGenderIcon()" />
                            </view>
                        </view>
                        <view class="user-stats">{{ userInfo.motto ? userInfo.motto : '这家伙很懒，什么也没写~' }}</view>
                        <text class="last-time">上次登录：{{ timeFormat(userInfo.last_login_time) }}</text>
                    </view>
                </view>
                <view class="user-header" v-else>
                    <view class="login-btn-box">
                        <navigator url="/pages/user/login" class="login-btn">登录</navigator>
                    </view>
                </view>
            </view>

            <!-- 账户信息 -->
            <view class="account-info">
                <view class="account-stats">
                    <view class="stat-item" @click="navigate('/pages/user/content')">
                        <text class="stat-num">{{ state.contentCount }}</text>
                        <text class="stat-label">文章</text>
                    </view>
                    <view class="stat-item" @click="navigate('/pages/user/comment')">
                        <text class="stat-num">{{ state.commentCount }}</text>
                        <text class="stat-label">评论</text>
                    </view>
                    <view class="stat-item" @click="navigate('/pages/user/score')">
                        <text class="stat-num">{{ userInfo.score }}</text>
                        <text class="stat-label">积分</text>
                    </view>
                    <view class="stat-item" @click="navigate('/pages/user/money')">
                        <text class="stat-num">{{ parseFloat(userInfo.money.toString()) }}</text>
                        <text class="stat-label">余额</text>
                    </view>
                </view>
            </view>

            <!-- 功能区域 -->
            <view class="function-area">
                <view class="function-item" v-for="(item, idx) in functionList" :key="idx" @click="navigate(item.url)">
                    <view class="icon-wrapper">
                        <uni-icons :type="item.icon" :size="item.size" :color="item.iconColor"></uni-icons>
                    </view>
                    <view class="text-wrapper">
                        <text class="title">{{ item.title }}</text>
                        <text class="desc">{{ item.desc }}</text>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { index } from '@/api/user/index'
import { navBarNetHeight } from '@/components/navBar/index'
import { useSiteConfig } from '@/stores/siteConfig'
import { useUserInfo } from '@/stores/userInfo'
import { fullUrl, get100vh, getStatusBarHeight, onTabBarPageLoad, timeFormat } from '@/utils/common'
import { onLoad, onShareAppMessage, onShow } from '@dcloudio/uni-app'
import { reactive, ref } from 'vue'

const siteConfig = useSiteConfig()
const userInfo = useUserInfo()
const state = reactive({
    contentCount: 0,
    commentCount: 0,
})

const functionList = ref([
    {
        icon: 'shop',
        title: '订单',
        desc: '查看全部订单',
        iconColor: '#409EFF',
        size: 24,
        url: '/pages/user/order',
    },
    {
        icon: 'star',
        title: '收藏',
        desc: '我的收藏记录',
        iconColor: '#FF9900',
        size: 24,
        url: '/pages/user/collect',
    },
    {
        icon: 'heart',
        title: '已赞',
        desc: '我的点赞记录',
        iconColor: '#F56C6C',
        size: 22,
        url: '/pages/user/liked',
    },
    {
        icon: 'eye',
        title: '浏览历史',
        desc: '查看浏览记录',
        iconColor: '#67C23A',
        size: 24,
        url: '/pages/user/history',
    },
    {
        icon: 'gear',
        title: '设置',
        desc: '个人信息等相关设置',
        iconColor: '#909399',
        size: 24,
        url: '/pages/user/settings',
    },
    {
        icon: 'info',
        title: '关于我们',
        desc: '了解更多信息',
        iconColor: '#909399',
        size: 24,
        url: '/pages/user/about',
    },
])

const navigate = (path: string) => {
    uni.navigateTo({
        url: path,
    })
}

onLoad(() => {
    onTabBarPageLoad()
})

onShow(() => {
    onTabBarPageLoad()
})

if (userInfo.isLogin()) {
    index().then((res) => {
        userInfo.dataFill(res.data.userInfo)
        state.contentCount = res.data.contentCount
        state.commentCount = res.data.commentCount
    })
} else {
    userInfo.dataFill({ money: 0, score: 0 }, false)
}

onShareAppMessage(() => {
    return {
        title: siteConfig.siteName,
        path: '/pages/index/index',
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.bg-image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 320rpx;
    background-image: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wgARCAIABKADAREAAhEBAxEB/8QAGwABAQEBAQEBAQAAAAAAAAAAAAECAwQFBgj/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD+oBZJItsgAmgAZAAABSGolQAAFAhUjRGiQLZmgaZlA1WQiVYjQBC1kACNVkFFSBYFAItFgCkBQGaFBRUoUAEABC1AaMgFFBVAAAEShaAAAClABoyzoAVboAeTJYpmGhAAChICFAIEqwIAAAAAAGgDIoCwICgEAFiioQAAAAAApBVLChAIoFShQBQUAAAFACFAApQAAAAAAUAFKAAAClZAKkVdaAV5MAAACEBQUhCwFMrSFsiJasAuQEAAANEIAAAAaMgAAAoIAo0hYTUQULWQAAAIpRUKAKVCgACoUAAAUFQFAAAAAFAAKUAAAoKhADQFpbaL48ZAAAIAQFBCkAKICpAtIEhaRABSApAAAAAAAAAoKFhUAABYAVAAAACgAoA0EKABQAACgoAAAAAAAKAAUoAAKVkApQALoFo1J4pEoAABCAAAAAAAAACCgliLSBSEACgikBRUANGQKARS1kCKBFpWQAAAKsUAAAVKoAAFAAKUAAAAAAAFQFAApQAChKgANAAWrbKslEeJEtIAAAhAAAAAAAAAAAIoiC0ECgAjVZBQQAAFikoQpAIoAFQAAGjJakaAAAoSqAAKAAUoAAAAAKEBQAABSgAFKyAADQFGlWJZLKB47lBYoAAIQFBAAAAAAAAABFFQAAACNVkRQBUAigFBBUBRFJUBQBSKAAAABSoUACgABKVQAAAABQyDQAAFBQAClZAKhQKq20CSiAKeO5k1UKDMUCKDIBoAEBAAAAAAAIUAAAAjQgAKVkAoEKAEoBFKSpFKAAAAAATQCgCgAApQpAAAABUBQAABSgAFAKyAClVRasS1GVAKaB4WQaBkCFIACBaRTIKQAAAAAACLSBayAAIsUChKhSACkWrGTQAAAAAAAApAVBVAAFCFAoShQAAABQGTQAAoKAACpUAANAC6WkIQiihSlB4WQUEAAAEKQBqsjK0ESgEWkQGjIEWhAAAUAsQVQSoWLUFQCLFAApAAAAAADQAAAAKAhRShCGgAABUABDQAGgAAEBKCgANBVoIsUAFKUAp89KgAAAAAAAGWhUAqQLFrNIsUgEKFFZi1I0AAAAAABUEUAACsligAACkKUAAAAoACVSVQZBoAACgBkA0KEoUAAhktKAAGhaaIZClAKCgpSnzipVgZAAAAAAgUCLUJSLFFSplSgVBFGmYpI0BUigAAAAAAAChKAohSAApCgAAFAAAKgqGgZBoAACgAAoKAAIUZoKApQBaUEIFKUFBQClB89KAQFIopAAgBABCNVASmWhUqZUoBKhQBAoGmYoqZaAAAAAFQVQAAAQFABAUCgAAAFCAVQAAAKQqEBoClAABWQKAFBQqigyApSgGgCgoB4EIAACkAAKIEBQSFABCNVKsSKAKlQCBYoFZKKRI0SlWApAUhQAAAAAAAAAUAAAAoKghVAAAAFCFAFKAAhBoABoAXRSEBFBSgoKAUoAB88rIAAAAAAAAAgUARRSFCRYVBUNEgIFFAKQFAAAAAAAAAAAACCgAABaEAoQApQAAKhDQAAoKAIIspQpQBaUEIFBoAFKAUFABQfPSkAAQAAAARRUAilAAABCgAAAAQoAAAAAAAAAAABUBQACEBQAWlAZBQQFKABQEIaAAoKAEoSFKFKABaUyFKCgFKAUoABQAeABkpQSFIAFIIFqEAjQAAAIUAAAAAAAAAAAAAAAgFUgIClAABCFLSgMmgZABSgCgIUhAaoKyUFFIhKpKpQABQAClBQClAKUAApQQp88hUigAAAAAAEpFMlBAaAIUQAAAAAAAAAFZNAAAEICggKCikBQAgqgAAAACoAQFIaIQ1UoQA0ZFIUrRCgCgApAUoKClABQUAoAAKfPBAAAAAUgAAAAAAAAAAIAUBkGhCoQGjIANAAyaBkAAA1UBKFhUBQUAhClAFZNQqAEALVBKoBCFBBpQUAAUAFKAAUApQUoABQAAUp88AAgAAKghFAAAAAAAAAAAAAAAIUAAAAAChkGjNAAAAAAaAAICigMgFIUENCpQEKUEIBQVSgACgAGgAUFKQpSgAAoAANAp84AAAAAAAEKQhQAAAACAAAAAAAIQpCiqQEKC1kCLFpWQCkAAKAUAAELUAIAK0DJRVBAQ1SM0AoUFAAoABSgFABSgpQACgAFBcmgHzwAAAAAAAAAAAAAAAQpGTQFIAAEAKSoUgBSCLUEWKKVkApAaBCgCoUyAWLUICkNUoZANACgjIFBQpQBQAUAFBQDRCFKUFAKAAUoKMmgHzgAAAAAAAAAAAAAAAAGQAaIUAhIUBQUAAhI0SkWFKgKQoFACAAgAEaAqVDVQpAQFLQUGUIKUKUACgAFKACgFBSFKUAAoABSgpQQHzwACAFICggAAAAAAAAAAQAFIUAhAaAAAAIACkBakWoIoFQFBCFIADQAoBQgBaVCgAzAtQpQABQAUFAANFIClAKACgAApQUpSEB88AAAAAAAAAEAAAAAAAAAAAAAAAAAAAAQtIVkpYChAKQAABRQAUBktUUIUGQDQAAAAoAKUAAFBoAFKACgAAFKCgpYgofOAAAAAAAAAAAAAAABCgEABQQoAABAUABAQAoBCxaACkKQAoKQFAAZpVKAQgABSgAAAUAFKACgoIaBQUAoAABQUFBQXJSh80AFBAAAAAAAAAAAAAAAAAgAAAABDQAMli1CAAtWAAAAAFBQAhC0LQAEAIUVIA0AABQAClABQUoAKUAAoAAKUAoBoQhoB88AAAhSAAAgBSAAAAAAAAAAIQAGgQAFAAABCgaSKIAAACgFAQAlUtQoBAQApQSgigUAAApQAUApQCgoAKAAAUoBQAWLDQAfPAAAAAAAAIUEAAAAAABAUhQCAApQRIoAFBAAAAAAUAoAAQCqKAAUEZBQKRVUUyAAFAAKAUFAKCgoABQAAClAKAAagKAp84AAAAAAAAAAAAAAAAAMli0AgABQyWKASkUQoICgAFAAABQVkFKAQCgEUKooBFgCAoKAACgApQCgFABQAAADQAKAClAKUHzUKAAAAAAAAAAAAAKQAAMmgAAAQoABAUAAAAAFMlAAFBUIAANNEhChbG6wDRqrHOkCkABQAQoAKCgFKAACgAAAoKUAAFLCgNAHzUqgQAAAApSAgAAKQAFBUEUUgIAUFMlKhYUGgdDkQABIFhUhVqFEABQEII0TZpdFiHUGSVQUybNRYVTYMkMA0WuZyIU2aIcwClAABQClBkFKAUAApYUBoAHzigEABCgApAAUAhQADRSFBgpACEIaKQpEETLUBo2dDIBzNFKZMmzRTBTZyIIArKhGuKcdBY0aN5uqEBSlKaOpuBDRa1EBYtbNmK4ghs5nMAApSlMlIClKQhoAFAALFoDQAB84oBCAyaBDJSmDBo0AUyEoUbNlMFIZKUhSEIQgBpMGUNUFKADRCFKZSFNGjJSkWG2TQrIhDK8zmZsBbKKVKF0UoNFKnDU1ojBuMnslR2WkIACEABQCgFABSAFKAUAFLChSgAHzwAACAAhDQMkBS2czNnl1OqezG/pS+c4GQQApCkIZKUEKDJEoXJkpooBSgoZCABVBBLaEKAWmSAgNGDJTQKACVxsxc87Pq514LM17M68qSzdvtzfRm4ORQABFEWlACqQAWJQpQCgApQAaAAB88AAAAAAAEB59Z8O8942vDU9Gb9rnvzn0zgQwZOJxQepacjkZKQhQUEKCEKIFoCkIUBkAGiFEABQUAAApSAHl1nNiPZL1M1qXw6mjoeCznZ+g578deK5xXaPv43xNHnMAFiVYxZxr2ywyDNmpaCiJQpQUAApQClAAKeApY0QlDJkAEKKyZM6zyufXNe6X51nk1Pfi+nN8de86TcZ7GjkeIp2T0LDJyIczzgAAAAHGzzanoj3zXmPQcJItCBKsBQBClIIFAoAAaWJ5dZ8esyyr9POvoY0ORK8us6MHj1ODP1cb92dfN3nzWU+9jcjB6jmeMpk4WefU4Ja9Wb7867nlPn7zzs9GbivTL6s2QoQGoUBSgA0AAUHyDRpKaXpG4Gahx1PDubTtm+iB2XMvPWbLs8Op9zF+fpwTy6npzfTL6pdg6GDgeZPoLg0U7GDgcTkcwAAcrPNqSz0RqXZo9WdePU8tz9TOvBZ618idpesc9TJ3zrmCkAAMVlPVLDJDlc+bTy6zDqbMr9nF9edYPHXePmbxxs+vjfg1PDrPql+jnXmrzM2vRL7s61HHT35eQ8+syOWpzKvul4HaOZmzy0TJmh7M3ou08laMnqy7TVIUoBxOxoAFB8Lee2b7ZeZQZMJiuep5bmWe/OvdnfCzyp9OXzJm3VeVPXH0s6+XqePU81z1l+jnXWXnZ7sOVvY2eQp0OZ2KbPKdDJzBs5nl1PHrPsl+jL840RMmq6ZpfPcl9kaXUcynn1PVLiOaStriBDlqee5taJLQeezjZlPVNemXlZwr05fZxrK1PDqdV+brPJn72OnNfnazDnZih9rF+VqVfXl0lH0JfBqcTa+rM81ajpp1l8qeeyWYUmZfcvmMWdT6GNebU1L3y1UOJkxZ5bOGplPqZ3mOZ1Nm17RzrjHKzqZOVcGc6cK5s+ma92NeteNny7PRJ6JrnZ9DOvJqc0w175Pnankrnc+vN+zjfmrxaz783MtOh2MGQaOZ3IczoeU+frPumu8YMWal6p5dIeazpG1plOZmkvvlRToefTyp7o8qcNMINFMnUyc65VhnBV6mV75ubOVYZ9md/TxqJ61+J0zqPNZk+3jWpfFXm1njZisnszffm/P1PPqZO2X2sb6HGzkvWPPc+bT0Rxr34uLcnKvZl47Ode/N8up5rPXm945W6Z1NdDgz5tONcrJUSR9nG+VnkrJAfRxrnXmucp7JrnXluVd5dR7Jqxs8Wp87Wfo5uK4V9nnrmebU5pi3zXPOtR9fOu2bzPBrPsizXU4g6HQEMWeStGI7ml8Nz3X05ZC7Xlc+TU89nM9ku5bG7ZGzlZg7mJc2d4i8bKea5zXOsiBmoZBU2vaORa0czIT0S+/Guh6JfLrPztTBo3H0MalePWeNc6h7s2ro8bHLVifSxvtG16ljgng6TjczN7y/TzrR4tSR0PPqeuX15vk1JBehxudy8q9EYl8m880zqZVHol92b4dTgmAbt7RuC8bO0Qhx1O+de/FVTy6nms9eb5LB65dL5rnhVOp2l5GbO+L2Xx6z6Y6TQwYs0Ytygwma4VuO0vl1npLs3L0OmarnZyrz2ZkleiX1Sl1luzw6z56hmu8vvxYvHWfNZEluTmDJEoUdinMp0OZqO0o9Gba86emX0S+HWeGpTJ9TG+acrPNZlaeyPJqUxHDSJoL0Ttm+mXrNeXWfPrMlq9o86TTJqLL7D6WNbORDlZ47PSvCzjZ6s3nWo5nGvoZvGoZs4JnTJ9vlug5GK5WYTz2aX1ZsXZLKM3GplMkriml6Rk51qkU6HeXUu4lI5WefU1L3zc2cbKVfLc+lfJZiqdI9uLtqHWNmTnZ5bMV6I7S8KycNZ41I6FpH08a0vG582piskMmQCFNlMENGQezF751x1kQ89U2WzlWTtm09U1GeZteFmo51nUwc0FUWT3zfOTB7Jrlc8ynHTFkIDrHfNyeyXFvBOdmUGaxXXL6Wd7jBDqU5V5rOKY1Mx9LG4YsyQltk0UyYqmUwCrpIF2VMnNSYq1zTB9LOu8uItc4zZy05J0lydo7LxTjqczCat6xY6mVsWqal52RdyczFmaGUxUKAe/OvTm8TlpEyYsxUjIKCksyDJo9MvXNlmSnnOWpKESqQtj2516s0ZPPqc0zWEwKAh0l9UowJO81LOdZs5mCJC2iG8uy9I7LoyZTnRLNdYGTNZTlXdesYskcLYRKdE6zWjUaNGSEMkICEIKgoYOVzk7x0OudeaqeiOdnGodV9WVOQOepxLHRYmbONF6xuXizy00erN6S87M1owcklDUvWXNajoU52ZEEV0mukZMkM1i551kHpjedYs413WJwsyDodI5nOwbl6qjS7KSTlphMkshF7TXsy8epzPTLlKbl8+s9Gss7XBgyKsemNrgHWKQwZM2c6xZg5VhISzBDJ9fHQEEQ1pnc1oyYMiyEMmpep0jQrBmspkibItBmVRBpUUBIFIVI1cISqUg1CzJFwU7R2l6GjBys5VkwYKdD0y9otcjiUpEwcqp0zdaEEMESHRdrJIsBVJKhYliLaKWSVzXYIUpEyiXqtMApKyylpTNCHNC+iXRqMmianmPJrPLU4kQAQUiH6Hns0Smk2VcGFhCAMyUZtgk0ooKgq0ySspgyg6L0l2UycqiAQFlpUymaFBpesvSBCVkiRYEhKwaXRuNFBCJhcs5qVqWll0arUkXmcrnS9JaQ0UwYsyRNzWimGYarS5BSRkyY1IJeh2XcbKZiGQc9OaE6Ri3Fmpei7iJ57Odnn087ImkihdFNAoKfW59KyWlQVaVNFWhObWZIatyeeTlWdTBhNL0jrL2Op0lqYOVvMxJoVopTCZIRYQhUq7l2W5gXKZXKZpG16L0iGLMGSESEqneX0S7jhqcUFBqWVIgrKSrGza6lpTDPDV5JDZ2jbQ5M8NNHaO8veXRyOFc0puWgySiZMlNFIQyaAs4nNManOuSU0u40aWmo0KhCEihR780EqkoWgppKtlpqKaKK5HJOdZTBCmirqOhpdBIvMxZJVQGQgQKJaLM1CGUi00hdmpehsCOFcrMFTS9F3FIcrMqKgGUlI0pMitRV2vSKYThWLKI0RcJxrlplNG43Ls6x2l6LohyMWEApCAhmoRBDnXGyFNGjRZYSoRIQBI1EAAV9XnsApKhaVBVJoppqmstFKUpoGTjXJOSc6waNGzS7Ny6iVDJmspkwYMk1MkiUKak0u40uimilMrIzUSHnueNmDVWKaXS9ZNrK5limoqkoWEIgyDJaEAABQIUgaLQwczFmE56ZiEAsAGo2aXa7igAgMishmAhCEAAFfX59IAELChBQVaaKaLm6KU0UpSlKAc7OJyTjpyOVc0hEzWDISVAIUypapo2ustro2uzRuXS6NmU8dnOzknKuZLLAppdxo6L0ja9I6LsoWAyZZyQEIQVIgoAQhglmE5nOs1lICFBSrToay6Go0VdLSlAIQyZSEJplIRMkIAAfZx0hCkSKIoAFSlKVKuoGl0agaBopQUFIIlSuZzTBizBisGLOZizBzrJZFajRoq6l2zqa0uo0aLdaTUukq6RWIxUkyZrJkICiy6QaNGzRQZMGCEM0oSASBRDNkOZlM1CFKalps0qKULspYqVqluQlgMksyQlQyRIZSEUKh9fG4RkQjUIABCjNhVKVaaSrSmpbFKUApQCAEBAQQoCAGbOZgyZ1MmQRIAVaUpYFBVLQAAVBQEFAUEAEBkEBBQhCEAAAKCgFgVoAAChIpAAAAQQApFoQWh3moQhEhFEIBCgkXJaUFKpNFLGlFihaVBFoBACAlICgIKAoQtIUAhkykMkICFCxkCghFBBQUFUVBAAACUhUBACCIKCBCChARIAAQAAAChFoIUgQFFAB9LOoQhGYRqAiRYBkRoWsgChaVBQFAAgBCEUAEhVAAAAApSAoBUoUUpSABkGoEikgAQQEIQAgKCCkAQAEoAAQABRIVEAAEZAhSAAmqgSgAAAQFH1MahFhGYRqBmKSEUoBkAAQAAgAAAIKCUAAAEFIVQICgAFSNVAUUhUVYKBQEKKAUqEFAAABACAgBACAhVgqAEIJJSUSwIAUIACEQUgBSAAhUhKHqzoACAAEAIUikAAgACkVJFICgAAAIUFkjQW2AQAAAARQKCAoBUKQ0ZNEFAUEKQUAoAQAAUAAABQUVk0AKVC0hQCAIWAgIksEIQyRBCkACQi9pQAIAACAFUgAAgWoItSUhSAAtBAJAWQAFRFILQAgKCAoQqWWEoUAKgii2JQogCKKBSBQEABaQFQAQFUEANGQUUFIUFUCoWgFKUFNFBQQhEhCGSWcoAgUARAAUEAFILUgKQKCAAAoWAAJSCSgQFAAAAFIAAAACkAAABSFIACyLRAWRalAAoIAAUhQAKACAoUAFIIpVBQKCgpQCgoKUoQeJBAAAhYWwARQAASyKKAUCFAAABQIlUiAEBYAAAUAgAAAAAAAABQCFACFEKAEBQAAAAAAKAQoAAKAACFAUWQpaAUBRQUFQVB5aEQWAsgUAAAAAAVAAAELYCgAAAAAAAAAgBQAAAAAACFAAAAAAAABQACFAAAkUUJAtAAgKAAAUAgBQIFAVVkKCgWkVBSnmsAgoCRaggWgAAIUAAAACFAAIAAAACggAKAACBQCAFIAUgKAACkABSFBCgAEALSICgUAkBVUEgAAAACgAgKAUFAIUJA0LFBSnn1FMlQooSFAUAgAyACkAKCAAAAoICggWoBVgIlUlCApYCJVJSBYCoWggKhcgAoAWoIoBIoFIhRoIMgoUChYgoUCAIIFoIAAApAUAoAAIWQULVHCxViVIAAlWgABAUCAFAIhQAAAUgoIAAAUgC1IUIAWAFIUAAAAABQAAACFAAKSFAMmgFIIoIWggKAAApCgAmVoAIAFBSAFIAUFAUf/8QAJBAAAQMEAwEBAQEBAQAAAAAAAQIDEQAEEhMQIDAUQFAFFWD/2gAIAQEAAQIA4jrHEftiojmIj9UfpjrEUPQDvAHkPOOsfrih7R7R1iI5HYDxH5x1H/p46juP1R0jvEfw44jgfsjgeMR+ceER7wOo/rD80RHQdQZ8BzHuPxxFR3A6D8Y/jRHWPIVPgKgeQ8B/UHUfxoHiOBxM1PM9Z6j8UAekekeMUOo8Y5HUDvH6xzP5ByOI6D3HrHoPwR4x4AR4DkfpnkeY7x+Qfhgew/bA5gAfnFRURA/JEcAcjrHWPQeQ7R+UfhjwHUAfkFSOZ8IHMfhmew5jsKio8I6ih6R4DxjwHiORQ/NHA5jgfw48h2iojwj8Y8R7ih3AHI6xzHoOB0HYdBU9hxH8kcj8Q/DHaO4/gjuPOeR+0eQoeg8B+eKjiPAUP5kfyYiPQeAHce4qOw7R7jgUP6Ue8eo8hUew8B3HaORQ4nyio9o/bFR+CPwDuO0eUdR7wOg5n8ccx+eP0RER+cfhHccjmOR5io/gRER3iPzR0H4h4x4D1HaOB4DuKjkcREREf0Y/nx+GOgqOo7xQ/VEVH54jxH74j8UdR0HQcCh5ioH8eKioqOIiI9x6xH5YjmO8cio6RA6DuOo7R/bH4h4DoP2DqOk1AHUdh0j2H/ihxH6h3HEUAO0dhyAPwDoOIj+THmPIcjrH4R1HaOBxH4BwP4MVERUcxQqIiIiOkcDwjiPOKiOo/JHjHUdh3jmP/KjtHjPMekdB1gdgPUesdY/tiojqPWO4HnHUUOw7joOg/VERFRER/HjyjrEeA9IjuPwjoB0HWP4scxzHMREeMcR4DzH4IjtHcfjHUfxB/LjuBUcCoADJbADaWi0UxGPSIqKA/QOB2HQdYiPOI7R+QdY1Ja+bXEAYxERERxEcDvKFlaVFQpJpVTOdAjmA3iG9SmRb/OGBbqtiiAAhLam+sUAQOkYYeg8B3mZmeZBqIBkGQeAMcQkoIiOZzSqpipKi5uDwuU3H0788swuYmQQMTSTR8JXRoLDgdDoe3b9uwOB3YFhxDu3aHg9v37tweDqVyqsVJSggr5yC9mwOFfEzQIUTU+Y7DrjFAREASU0FZZBeclaKiQRWe0O7chUghRIGGGMAglU0OAIqQqokLLk1IVnIrKQe0GiFJxiIjgVIIMihxJvYQ2h63oPpcTcbd+7dszCyekeo5HUdB7RERFRhrCAIS468C1dMMlpdiWYxxxA5jHACeSMQ3q1lI4CcMMQMQIio9ykthBaDQbLQa0hnTp1atSgHVsspp5dpTbV03bPPqtHtejuO48ByP4Tt267bWKrJw2TCqYuKXRaFkuyVbwhlLCrNVqRzEd8Y/FM+Y6Equ13lu0221brtbdu7pLTq3CChNy2UEWS4cCmlM9nHW7sNlHCnG1cDoOR1HpAQERrLRR3K8l2yLJq1m4WhlhrN9No+VJJKFOoKHgw4CaNGyFi5a+a7g3FqXKU6plVJoCo74hIHA8ipy9W5ONk0gLTkBchClocTX+bcuNuIUGCVBYKS41WFO3IuSpIYpm7KH2lhCi+bqyBBEUpSFDqPMOBe0OJKSFFcw6tdyxcb02qFtqunBTdXDrLaWn15Pv8A+eWroFpawhxxopSaDiktrorW0bZTEdVPrcRbJaskPu2vFwlh1bCmUIdDLUlkJDBHMRwXUPaUMFFLfcvVLQhLGBqwtcFFS104sOtC4ZItEIuXbhIdas70hBS4lV0w28+tFqu0YsXWLMvsIeecUE0pRoIZvReLZWdSWmXQIodF3U9s2GPiNmLXRhmXlvHi0tFUVtqShCVFTqRZhZWHlAbP84uqaulOEtPqbdaZU6hp0028tBpNGipL1LYcQtq1/wA91pDbtN0ltRadcpVs1dbW1rS00tvJClu/SHi5PC1loW+Mh5V6t+aYszSlKVYKXTLty2y68tVRatvoat1qoqbWKeYYfReuuWTwVdWqHm0uJJRdoQsOJo1jgRZhTbyLF8h23ZeLdKJd+g3jl2pdMXTrP1Iu03ibpNCnCl4XguFuFCnVLpi1asYWX3f8sv3KwltxuzDZeeccVRNjapQ8F02EUukPpdWyhS221KDbi6AIeKl2rZQbfU2paySFusvPMNN61tItFNsoXSFZOoQ5TjShMhzbsTdKfLhdK6SgMEpfUoqqxKHqTT1PLJQsOnh2jR4sS4l1sgmzIUHnbdtLVOBSwpC9aW3EGgy6WFLbW0wCppx1ttwqpYUlQiDQq0efZFFcMXOaipSA3Tl0o6W7JqyIQMn1EWBuwXGqcSgIpxxRNN2zKQ64lCW3hUEBSXNtEKWq7LjdwLhbj71uNu4XFLpbzjrbaCm8acINOltbl0y+p1S2gtOa1qJo1ns27SugKQ2VqWG6JqLZAJply/ZTSqKLV5VLLgIUEpaQHXnFUqm1Jv2rnNDhS8HKK5Yu0XBW8GLp27SUiH7VCsXKyQtbiHnG1CIjFlxxSwojgOotP+ebVTDbJOK3rZW0E1cJU2CukLaeNyq6L6Q0oKdQikAqcZYoUFLcQ/sLodUstgKet2nFKdUWFqLLS6LSmVWqmQk1bMuJbUhRW43mVAMvtEKeSRNEVB4CYptEktgklCPjQw2XHEXSHkuutQ5TAQ6qnAQttguUaBNKIoUKS606m9C3UkQlpYqaACWL5t6lJBK1qAfS06H3HEMLtsWm3bZtSqUmjQQFkmiopU4qkW4oLKt4fzUCYVcFaGIJkJ3ChcNuyF7DS2lsooBRUtCHQltTiyKAQy2StLqFVkp5x0NNFSgtTy3DwHC60hi0W0pKhERGOEUEJSaNY1MW6SpwNh2gC63cKvC8XEPIdQC2G7httCVKFKrGMQkUgKYQAVMFrJVYxiKbWQ06HC4pZEUahhSaAICwclsKaUkiA4VbPp30GAwWIxkjHWGgjWGQmDRTGASohNs0aNQpOa3hSVbUNanEURiGkNFCKcU2FIS9sIDUFJrDUUY4BvWEsXOSxlpNto1asAjDDDCIhLbbVSKIWYjGAjDAJYcHK2iCCMccahDIUSptpQokgsFvDHEJjFCUhNJRp0G0NmLdJFbC59ButrSS383y55wEJpLouRdC63zjFREVM1EQaICA224VOLQpLi0lAbbtUAqy2KSWktgQpZKGwjJbpUhLaqU4HhSmsYoAHANoUVEyHcgE0AUcEFsohKGxSiFpKiaCNaWdagRihuAtL23IpKYjGMWmClxKaQpbbbiklKa2AKZiISltRGIpLkkE7FPF6TcqvDefWbs3G4ucTnlgGgILRbipKshSSmsdRaKZoJFYis5mcwrKZyzyyyymhU55BIRiazNIaS0lsCS0pgpJJ2ZNtobCdarUhK8s1LLqVAxr1ETAQmo1YxFRjjURjgEwV5gYYip2G4TQZwIBJFGkpICjQouF5K0DPgUpxd6u9U+T2mpjEIAByKdWnVWe3dtJigrPIVOc0TnuL+QbSkGcC2TOU0E4YwV7dgczDiXg9lWe/fu3btxXgGxQWHvo+r6TcF7ONYaDQaCQ7vN4q83JfFztBBkkuF0EAAku7QsJ1BAXs3m42wGktpUHxd/RWsM6lUVBIWp8UlAQlSnTdK/0V3ZPQUEaBbfJ8fxCxmpkGZkKBBBKTb/J8uhSVXZvvsNwVJCaSUqSoI0G1NuWsAgAUF5miJ2bJxDYbDYbxnIrLmzMKTSWxb/OUVOe4v70lDCGzS6ImQayzzCyMAgAIDWGJSoFYcSU1hoWyVpUikpQjFQUISAAnDXgay2B7eLr6csAzoLBWbr6y+VABkW4tgwGwA5u3btuzbs2dJ4mZBmQQZFAkKsz/mn/ADDYFgIgK2JuBdC7F39JeNEVM5ZZZ7NmeeeVa9WvSLb5wyEAhwXH0F9SCxoDAYSyFby+TARhrI3/AEh4LmAnAJCg9vUtSNQbxFbFXCnzWIApJStLqbkXX0m5L+yYic930fV9X1fX9v3KvCuA0GAyBkVTMzMzPaI6zwDQIIIIIIIIPKmlWCv842BtqBCgQQQY16DbG0+Ysmtn0fX9v2/Z9ovBeJuhcB4OAxjjjBMqWq+Veb9wf+gXKboXQfJ+f5BbBgIiMNevCI4mc8888weQrLPIK2F43RuzdF/bszyyykEANhkNBMY4444xEREfjmaBBBBBkEEGZkEHiFW6rBVgqzLanje/b9ZuS9snqOARQoEEKCgoLCgoKCwpbav8s/5ZsDbmp5BCwsLDiXUuh0Ozhp1FooIxxxwwwwwxqc9pe37y+XSsqJ5jgJDQYDAbACQkICcMccMMcSnGIIiO8RHhNSCCCCFAggzIMggyDMzyQWTaGwP+af8ALP8AlH/JP+Sf8s/5xsy1wOAaBFAgghQUCFBQXsCw7sKfn+T4f+f/AM//AJ/w/F8ujWKyCw6Hg9u2mi2WdOjRo0fP8/zfN8/zfN8vym0Np8vyi2+YWvzBgN4444hISBEAREY44YatWnTo0fP8/wA3zfL83zfPHvIMgzIVOQUDMzkFZZZTMzMzNTxOUlBtfi+A2HwfD8mjCgQZmcsss8888888888889mzZlMYa9WrVq1ateGEY44469evVq06dOnVr14RWWeezZs27NuzZs2bNmzZs2bNmzZs2bNmzbERERHEeMzMggyFZTlOWWWWUzMzUzOWWWWWWUzNT0KNRZ06dWrXhrwwwwwwwwxwwwwxA4yzzzzzzzzzyyyymZmZmZmZnLLLLLLLKcpymZmZmcspmZmZyyyy8I95nLPZs27du3bs2bM8sspmZmZmcsssssspyyyCs89mzYF55TUY4Ya9evVq1a8MMY85/FERERHEdoiPOZnKZmZnpMzlMzlMzOWUzMzMzMzMzMzMzMzUz2mZmZmcpyyzyyyyyyyyzzC8889mzPLKajHHDDDXr1atWrTq1atWvDDDHDGO0RERERUREdYqOJmZnKZmZmZmZmZntM+88TMzMzMzMzMzMzOUzMzMzMzMzMzllOU5ZTlllllllOU5ZZZTllllOeYXmF7M8pFRhr1adOjR8/zfPo0acI8ZBmaniZmZqeJqZqZmpofwx4zNTUzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM5TlMzkFZBeYXmF55zGvT8/zG1+T5Kme01MzMzMzU1M9J/rj+BMzMzMzMzMzMzllllllllkFZZZeszMzMz4T4z+me0zMzPM9p/JPWZnvPnMzMzMzMzMzMzNTMzMzNTMgzMzMzM/nmZ/aO08TM+8zM9Z7zPE1NTwDMyD2n+nP9GeJ85nyHqKnpPSanmZmZmp7TMzMzMzMzU956z3nmZ5mZmZnmamZnmZ8pniZn9EzPaZ/JPeZniZ/ZPvM8zwOJ9Z4nxmeZ6TU8jme09v/EAD8QAAIBAgQDBwMDAgQFAwUAAAECAAMREiExQRBRUgQiQmFxgZETIDIwU6FAUCNDYsEUYGNygAWC0TNwoLDw/9oACAEBAAM/AP8AwBt/4K5f/oJNf/zdDCYYV1EMa14eBBIPE8v+XD+gTGteO3lO6bNnHG0O44Xhh/pBEEUwchBF5RbRSbxSIJbQy4t9oimJBoYg2iXvhziEHKxi9RnJoo1vEji+Ei0YXBHEQTcfoEwj7TGjcv6ocRB9wgP2AQQQQQcFgMHKAwbGAGxMXY/aOAgg+xRvEg2luAg4X+y85wQcFMSW/Uck20jCNDDDwA34GGGEQnisSLxtqQJ5Qnb7RwJNzBwtD9hEMMMMuPsMMIhl/wCsEH2GHhbgY0MMCqSSAI70vqopK6eY9Y3Q3xPmGCAQQW4X4kQy8HAxoY0MPBYg2inaDlB9l94RDCI0JjRo0aEwwww/faNL7X4GGGH9QKLsbCKuiEgbk2na62o+knJdTEpAuwufM3vHu9mIsNNiZUrswdybaDSVKJ1LDpMLURWQfUXy1EQsAL3OlxaFdUI4GGGGGX/to+w8QeBHAb6Sk5NnBtKVNcjiPKNWYu5ARcz/APAn01IQZbLa8qVCK9a92swA8NjKNdblb+ehjC+BwRyOUqrrTPAQQQD7jCPuEBgglofsMMP2DgP6EGAcAIM5uIeIg5wc+BiUxd2C+pjVDg7OhY6XtCLmoSSBreDHjI7oIEshM2ByEUVTjyDZQ0e1W2OkKsfmNRa4PdOoiY8VPQ52hqp3bFx+dNtCOcWoCFBVhrvaMAe8G8h/fAt1pLjb+JWq3FRvYaTtFWzYAo2Zso1K5dwf+0QgWOQG0u4rPschLUp9OvgOjH4Mym41EpVkxW+MpT6mb3tGFzTYejR0BLOsYnChUnzvKuOz1F9AP95TvhdbX3vBclH+ZWGgDehhU2YEHz+wfoiD+jHE/rAAksABuZibDS0Grn+bQgf4QB8yP9oa7OXc3AlV0sQA6/DCIxOMk28N/wD+JlHMBADERHXCFa8JJTa8tRpUxv3jLU8C8Dig7R2RH8Vr384SouLEZGWHAp22n5m3zBe+4jUz9VbsB+Q5iJWUOpseYjpqMuf3pTBLGKzkMpA23zhZcSMrgx11UjiiDvOBBVBKG4/qhFg5xbaxZfeEQhb/AKCA2vc8hnKh/Ds1VvUWna6qnHhpjli/3im4+pity0Eo0TiK3MsnBqr3AuBHpk4wRfaKQUls59eiDi765Xl/Jt4yPcaHUS2Y0l58TBUuJ4hBUTzE24K3dZQwO0VrmmxUciLznU+BHQEjvD9SmmV7tyEr1iVTuA8uXOYajtuLKPmD8jnMGAOgAuLm2ogK3T4MCmzEKYDexBtxO/6QH6oUXYgCU1uKa4z8CPWJNQ5DO3A2JIsJho/WU36hyEG0xHGmTjXzgfI5GFSTLm8umDcC0MtwsDSPqP8AeCslxrLE8AldGbRSDMsQgsAdJ/w7XB/wzqOUDLzBiMNM4n1MBJBh2ztwSn3VszfwJWscxp8Qs12NzMjaVqa40Yi+dpjOCpkZSfUZ/ERdWf2aKLhRHV+4SG8pVtZ3v6yqL2b5tBWxM1VvqA/jfaDcWO4MseKoCWYARWAZDcHcf0oiwCAxYpz0lKit3a3luZVc9wfTHyYKRLPdzbcyrXJFHs49dh6xLD67F3Ogv3fYRA4RBc8xkB7T6taym6p+R8+UBXDoL68/SfTp4nsq7LC5DsPRf94ESN2rtIQ6HMxEpWQBQJZ5hGImO+QNhDSpPUOSmL2isVwHu54xrLpqDAwKGFDcRXFjMiRO7Yw0K9xoYHQEQA4WlxcHOEXBm4gEpVLmxU81g8NT5EqrsD6QjVSPupIM2v5St2i60wVWHEEAzgo0GYA3OUzYkQi4WMUIfQ7GAKAugyhMahXxC9txKNanipd0mV6NS4UlhodY1Sl3gEqjcDIyujkO2R5CKULgksOecFRCH+ZWw3SriE7RexpBveMUuMjuDCpswIP6FJdagiO9hdV6mhIvTdag8pWcGyR0/JSOFKne7XPIZxjlTUL5nOM5JcknzjObICxj7m0VNBeYo/ZaRNR7l7dzlBmy6zGDY2cS1SzCxn+HihLEgx0fGLYhF7T2cVE+POW4Or/WGSruYikuGsNxBVucIEx1MA1ManqtoKVqVa+DnygGYIKtncQOpRo/Y6mFs6ZiugZTcQsMa/kJ9SwL4Ko32MexR6K389DKdemWpFkYaqcwJWXRcY8pVqVO+hSnud4KXZ8CAACEVjTt3TBclcjKlOwbO0+pwCXNs4zTKOLPYjkZ2gdwkOPPUSg3cqIVB13Ala2KlWLLtYztOIFzax0F7H1lKt+J+jV5bGdo7OxurWPLT1hqD6bvhqjfUNKl7Otj/BhH3UUYLiuSbZQDU2+8kWRb+15WdgXBRNy3/wASiy9yqQfPOVF1ZY37glRfEpjgEkqBzvE/cX2uYBp3pUKmxCiAm+pM8rxai46n47DSKlMqqgZZWmQY6YT83lSpUNKjqdW6RBSoYEn+MW0An1alluRvBSBBXCfkxu01Dc2RczFo9owDJWFpZLy7k7S+UvC6hcXdGQgwMFQ23eGmxZDaBqoBGEzLMiWOJTnA3dMDZ78CndMDrLNge45QiC+E5NA484UMxic4R5wHUSi+qiJngPzKg8fxCzaMxgJx17W6RKX0Siooy2FphrNMWU+mhn1HLGFclgtYnOJoYmsek2BSH5RtWHxFb8TY/wAxWU3zEwsSuhlrxqT4liuuJTLC20Q3DC4lIOLgW9J2dtGCxf3FPD1jAd2mWM7RVN3VoRqhmGW3+JUXR2+ZWAsKp+ZUqfk2XLgSbDOYxjrd0dMRFwoABxC9psVuW0PKEpwLJjS4YbiDtCFH/wDqJl5zD2fCTnpwucO5gpdmWnvv6wOCpHeExs7Nnh284Tloo0HEpUDDUG8TtXZrjP11BhRiCJUoZDNekykc7MhEpV6JwuCRNUBGIfyIlQHYjWEEugnd+lVzXnuI3ZqoqA3Q6jmIpXEpuDoYyG6MQZc/TrL7iURUDg2I9oGWDjfgIlTs7UyL2n0q3lfKYWMKErpKdTJsjLG4jKfp1MxKZbEVAI3Ey5rPK8QagiUuZiDRGMrMTZsA8o7jvMT6nhSqUxTqHvWtYxqbXUkb3lVQRkTCyXwC428omeJGHpnKDePD6wNoQR5ccJylhmt4HJFNGJnadBSwjmxgvirVMRgAsqxze5A9ODVFNR7/AExKSm9rg6biAKABlMiY1im0zfKwjKxRVuecwkB3YhtYEpDCthad8v5QLQqPsDCztXbQGyCAJbUngWnvaCu5x3sBtoIKVMKuggMFIhgQY79nvVAxbQg3GYliLbx1yMRxYy4uhvCuTRXENsDajQwXIIsdZiFjqP5itfEIyHmIHW4hVdJWZtwICly7XlvMRXG8+nolhzEIM7suZlfWAHvkW5QVWw06ZC7kx8DOpuBnbeBFFziY7yoCStj6nOV6mRIEqocQZZ2rEQpPzcT/AAgXHfEswfRhuNDALkG4iNvYy4JtePQqXFyDqIlWni1vF2EtwtvCNzG6jDe8cLawmLa0Gd4sZvIcHe+EZc4B+bfEw5JGwBLXMO/G5dRbHa6/7iY0xD0YcpZ8QOUxJaHs/bmcC1jA1nBuDnwKVQwAYg3gqUVqocj/ABFrUz1CGn2i58WTefnO+fsYVcSsRBWFvH57yxtaxEIlrmH/AI1BexljhbI7NLZVB/7hKbjEm8aicLi6zCzURfCc1hW+E+0xZMLMIGpC8BrYb5DUxaiXU2MYGz/MI2EpBhjQsNzKWC6IIEJDgH1hSr9SjY/6TE7TROH+dQYWp4X/ADQWmHtGE7woLQPTyGKA6TwPGpm9u7AyYll734WhPEz69DA/5rBmVhpnEIobEoIjuhqXAA2lSg90zG4OnFRGrNYZJuYlJLKRaILi+I8tY9Qm1Npld6gWUimKoWJ5aSl9W/I+stku21tYFuVvaAz6c+qSSbKIDTaKrho9bCls9iIy0lDG5AmpEC06i2sDAAMWSroITvBvC2n8R38OFeZi0kstgAIG3lxcWijtN6mi5zHna3LzEKVf9JimMrEqLgwWvaFdGinJxEP4twQL3yPWDHhpDEdmlUpdnz8tIwNnOURcxUEpFbtaUV/HFn5Qqn1EYRLd42iAkYxKd7GIcxaYRkfmOL6Rm/Jp9R4KOhAEHeucvmFjkLJsWlQta4UcyZ2lPAhHON9LFeWBxNa0s4wGCqpDgAiU0JGNR5Q9JMC08TcCneXPmIrC4PEDMwwwQxj9gP5QKsJhIuTYQKMpfheVRUVwptMFUMLm+RmG7rYrAwsDAyiqBmIQGU+3A00PW38RqT2AuG1EKPiS6sNjEqjFuP4PHUS5sIKaWmBoKgBvfLPiUcMNQbiU2p/4l8QlOstsXzrMByOHz2MDZGwMGTLkRLgsDMjGw4bm3KWFpUpZar5yk6g4gL6XMSxGRERO+pA8iYlM51Z2Wr3bm/PDEFWyVASfaVUcVFBvuOYiVFvYw3x09R8xHGGp3X841GpfbeZY1gqAi9mEJXA+o3jUHurSnWW5Fj5SwuMxzEH2mjVDA906wMl+OfCq2rteV6ouSVB6jH1+qvxHC2FQ5baCdpfum9olEHducd7hCAN2mBtLtu7bQk4FYlRrD9TELhR8GLaxEAzSA3tk0LoLjvCY6oRT3RFoJHrMSBlzMWmpC3Y85WCDFa3IQAHEpAgsQq5RmJFsXpHNybIPkzs6A4gGPNhcyg2QUfFoACcZt5mIyBDUJI2v/vAniMDLYSsxvYlfK2cc0SHWwGQjBSC2XOG0AvfWIwIOR84hQ3NrS34WMdtEMe9r2vEOrNfzgVsK3b0ji64ry4+o/e5QILxne219IpXO+MbQKmHFhaVzkCtzuRlEW+Jc9iRDyJi4cSE2PI2tHvb6mR0JnaBooPvKozZGEZTdQbxye8TeYlLnTlCFJELJhaxIjJobr0nWB1texhW93WIt8IxN/Ec3NsIPLQwz6YsRiHIwPTJpkEcjMJsSbfyIRmNJb9K8wC+/AmXz4tUayi5jWOJ/iYCWZtJbPWWW8qB9bjcWgvde6eR0gqJgcZHKfTdgRlfIzvCWB3J3hR8R2iPRuYabYwbg6+nnB6g58GGogWriYZaekyhJht9gtwqqpXGbSqF0uP5htZ194HBZGxeUHA2vGJgWlbgYZfQR9lMakAlVCw57iJUQMhvARcRfEtxLLaxtEp374wnYxWqXRgIropxi4ll/MGCmb3lxipq0xA/4LAz6iXuVPLUSsm2Ic1zjA2sRKdaiLrZhvvHS51WELhOnEjgi3wqoPpBmDl9mM3bSAXVIz5XvLG7/ABBhttMJKmZXBtD4heLaxETyEVszAFKgACIMyb2myrKlTYGbub+W0GijKBRHY2At5ywuTcxhke95Q2uVUCAZNYxW/CHVdeUvpM8xFMvDO7hcQYLXygRLfFp8xnzc2HKWp2WYmgVbLCb3M5QmG4vhHqYVXPvDnLKW1EO+YgIJVoLWIBECggacosZrhchDa59pgYoPeAgwKTnBGaE8DYA2IEBB7kNVwoNr7mJTFw7X5ibGzeca1jYyxscvv9uF5b7AJeEx0XkJhFze05XtMIgKmxgBuTNgbCLTWwUmFgVNNSvIzMkIAIX1EpLTKlCPMGJ+IxRwuVrfMZtBaFXGMby6hxBgYbmWGE7aQfeL84lSnpaDYwo+vuICuZuDzim+HuyxziqMoW+wiWOZikXDAw02PKBxdXsZVG5jNe5P2mMtQBb23nOKYUMBJu1j/EO9oNDlEa5BAMcbXnlY/Ze8K7iAcjARbBMfgaE6UmEqAZUiI+hVoVUixEN72vH6THPgj57Qy0I8RhO5M5wDQAcbwjSO8WmMozQ3gRL7ngNzY85iFriMmxtzlt4xyCyo29oKYzNzHYmyiF83p2lhYGOt7r7zO4jHaDc3Md9BYRUPnCYAIrAi9oOdxCM0JjDWKwIaUjo1oNYRGF7LrvH0jnaPvYSwOfEngym4hIwuc+FxcGA9xwDFP4m0bZ44jiP0GHgdlj9BjcuHIQ8C2ggTzPAS5PA6CHO/2mAcCBZorb2MsLMLiZEA5cpunxDD95PetlwBmVxCLjhaU21Fj5Q+BgRHF7qYfuJ0vHHiM5gGU28AlLemplA+G3oZSOjMINnv7Rk/EAyqpsQSI1sriEXvKdiTFXQNaG1gnzHfy9I5GZIgP5C8p6WYRNnMbnCdWgMXkYo0UwL4Z5GLvcSnu0pHcSgemU+oReYiZ3YROoReoReoReYi8xBwEEHEsbKLxKQudYSfKZRibAw7mG0xXK2jDVCZVfRbRBm5vKaDugQcUbyMvveKOAlr2hO/C0wixMp9MY6ZCGECLbSIuRNjAdFha9iBKnK/pLE3EHC5zMQRG2I4FRYxdLzkCYfMQWs0O0JloCM4BfIGCCA8LcLxQOAUQls4MN7wTlCYZ1GIBkOB4gQiWiHWA6NMWovBBBwEvBe7GAplCphJzgl+8usGhlxkZYw4YREcZ5GH1HlwEEG8QC0B04EcFaNtHGoM8553lQ3ANpu7295QW+Zb0ETw0o2ygSr1W9BK/wC63zKu9VvmPvUb5jczwEEEYyo28YbwiJukXwt8xhsDCOA6Y2yR+dod3g5xTEM5cLbzzPADb5hl9WmEZEQ84s5AwwdcPVlG6o3UY+zSpNbmDz4HlDDPODnBsIdlMfpjHVRBOSGMPAY+wtKrixJtDwtLRSMx8ykdO7DthaMP8qVOiPCPMyo2rQ8UIIZAZqafxHp5OLes9IuxIh5iDcgToBMbxNB1T/UIp0UexjbIT6R18DCNHO0fojDaI2oAMa11s0fdTDDDPKeUH2iWlt4AM2mL8VJMJ/ILAASojTmoh2uJg1qARTrZoG8oxF1IMqL4YD5GMsuMxCIpl74WIlRYfFb3gJ1AiASmJ0p8yq3it6Q21zhF7mXGxnMEek5EiYASzqB5ygL+L0EB/ClbzJlQ+Kw8oTr+iOQi9IlPoEp9AiDRYBBC2jkR+u8fzMI1RoBrcesXnE5ynziRD4WnIGPsJVEfcH2l9cUXlFETqEU8AL3lHmIg/ECOb2sPaVG3aX1/kymOUQRDqBKe1xDt3oBkQR7RYNiIeYh6pzYxYvKINxKY3EXa5h6THjwjY8KZ1AMoHYCLsRLeGeRh4ecHVG2eVD/nS/5PeL1CAS2glpaLwvqRKR1UH0EpHQMIDs3yJfRY/IRuYnN4i+ctANTKY3JinSlf1lzpb0M5XjdJmLWkYvQwnkwg3vKW7SntczkphOrW94OcWUhqwEpbEmLsDFMJ0YRzqpMC/lTPxKcpymOc5CO29vSM2tzwTcxFiiKNjKbZMl5Qb8QywnRlMFzdSPQ3g2zjr4DKrXGYg8ZlFRqJSa4sfbKUm2IlI+My2jCONADE/wAwWlBCcFQ+2cbwID5tK76vbyXKXzP2k6XjnRG+JWOlJpX/AGmlfo/kSv0D5Er8lH/ulfmnz+qh1VT7Sgb9y3oYnhcj1zhHiBloqAlr29J2dOu/oYnhpE+ZMqbIoldvF8COdWJ+wznKR1SUzexIj+FlP8Sv039DKm6t8TmeDDQxxGEuLEAiLtcT3jDRJU6JW6ZWlQ6mHc/YBuIg3ESL0kzkkbyEbrnN2g5MYD4T8y+5HrH2sYyjvIRB1GL1RB4og5wDRTH2WVn3MbxEmWiAd5ROzdJHoZQ8LmIPHOTiPsVMq9MqjwGP0mP0x9hL/mVlHdpR2N/eL4QscxuYhHiEYbiVCDZlEAviqrE2JPtAdjB0CLaKZTO5ERLk1V94gJswMQ7xOsRetYNnHzKmxBjeKmD7RP2hBsgh6f4jdJnkeBhG0A1ijeKNiYdkMfptK22GVjuPiVG1cy+tzBbQwecsLk2HMmUU8eL0ii4Wn8mVdrCVjfFVaecY6XMqnwH3j7so94N6vwJR3LGUB4L+plIaUlgGgX4hh5w9UMP9MrAhlVvUTsr60F9sp2c/iWWW/CqD7WlQX7pPoZg1DCJ1iIPGIg8YiDxiIPHE5n4i+fxE6TF85TOq39pTOkXmYOqDqi84vUInUInOJziReRg5GDpME5ERiPzX4lTrWVOpZV61jnxD5jcxDAIg3EpiINjANFM/0QG4sRFbg0MG5lNZSWDZSY50WMePlwCataUxo14dlJlQ+ESpG3EGdxKcSL1TDo0Iin8lvKZvZmWK3+cx9Yn7g+InWJTHiiCIOcI/FZVbVjaEwwwwiN5xhzhHOcwTE6TBshj7KBKp3Mc6lo3M/MG5/mUvKUeayjzEoiUpS5SmNjE6TB0H5j7J/MrtowX0EZ7liWPnnGOixzsBOb/EpjW5iLoiw8TDD/Y6L/lSQ+07K2isnoYg/Gq3uJWF8OFvQyuutJph/IEQcB9iHVZSPglHkRKezGa2IMI5QjW0RdXUe4lEa1FnZx47+0obYjKe1NoNqZ+Z/wBL+Y3QI/SsqdKx+lYelYN0EQj8BKfSfmUuREp7MYvPgR4IemGBAS7BfWUxcIrP/AlVtCEHkIx1JPqY3ON1RuqNzjc5zAMU+FYjeJh6ZSmSSHNz5TlUBlQcj7yoPBKg1Qxukw9Jl/AYeRj8mjjUNCOqW6p5NB0tB0QdMHTPLh5QdIi8h8RekfEXpWDpWDkIPKDkIOUA2MQRBtBsojRoxjc43OGGGGHgx0EczmYm8UaD+53FiAfWdnf8qK+2UoG+Eunobyp/l9q9mWdvUXWpTef+pp/lE+ljO3p+SMPVJ2kZF7eqyv8AuztP7zSvvVf5lbeq/wAmPu7H3P8ATCLUFsbp/wBtohJIrtc9QvKwvhq03+RO1C9qWL/tIMrp+VFx7QjW49RB9luJh+znKZ2+Ih0cy+lQSpzUyp0H2MbdGi73idUXqEXqEXqEp9QlPqidcp9RlLzlEbGUumU+gROkfEHSPieQhjHeGH7jxJ0Bjna0O5tF3uYo2/v4OoB9pRN70U91nZTrQSdjN/8AAHyZ2PoYejTsuzVR7iUdq1QfE5do+UlbavTPsZ2oaGm3o07WP8oH0YTtY17O/tnKy/lSceqzmCP6A8fMy+tj6yifypUz6qJ2U60EnZD/AJPwTOydLD0adl2aoPeUdqriDav8rH2rIfYyt1oZXGyn0aVx4DKo1ptHGqtCNj9nnDBuAZSOtNfbKUToGHvE62EG1WH9wRutY3WsfrWP1rG/cWH91Z/1RB+7/ETeqZT/AHGlP9xviJ+6ficqo+I/7iGVOpY/UsfqWHrE5vE3YmUxteINFH67cjD0mN0mN0GP0GVOhpV/baVf22lb9ppW/aaV/wBppX/Zado/Zado/Zado/Zedo/Zf4naP2X+P7iefCkb4qSH2E7MdaCe2U7J+1b0Yzs+2Me8Taq3wI21Ye4lXrQ/Mrjwg+hlYa0mjjVGHt/TmHgDsIvSInSJSOxlPzibMZyeHrj8xKnKVORlTkY/Ix+RjxuRjRuUePyjx/KPzEbmsPUIOsReuJ1mU9yZS85S5H5lLpPzKfTEHgETpEXpHxPIfb5w84ecPPj5/Yf0j/bRBzEHMQcxF6hF6hF6ovVF6ovVF6hF6hF6hB1CDmIOqecvuJfZTF/bET9qJ0mJyaU+bROponUYvUYvUYvUYOZg5mDmYOZi8zBzMHVB1QdUHVP9UHOAbmCCDiYYYYf1j+iYYeBhhhhhhhhhhh4H7jD/AF4ggg+wxo0bnG6o3Mw8zDzP9EOA+zznnD1Q8zDzh4DkIvIROkSn0iU+mU+RlPziczF6oOqf64esRuoR/KPyj9MfpMbpMbkYf74vMReYi8xF6osWCCCD7RBB/ZD+mf6c/Z5CLyETpEToEp9Mp8pTiecp+cTziczF6jF6zB1Qdc/1Q9Yh6hG5iPzEfyjdMfpj9JjdBj9JjdJ+IeX6h/pB95/uQ/vwi9KxOhZT6BKXRKXI/Mp+cp7FonUYvXB+5/EPWI/UsqeXzKvTKvQZU3Row1VoYP8Alkw/3och8CU90X4lE+ASj0fBlHzHvKXU0Taofif9UfEPWv6Q/pB/yEP/AD6H9qH/AN1D/Yf/xAAhEQEAAgMBAQEBAQADAAAAAAARARAAIDBAUHBgEgKAoP/aAAgBAgEBAgDI+KG0VH9LHz4/o4/O4/qj8UX8Rfw0D8QKX8MMMXD8LKaPwyPxMx/6Sv4EHAPxJ/8AbKfPD+eD9Fj9hANg6AABQfhQUB99iAjD4we6I2iiekco+REC5M/wAaMURcXPMNDSPQHICMXIxmow9MQamHQKd/8ANzrGsxHQAwyLA+BEBbcUxhFHmiDSajacjmBoBpOsXFlRMxwVo2D1AFNvKcjDxRGO0xQbgARTQFNzcazkY6xQHkdQiAIwCnAwjRcjIycMY3WPUTj4zDYKm4yNJ3mnido3jV4BStRkZORtG8cQLjQACi4wwKijQNzjGkxuaAbBkQHEMjWcjZ0douMcOMahqUaORi07lR5F1i3SMniARbhpPCN14xRYB0C40KiouO4RwXzAYBcd4niGGzwbCKV1WngzkVGpcaLRq1Fx0cWlop0jI1anSOLtFNxTsrqFvkOMZNRivNqI4PI9wbuRcdY4gAByAPIUFmzbsuoFtlB7wMcjDwkf8QoD1mBRqGy6BhoABqAAUuhgFgFnANg4GgRB8EN15lr4AAt1DZeccV7LQaPpDZXcA8i2Ba2GoAbBsG5QRBsAAB5I9L5QAADiAABRi9I5hqRAaBorR4Y+E6AAYeNVdQAOsdz7AB4FV/0qrsFBZoqqq9opeSqvwF7R8RVpfrPcPgR0DxAH3A8gaAAAH4QqqvhD2gGgB2D2Bb/LB5A/kI8kcg+QFRsAUHuD2xxAACg8QfQAAAAAA7B6YwKD0R/QB2DQPMH8THrAKDjGoUFAAAABsAcg0AA+YGoHwAyPnxcXHKKCgoNgCgDvHxQoPObAFBsEXFxsBkfLiw7AHk//xAAUEQEAAAAAAAAAAAAAAAAAAADQ/9oACAECAQM/ABQD/8QAHREBAAEFAQEBAAAAAAAAAAAAEQEQIDBAUABgcP/aAAgBAwEBAgD5gKBYAYADAHEAADuOqfCxzoxxWLo0g2nTCkdCNWKxdH3ca8bwbLSMJzwujXjvRVuj08MAsKhiAyRzo8FY8GCNAM7rRkjvxdHOjmh8oFgZooXxWPtisVD0aodgODGw4Y3j6mNGLYq4wwxaHODhxaGpFsfegGAKAHTNRrG+AGIPpI4gAFY7p6OFHo6ofPHOjvxqxljpx9DHzLnjPFkZAwB9TGePsgwxw4xnxgBpFQ4EYQ+si0AAA0o+zjgx88Ho4sYgpH0MY42owxUD6GOUAfTR9JG/GmG8Ad6N+OeH2MdVfnY4Eab8O0Y1g1goGpGCO8oeiPgF8Uj02MemsY16JEUiyMEaSxa0KRqtYxRZGFaR6Ll4K1jFGCNBscEaatY9Fs+j0Vi2MARUd2L2sR5ccVjUiPBWMziaRFYwRHjJFDCR4rFz58xPlyxBSfRjik0jTMAUjI4DzWMEZ4vjHGOKBkLY9PovCyMTSMkXNH0a8R6KGNsW+KrSKBWMMYAsbSsUcMYj0YgrGBjWIo6zji+LQ0YsjM9+NEOGXRQDEaD4xRcZgALI0o9GeLA8YItMwaxnM4YgxBWLwoeahYWhZGoqruFkaRvBZFAwGrGZcgUDM3NYwhpgZA2g11W0AAMwXxceN4qvIDMFFagGlGQAuXEFwUDAAYlvd5aKtADSOSqqquFVVVWgWBsq8ILA1guV0G4AALYq6JshcHWAA1gAAADRCwAAKBmALgAA1Y3wAOgFgcYwzfHLAA5S5lVdcsn0bq8AA4AAAAABttHdVfggofGRvhcFA5QAHAKhsKqqtyr5oti5ADRdgAD5xVVVoqrmXcWxblVfxAAAPq19H4o/iofjH//EABQRAQAAAAAAAAAAAAAAAAAAAND/2gAIAQMBAz8AFAP/2Q==);
    background-size: cover;
    background-position: center;
    z-index: 0;
    -webkit-mask-image: linear-gradient(to bottom, rgba(0, 0, 0, 1) 60%, rgba(0, 0, 0, 0));
    mask-image: linear-gradient(to bottom, rgba(0, 0, 0, 1) 60%, rgba(0, 0, 0, 0));
}
.container {
    position: relative;
    padding: 40rpx;
    padding-top: 0;
    z-index: 1;
}
.user-header {
    display: flex;
    align-items: center;
    padding: 0 0 52rpx 0;
    .login-btn-box {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        .login-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 160rpx;
            height: 160rpx;
            color: rgba(64, 158, 255, 0.8);
            font-size: 16px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(217, 220, 225, 1);
        }
    }
}
.avatar {
    width: 120rpx;
    height: 120rpx;
    border-radius: 60rpx;
    margin-right: 20rpx;
}
.user-detail {
    flex: 1;
}
.name-wrap {
    display: flex;
    align-items: center;
    margin-bottom: 10rpx;
}
.nickname {
    font-size: 16px;
    font-weight: 600;
    margin-right: 8rpx;
}
.badge-wrap {
    display: flex;
    align-items: center;
    .gender {
        width: 30rpx;
        height: 30rpx;
    }
}
.user-stats {
    font-size: 12px;
    color: #666;
    margin-top: 10rpx;
}
.last-time {
    font-size: 12px;
    color: $uni-text-color-grey;
    margin-left: -2rpx;
}
.account-info {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
    margin-bottom: 20rpx;
}
.account-stats {
    display: flex;
    align-items: center;
}
.stat-item {
    flex: 1;
    text-align: center;
}
.stat-num {
    font-size: 20px;
    font-weight: 600;
    display: block;
}
.stat-label {
    font-size: 12px;
    color: #666;
}

.function-area {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20rpx;
}
.function-item {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
}
.icon-wrapper {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    margin-bottom: 16rpx;
}
.text-wrapper {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}
.title {
    font-size: 28rpx;
    color: $uni-text-color;
    font-weight: 500;
    margin-bottom: 8rpx;
    width: 100%;
    text-align: left;
}
.desc {
    font-size: 24rpx;
    color: $uni-text-color-grey;
    width: 100%;
    text-align: left;
}
</style>
