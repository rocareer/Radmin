<template>
    <view class="article-list">
        <view class="article-item-box">
            <view v-for="article in state.articles" :key="article.id" class="article-item" @click="goToDetail(article.id)">
                <view class="article-content">
                    <view class="article-header">
                        <text
                            class="article-title"
                            :style="{
                                color: article.title_style['color'],
                                fontWeight: article.title_style.bold ? 'bold' : 'normal',
                            }"
                        >
                            {{ article.title }}
                        </text>
                        <text :class="['status-tag', article.status]">{{ statusMap[article.status] }}</text>
                    </view>
                    <view class="article-info">
                        <text class="publish-time">{{ article.publish_time }}</text>
                        <view class="article-stats">
                            <view class="stat-item">
                                <uni-icons type="eye" size="14" />
                                <text class="stat-text">{{ article.views }}</text>
                            </view>
                            <view class="stat-item">
                                <uni-icons type="heart" size="14" />
                                <text class="stat-text">{{ article.likes }}</text>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </view>

        <uni-load-more class="ba-load-more mt-0" :status="state.loadingStatus"></uni-load-more>
    </view>
</template>

<script lang="ts" setup>
import { content } from '@/api/user/index'
import { onPullDownRefresh, onReachBottom, onShow } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state: {
    articles: anyObj[]
    loadingStatus: string
    currentPage: number
    pageSize: number
    total: number
} = reactive({
    articles: [],
    loadingStatus: 'more',
    currentPage: 1,
    pageSize: 10,
    total: 0,
})

const statusMap: anyObj = {
    normal: '已发布',
    unaudited: '等待管理员审核',
    refused: '管理员已拒绝',
    offline: '已下线',
}

const goToDetail = (id: number) => {
    uni.navigateTo({
        url: `/pages/user/contentDetail?id=${id}`,
    })
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const loadData = () => {
    state.loadingStatus = 'loading'
    content({
        page: state.currentPage,
        limit: state.pageSize,
    })
        .then((res) => {
            state.articles = state.currentPage == 1 ? res.data.list : [...state.articles, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.articles = []
    state.currentPage = 1
    loadData()
}

onShow(() => {
    onInit()
})

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.article-list {
    display: block;
    overflow: auto;
    box-sizing: border-box;
    .article-item-box {
        padding: 20rpx;
    }
}
.article-item {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
    margin-bottom: 20rpx;
}
.article-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20rpx;
}
.article-title {
    flex: 1;
    font-size: 16px;
    font-weight: 500;
    color: $uni-text-color;
    margin-right: 20rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    line-clamp: 2;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.status-tag {
    padding: 4rpx 16rpx;
    border-radius: 4px;
    font-size: 12px;
    flex-shrink: 0;
}
.normal {
    background-color: #e8f5e9;
    color: $uni-color-success;
}
.unaudited {
    background-color: #fff3e0;
    color: $uni-color-warning;
}
.refused,
.offline {
    background-color: #f5f5f5;
    color: $uni-text-color-grey;
}
.article-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.publish-time {
    font-size: 12px;
    color: $uni-text-color-grey;
}
.article-stats {
    display: flex;
    align-items: center;
}
.stat-item {
    display: flex;
    align-items: center;
    margin-left: 20rpx;
}
.stat-text {
    font-size: 12px;
    color: $uni-text-color-grey;
    margin-left: 8rpx;
}
</style>
