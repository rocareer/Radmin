<template>
    <view>
        <view class="agreement">
            <view class="checkbox" @click="toggleAgreement">
                <uni-icons v-if="model" type="checkbox-filled" size="20" color="#1989fa" />
                <uni-icons v-else type="circle" size="20" color="#999999" />
            </view>
            <text class="agreement-text">
                同意
                <text class="link" @click="openPopup('terms')">《服务条款》</text>
                <text>和</text>
                <text class="link" @click="openPopup('privacy')">《隐私政策》</text>
            </text>
        </view>

        <!-- 服务条款弹窗 -->
        <uni-popup ref="termsPopup" type="center">
            <view class="content-popup">
                <view class="content-header">
                    <text class="content-title">服务条款</text>
                    <uni-icons type="closeempty" size="15" color="#999" @click="termsPopup.close()" class="content-close" />
                </view>
                <scroll-view class="content-text-box" scroll-y>
                    <mp-html :selectable="true" class="ba-uni-markdown" :content="agreementContent" />
                </scroll-view>
            </view>
        </uni-popup>

        <!-- 隐私政策弹窗 -->
        <uni-popup ref="privacyPopup" type="center">
            <view class="content-popup">
                <view class="content-header">
                    <text class="content-title">隐私政策</text>
                    <uni-icons type="closeempty" size="15" color="#999" @click="privacyPopup.close()" class="content-close" />
                </view>
                <scroll-view class="content-text-box" scroll-y>
                    <mp-html :selectable="true" class="ba-uni-markdown" :content="agreementContent" />
                </scroll-view>
            </view>
        </uni-popup>
    </view>
</template>

<script lang="ts" setup>
import { agreement } from '@/api/user/login'
import { ref } from 'vue'

const termsPopup = ref()
const privacyPopup = ref()
const model = defineModel()
const agreementContent = ref<string>()

const toggleAgreement = () => {
    model.value = !model.value
}

const openPopup = (type: string) => {
    agreement(type).then((res) => {
        if (type == 'terms') {
            termsPopup.value.open()
        } else {
            privacyPopup.value.open()
        }
        agreementContent.value = res.data.content
    })
}
</script>

<style lang="scss" scoped>
.agreement {
    margin-top: 40rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}
.checkbox {
    margin-right: 16rpx;
    display: flex;
    align-items: center;
}
.agreement-text {
    font-size: 14px;
    color: $uni-text-color-grey;
}
.link {
    color: $uni-color-primary;
}
.content-popup {
    width: 600rpx;
    background: $uni-bg-color;
    border-radius: 24rpx;
    overflow: hidden;
}
.content-header {
    padding: 32rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid $uni-border-color;
}
.content-title {
    font-size: 16px;
    font-weight: 500;
    color: $uni-text-color;
}
.content-close {
    padding: 8rpx;
}
.content-text-box {
    height: 800rpx;
    box-sizing: border-box;
    overflow: hidden;
    padding: 0 20rpx;
}
.content-text {
    display: block;
    box-sizing: border-box;
    padding: 10rpx;
}
</style>
