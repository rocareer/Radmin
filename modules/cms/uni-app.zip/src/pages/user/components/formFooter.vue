<template>
    <view class="footer">
        <view v-if="isDisplay('weixin')" class="footer-item" @click="onWechatLogin">
            <uni-icons class="footer-item-icon" type="weixin" size="20" color="#333" />
            <text class="footer-item-text">微信登录</text>
        </view>

        <view v-if="isDisplay('retrievePassword')" class="footer-item" @click="navigate('/pages/user/retrievePassword')">
            <uni-icons class="footer-item-icon" type="locked" size="20" color="#333" />
            <text class="footer-item-text">找回密码</text>
        </view>

        <view v-if="isDisplay('login')" class="footer-item" @click="navigate('/pages/user/login')">
            <uni-icons class="footer-item-icon" type="person" size="20" color="#333" />
            <text class="footer-item-text">登录</text>
        </view>

        <view v-if="isDisplay('mobileLogin')" class="footer-item" @click="onMobileLogin">
            <uni-icons class="footer-item-icon" type="phone" size="20" color="#333" />
            <text class="footer-item-text">手机号登录</text>
        </view>

        <view v-if="isDisplay('userNameLogin')" class="footer-item" @click="onUserNameLogin">
            <uni-icons class="footer-item-icon" type="person" size="20" color="#333" />
            <text class="footer-item-text">用户名登录</text>
        </view>

        <view v-if="isDisplay('register')" class="footer-item" @click="navigate('/pages/user/register')">
            <uni-icons class="footer-item-icon" type="personadd" size="20" color="#333" />
            <text class="footer-item-text">注册</text>
        </view>
    </view>
</template>

<script setup lang="ts">
import { wechatMiniProgramLogin } from '@/api/user/login'
import { useUserInfo } from '@/stores/userInfo'
import { isWeixinBrowser } from '@/utils/common'
import { getBaseUrl } from '@/utils/request'

type names = 'weixin' | 'retrievePassword' | 'login' | 'mobileLogin' | 'userNameLogin' | 'register'

interface Props {
    buttonNames: names[]
    onMobileLogin?: () => void
    onUserNameLogin?: () => void
    onWechatMiniProgramLoginSuccess?: (...args: any[]) => any
}

const userInfo = useUserInfo()
const props = withDefaults(defineProps<Props>(), {
    buttonNames: () => {
        return []
    },
    onMobileLogin: () => {},
    onUserNameLogin: () => {},
    onWechatMiniProgramLoginSuccess: () => {},
})

const onWechatLogin = () => {
    // #ifdef MP-WEIXIN
    wx.login({
        success: (res) => {
            if (res.code) {
                wechatMiniProgramLogin(res.code).then((res) => {
                    userInfo.dataFill(res.data.userInfo, false)

                    // 调用微信小程序登录成功回调函数
                    if (props.onWechatMiniProgramLoginSuccess(res) !== false) {
                        uni.switchTab({
                            url: '/pages/user/user',
                        })
                    }
                })
            } else {
                uni.showToast({
                    title: `拉起微信登录失败：${res.errMsg}`,
                    icon: 'none',
                })
            }
        },
        fail: (err) => {
            uni.showToast({
                title: `拉起微信登录失败：${err.errMsg}`,
                icon: 'none',
            })
        },
    })
    return true
    // #endif

    if (!isWeChatLoginAvailable()) {
        uni.showToast({
            title: '请在微信客户端打开链接',
            icon: 'none',
        })
        return
    }
    const url = getBaseUrl() + `/api/cms.User/wechatLogin?server=1&name=wechat_mp&type=login`
    window.location.href = url
}

const navigate = (path: string) => {
    uni.redirectTo({
        url: path,
    })
}

const isDisplay = (name: names) => {
    if (name == 'weixin' && !isWeChatLoginAvailable()) {
        return false
    }

    return props.buttonNames.includes(name)
}

const isWeChatLoginAvailable = () => {
    // #ifdef MP-WEIXIN
    return true
    // #endif

    // #ifdef WEB
    return isWeixinBrowser()
    // #endif

    return false
}
</script>

<style lang="scss" scoped>
.footer {
    width: 100%;
    box-sizing: border-box;
    padding: 60rpx 0;
    display: flex;
    justify-content: center;
    gap: 80rpx;
}
.footer-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    transition: all 0.3s ease;
    .footer-item-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 80rpx;
        height: 80rpx;
        border-radius: 50%;
        border: 1px solid #eee;
        &:active {
            background: #eee;
            transform: scale(0.95);
        }
    }
    .footer-item-text {
        margin-top: 16rpx;
        font-size: 12px;
    }
}
</style>
