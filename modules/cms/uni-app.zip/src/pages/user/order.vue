<template>
    <view class="article-list">
        <ContentList :contents="state.articles" mode="card">
            <template #contentItemFooter="{ content }">
                <view class="order-info">
                    <text class="order-price">￥{{ content.amount }}</text>
                    <text class="pay-time">购买于：{{ content.pay_time }}</text>
                </view>
            </template>
        </ContentList>
        <uni-load-more class="ba-load-more mt-20" :status="state.loadingStatus"></uni-load-more>
    </view>
</template>

<script lang="ts" setup>
import { order } from '@/api/user/index'
import ContentList from '@/components/contentList/contentList.vue'
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state: {
    articles: anyObj[]
    loadingStatus: string
    currentPage: number
    pageSize: number
    total: number
} = reactive({
    articles: [],
    loadingStatus: 'more',
    currentPage: 1,
    pageSize: 10,
    total: 0,
})

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const loadData = () => {
    state.loadingStatus = 'loading'
    order({
        page: state.currentPage,
        limit: state.pageSize,
    })
        .then((res) => {
            state.articles = state.currentPage == 1 ? res.data.list : [...state.articles, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.articles = []
    state.currentPage = 1
    loadData()
}

onInit()

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.article-list {
    display: block;
    overflow: auto;
    box-sizing: border-box;
}
.order-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20rpx;
    padding-top: 0;
    border-bottom: 1px solid $uni-border-color;
    .order-price {
        font-size: 13px;
        color: $uni-color-error;
    }
    .pay-time {
        font-size: 12px;
        color: $uni-text-color-grey;
    }
}
</style>
