<template>
    <view class="comment-list">
        <view class="comment-item-box">
            <view
                v-for="commentInfo in state.comments"
                :key="commentInfo.id"
                class="comment-item"
                @longpress="onLongpress(commentInfo.id)"
                @click="goToDetail(commentInfo.id)"
            >
                <view class="comment-content">
                    <view class="comment-header">
                        <text class="comment-title">
                            {{ commentInfo.title }}
                        </text>
                    </view>
                    <view class="comment-text">
                        {{ commentInfo.content }}
                    </view>
                    <view class="comment-info">
                        <text class="publish-time">{{ commentInfo.create_time }}</text>
                        <text :class="['status-tag', commentInfo.status]">{{ statusMap[commentInfo.status] }}</text>
                    </view>
                </view>
            </view>
        </view>

        <uni-load-more class="ba-load-more mt-0" :status="state.loadingStatus"></uni-load-more>
    </view>
</template>

<script lang="ts" setup>
import { comment, delComment } from '@/api/user/index'
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state: {
    comments: anyObj[]
    loadingStatus: string
    currentPage: number
    pageSize: number
    total: number
} = reactive({
    comments: [],
    loadingStatus: 'more',
    currentPage: 1,
    pageSize: 10,
    total: 0,
})

const statusMap: anyObj = {
    normal: '正常',
    unaudited: '等待管理员审核',
    refused: '管理员已拒绝',
}

const goToDetail = (id: number) => {
    uni.navigateTo({
        url: `/pages/info/info?id=${id}`,
    })
}

const onLongpress = (id: number) => {
    uni.showActionSheet({
        itemList: ['删除评论'],
        success: function (res) {
            if (res.tapIndex == 0) {
                uni.showModal({
                    title: '提示',
                    content: '确定删除该评论吗？',
                    success: (res) => {
                        if (res.confirm) {
                            delComment(id.toString()).finally(() => {
                                onInit()
                            })
                        }
                    },
                })
            }
        },
    })
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const loadData = () => {
    state.loadingStatus = 'loading'
    comment({
        page: state.currentPage,
        limit: state.pageSize,
    })
        .then((res) => {
            state.comments = state.currentPage == 1 ? res.data.list : [...state.comments, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.comments = []
    state.currentPage = 1
    loadData()
}

onInit()

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.comment-list {
    display: block;
    overflow: auto;
    box-sizing: border-box;
    .comment-item-box {
        padding: 20rpx;
    }
}
.comment-item {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
    margin-bottom: 20rpx;
}
.comment-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}
.comment-title {
    flex: 1;
    font-size: 16px;
    font-weight: 500;
    color: $uni-text-color-grey;
    margin-right: 20rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    line-clamp: 2;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.status-tag {
    padding: 4rpx 16rpx;
    border-radius: 4px;
    font-size: 12px;
    flex-shrink: 0;
}
.normal {
    background-color: #e8f5e9;
    color: $uni-color-success;
}
.unaudited {
    background-color: #fff3e0;
    color: $uni-color-warning;
}
.refused {
    background-color: #f5f5f5;
    color: $uni-text-color-grey;
}
.comment-text {
    box-sizing: border-box;
    display: block;
    margin: 20rpx 0;
    border-left: 2px solid $uni-text-color-grey;
    padding-left: 10rpx;
}
.comment-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.publish-time {
    font-size: 12px;
    color: $uni-text-color-grey;
}
</style>
