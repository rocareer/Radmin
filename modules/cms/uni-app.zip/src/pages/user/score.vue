<template>
    <view>
        <!-- 积分展示区 -->
        <view class="score-header">
            <view class="score-title">当前积分</view>
            <view class="score-amount">
                <text class="amount">{{ userInfo.score }}</text>
            </view>
        </view>

        <!-- 交易记录区 -->
        <view class="transaction-list">
            <view class="transaction-items">
                <view v-for="(item, idx) in state.logs" :key="idx" class="transaction-card">
                    <view class="transaction-main">
                        <view class="transaction-info">
                            <text class="transaction-time">{{ timeFormat(item.create_time) }}</text>
                            <text class="transaction-remark">{{ item.memo }}</text>
                        </view>
                        <text :class="['transaction-amount', parseInt(item.score) > 0 ? 'income' : 'expense']">
                            {{ parseInt(item.score) > 0 ? '+' : '' }}{{ item.score }}积分
                        </text>
                    </view>
                    <view class="score-change">
                        <text class="label">变更前 {{ item.before }} 积分</text>
                        <text class="label">变更后 {{ item.after }} 积分</text>
                    </view>
                </view>
            </view>

            <uni-load-more class="ba-load-more mt-0" :status="state.loadingStatus"></uni-load-more>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { getIntegralLog, index } from '@/api/user/index'
import { useUserInfo } from '@/stores/userInfo'
import { timeFormat } from '@/utils/common'
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const userInfo = useUserInfo()
const state: {
    logs: any[]
    total: number
    currentPage: number
    pageSize: number
    loadingStatus: string
} = reactive({
    logs: [],
    total: 0,
    currentPage: 1,
    pageSize: 10,
    loadingStatus: 'more',
})

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.currentPage = 1
    state.logs = []
    loadData()

    index().then((res) => {
        userInfo.dataFill(res.data.userInfo)
    })
}

const loadData = () => {
    state.loadingStatus = 'loading'
    getIntegralLog(state.currentPage, state.pageSize)
        .then((res) => {
            state.logs = state.currentPage == 1 ? res.data.list : [...state.logs, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

onInit()

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.score-header {
    padding: 20px;
    background: linear-gradient(to bottom, #ffffff, #f8f8f8);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.score-title {
    font-size: 14px;
    line-height: 15px;
    color: #666666;
    text-align: center;
    margin-bottom: 10px;
}

.score-amount {
    text-align: center;
}

.amount {
    font-size: 40px;
    line-height: 40px;
    color: $uni-text-color;
    font-weight: 500;
    font-family: monospace;
}

.transaction-list {
    overflow: auto;
    box-sizing: border-box;
    .transaction-items {
        padding: 20rpx;
    }
}

.transaction-card {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
    margin-bottom: 20rpx;
}

.transaction-main {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.transaction-info {
    flex: 1;
    margin-right: 20rpx;
}

.transaction-time {
    display: block;
    font-size: 12px;
    color: $uni-text-color-grey;
}

.transaction-remark {
    display: block;
    font-size: 14px;
    color: $uni-text-color;
    padding: 10rpx 0;
}

.transaction-amount {
    font-size: 16px;
    font-family: monospace;
    font-weight: 500;
}

.income {
    color: $uni-color-success;
}

.expense {
    color: $uni-color-error;
}

.score-change {
    display: flex;
    align-items: center;
    font-size: 12px;
    color: $uni-text-color-grey;
}

.score-change .label {
    margin-right: 20rpx;
}
</style>
