<template>
    <view class="article-list">
        <ContentList :contents="state.articles" mode="card"></ContentList>
        <uni-load-more class="ba-load-more mt-20" :status="state.loadingStatus"></uni-load-more>
    </view>
</template>

<script lang="ts" setup>
import { operateRecord } from '@/api/user/index'
import ContentList from '@/components/contentList/contentList.vue'
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state: {
    articles: anyObj[]
    loadingStatus: string
    currentPage: number
    pageSize: number
    total: number
} = reactive({
    articles: [],
    loadingStatus: 'more',
    currentPage: 1,
    pageSize: 10,
    total: 0,
})

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const loadData = () => {
    state.loadingStatus = 'loading'
    operateRecord({
        page: state.currentPage,
        limit: state.pageSize,
        type: 'like',
    })
        .then((res) => {
            state.articles = state.currentPage == 1 ? res.data.list : [...state.articles, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()

            for (const key in state.articles) {
                if (!state.articles[key].cmsChannel && state.articles[key].name) {
                    state.articles[key].cmsChannel = {
                        id: state.articles[key].channel_id,
                        name: state.articles[key].name,
                    }
                }
            }
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.articles = []
    state.currentPage = 1
    loadData()
}

onInit()

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.article-list {
    display: block;
    overflow: auto;
    box-sizing: border-box;
}
</style>
