<template>
    <view class="content-text-box">
        <mp-html :selectable="true" class="ba-uni-markdown" :content="agreementContent" />
    </view>
</template>

<script lang="ts" setup>
import { agreement } from '@/api/user/login'
import { ref } from 'vue'

const agreementContent = ref<string>()

agreement('about').then((res) => {
    agreementContent.value = res.data.content
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style lang="scss" scoped>
.content-text-box {
    box-sizing: border-box;
    overflow: hidden;
    padding: 0 20rpx;
}
</style>
