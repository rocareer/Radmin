<template>
    <view class="login-page" :style="{ height: `${get100vh()}` }">
        <view class="main">
            <view class="title">找回登录密码</view>
            <view class="subtitle">通过验证账号绑定的手机号设定新的密码~</view>

            <view class="form">
                <view class="input-group">
                    <input class="form-item-input" type="text" v-model="state.mobile" placeholder="请输入手机号" :maxlength="11" />
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" v-model="state.code" placeholder="请输入手机验证码" :maxlength="6" />
                    <view class="get-btn" :class="{ 'get-btn-active': canGetCode }" @click="onGetCodePre">
                        {{ state.codeSendCountdown <= 0 ? '获取验证码' : state.codeSendCountdown + '秒' }}
                    </view>
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" :password="true" v-model="state.password" placeholder="请输入新密码" />
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" :password="true" v-model="state.passwordRepeat" placeholder="请再次输入新密码" />
                </view>
                <button
                    class="submit-btn"
                    :class="{ 'submit-btn-active': canSubmit }"
                    :disabled="state.submitLoading"
                    :loading="state.submitLoading"
                    @click="onSubmit"
                >
                    重设密码
                </button>
            </view>
        </view>

        <FormFooter :buttonNames="['weixin', 'login', 'register']" />

        <ClickCaptcha v-model="state.showClickCaptcha" :uuid="state.captchaId" :callback="onGetCode" />
    </view>
</template>

<script lang="ts" setup>
import { sendSms } from '@/api/common'
import { checkIn, retrievePassword } from '@/api/user/login'
import ClickCaptcha from '@/components/clickCaptcha/clickCaptcha.vue'
import { useRuntime } from '@/stores/runtime'
import { get100vh } from '@/utils/common'
import { uuid } from '@/utils/random'
import { computed, reactive } from 'vue'
import FormFooter from './components/formFooter.vue'

let timer: number
const state: {
    mobile: string
    code: string
    password: string
    passwordRepeat: string
    captchaId: string
    userLoginCaptchaSwitch: boolean
    accountVerificationType: string[]
    codeSendCountdown: number
    submitLoading: boolean
    showClickCaptcha: boolean
} = reactive({
    mobile: '',
    code: '',
    password: '',
    passwordRepeat: '',
    captchaId: uuid(),
    userLoginCaptchaSwitch: true,
    accountVerificationType: [],
    codeSendCountdown: 0,
    submitLoading: false,
    showClickCaptcha: false,
})

const canGetCode = computed(() => {
    return state.mobile.length === 11 && state.codeSendCountdown <= 0
})

const canSubmit = computed(() => {
    return state.mobile.length === 11 && state.password.length >= 6 && state.passwordRepeat.length >= 6
})

const onGetCodePre = () => {
    if (!state.accountVerificationType.includes('mobile')) {
        uni.showToast({
            title: '请于后台安装和配置短信模块',
            icon: 'none',
        })
        return
    }

    if (state.codeSendCountdown > 0 || !canGetCode.value) return

    if (state.userLoginCaptchaSwitch) {
        state.showClickCaptcha = true
    } else {
        onGetCode()
    }
}

const onGetCode = (captchaInfo = '') => {
    sendSms(state.mobile, 'user_retrieve_pwd', {
        captchaId: state.captchaId,
        captchaInfo: captchaInfo,
    }).then((res) => {
        if (res.code == 1) {
            uni.showToast({
                title: '验证码已发送',
                icon: 'none',
            })
            startTiming(60)
        }
    })
}

const onSubmit = () => {
    if (!canSubmit.value) return
    if (state.password !== state.passwordRepeat) {
        uni.showToast({
            title: '重复密码不一致',
            icon: 'none',
        })
        return
    }

    state.submitLoading = true
    retrievePassword({
        type: 'mobile',
        account: state.mobile,
        captcha: state.code,
        password: state.password,
    })
        .then((res) => {
            if (res.code == 1) {
                uni.showToast({
                    title: '密码重设成功，请使用新密码登录~',
                    icon: 'none',
                })
                setTimeout(() => {
                    const runtime = useRuntime()
                    runtime.setSwitchTabParams({
                        navUrl: '/pages/user/login?type=username',
                        navType: 'navigateTo',
                    })
                    uni.switchTab({
                        url: '/pages/user/user',
                    })
                }, 1500)
            }
        })
        .finally(() => {
            state.submitLoading = false
        })
}

const startTiming = (seconds: number) => {
    state.codeSendCountdown = seconds
    timer = setInterval(() => {
        state.codeSendCountdown--
        if (state.codeSendCountdown <= 0) {
            endTiming()
        }
    }, 1000)
}

const endTiming = () => {
    state.codeSendCountdown = 0
    clearInterval(timer)
}

checkIn().then((res) => {
    state.userLoginCaptchaSwitch = res.data.userLoginCaptchaSwitch
    state.accountVerificationType = res.data.accountVerificationType
    if (!state.accountVerificationType.includes('mobile')) {
        uni.showToast({
            title: '请于后台安装和配置短信模块',
            icon: 'none',
        })
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style scoped lang="scss">
.login-page {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.main {
    padding: 0 60rpx;
}
.title {
    padding-top: 10%;
    font-size: 20px;
    color: $uni-text-color;
    font-weight: 600;
    margin-bottom: 20rpx;
}
.subtitle {
    font-size: 14px;
    color: $uni-text-color-grey;
    margin-bottom: 50rpx;
}
.input-group {
    display: flex;
    align-items: center;
    position: relative;
    margin-bottom: 40rpx;
    border-bottom: 1px solid $uni-border-color;
    transition: border-color 0.3s ease;
}
.input-group:focus-within {
    border-color: $uni-color-primary;
}
.form-item-input {
    font-size: 15px;
    color: $uni-text-color;
    flex: 1;
    height: 60rpx;
    padding: 20rpx 0;
    transition: all 0.3s ease;
}
.form-item-input:focus {
    border-color: $uni-color-primary;
}
.get-btn {
    margin-left: auto;
    font-size: 13px;
    color: $uni-text-color-grey;
    transition: all 0.3s ease;
}
.get-btn-active {
    color: $uni-color-primary;
}
.submit-btn {
    width: 100%;
    height: 88rpx;
    background: #e6e6e6;
    color: $uni-text-color-inverse;
    font-size: 16px;
    border-radius: 44rpx;
    margin-top: 60rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 4rpx 12rpx rgba(230, 230, 230, 1);
}
.submit-btn:after {
    border: none;
}
.submit-btn[disabled] {
    box-shadow: 0 0.125rem 0.375rem rgb(230, 230, 230);
}
.submit-btn-active {
    background: $uni-color-primary;
    box-shadow: 0 8rpx 16rpx rgba(25, 137, 250, 0.3);
}
.submit-btn:active {
    transform: scale(0.98);
    opacity: 0.9;
}
.submit-btn-active:active {
    transform: scale(0.98);
    opacity: 0.9;
}
</style>
