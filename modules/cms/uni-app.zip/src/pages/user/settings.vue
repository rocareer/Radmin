<template>
    <view>
        <!-- 头像编辑区 -->
        <view class="avatar-section">
            <view class="avatar-wrapper" @click="changeAvatar">
                <image class="avatar" :src="fullUrl(userInfo.avatar)" mode="aspectFill" />
                <view class="change-text">点击更换头像</view>
            </view>
        </view>

        <!-- 基础信息表单 -->
        <view class="form-section">
            <view class="form-item">
                <text class="label">用户名</text>
                <input class="input" type="text" v-model="userInfo.username" placeholder="请输入用户名" />
            </view>
            <view class="form-item">
                <text class="label">昵称</text>
                <input class="input" type="text" v-model="userInfo.nickname" placeholder="请输入昵称" />
            </view>
            <view class="form-item">
                <text class="label">性别</text>
                <picker class="picker" :range="genderOptions" :value="userInfo.gender" @change="onGenderChange">
                    <view class="picker-value" :class="userInfo.gender ? '' : 'placeholder-text'">
                        {{ genderOptions[userInfo.gender] || '请选择性别' }}
                    </view>
                </picker>
            </view>
            <view class="form-item">
                <text class="label">生日</text>
                <picker class="picker" mode="date" :value="userInfo.birthday" @change="onBirthdayChange">
                    <view class="picker-value" :class="userInfo.birthday ? '' : 'placeholder-text'">{{ userInfo.birthday || '请选择生日' }}</view>
                </picker>
            </view>
        </view>

        <!-- 个性签名区域 -->
        <view class="signature-section">
            <text class="signature-label">个性签名</text>
            <textarea class="signature-input" v-model="userInfo.motto" placeholder="请输入个性签名" :maxlength="50" />
            <text class="word-count">{{ userInfo.motto.length }}/50</text>
        </view>

        <!-- 底部保存按钮 -->
        <view class="footer">
            <view class="button-group">
                <button class="footer-btn clear" @click="clearStorage">清理缓存</button>
                <button class="footer-btn" :loading="saveLoading" :disabled="saveLoading" @click="saveProfile">保存</button>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { upload } from '@/api/common'
import { index, postProfile } from '@/api/user/index'
import { useUserInfo } from '@/stores/userInfo'
import { fullUrl } from '@/utils/common'
import { ref } from 'vue'

const userStore = useUserInfo()

if (!userStore.isLogin()) {
    uni.showToast({
        title: '请先登录',
        icon: 'none',
    })

    // 延时防止微信小程序内不能正常跳转
    setTimeout(() => {
        uni.redirectTo({
            url: `/pages/user/login?navUrl=/pages/user/settings`,
        })
    }, 500)
}

const userInfo = ref({ ...userStore.$state })
const saveLoading = ref(false)

const genderOptions = ['保密', '男', '女']

const changeAvatar = () => {
    uni.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
            upload(res.tempFilePaths[0], 'image').then((res) => {
                userInfo.value.avatar = res.data.file.url
                saveProfile()
            })
        },
    })
}

const onGenderChange = (e: any) => {
    userInfo.value.gender = e.detail.value
}

const onBirthdayChange = (e: any) => {
    userInfo.value.birthday = e.detail.value
}

const saveProfile = () => {
    saveLoading.value = true
    postProfile(userInfo.value)
        .then((res) => {
            if (res.code == 1) {
                index().then((res) => {
                    userStore.dataFill(res.data.userInfo)
                })
            }
        })
        .finally(() => {
            saveLoading.value = false
        })
}

const clearStorage = () => {
    uni.showModal({
        title: '提示',
        content: '确定清理缓存吗？',
        success: (res) => {
            if (res.confirm) {
                try {
                    userStore.logout(() => {
                        uni.clearStorageSync()
                        uni.showModal({
                            title: '提示',
                            content: '缓存已清空，请重新登录~',
                            showCancel: false,
                            success: () => {
                                uni.reLaunch({
                                    url: '/pages/user/user',
                                })
                            },
                        })
                    })
                } catch (e) {
                    console.log(e)
                }
            }
        },
    })
}
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style lang="scss" scoped>
.avatar-section {
    padding: 40rpx 0;
    background-color: $uni-bg-color;
    display: flex;
    justify-content: center;
}

.avatar-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.avatar {
    width: 160rpx;
    height: 160rpx;
    border-radius: 80rpx;
    margin-bottom: 20rpx;
}

.change-text {
    font-size: 12px;
    color: #666666;
}

.form-section {
    background-color: $uni-bg-color;
    margin-bottom: 20rpx;
}

.form-item {
    display: flex;
    align-items: center;
    padding: 30rpx;
    border-bottom: 1px solid $uni-border-color;
}

.label {
    width: 140rpx;
    font-size: 14px;
    color: $uni-text-color;
}

.input {
    flex: 1;
    font-size: 14px;
    color: $uni-text-color;
}

.picker {
    flex: 1;
}

.picker-value {
    font-size: 14px;
    color: $uni-text-color;
}
.placeholder-text {
    color: $uni-text-color-grey;
}

.signature-section {
    background-color: $uni-bg-color;
    padding: 30rpx;
    padding-top: 0;
    position: relative;
}

.signature-label {
    display: block;
    font-size: 14px;
    color: $uni-text-color;
    margin-bottom: 20rpx;
}

.signature-input {
    width: 100%;
    height: 200rpx;
    padding: 20rpx;
    box-sizing: border-box;
    font-size: 14px;
    line-height: 1.5;
    background-color: $uni-bg-color-grey;
    border-radius: 8rpx;
}

.word-count {
    position: absolute;
    right: 30rpx;
    bottom: 30rpx;
    font-size: 12px;
    color: $uni-text-color-grey;
}

.footer {
    padding: 20rpx 30rpx calc(20rpx + env(safe-area-inset-bottom));
    background-color: $uni-bg-color;
    flex-shrink: 0;
}

.button-group {
    display: flex;
    justify-content: space-between;
    gap: 40rpx;
    margin: 0 40rpx;
}

.footer-btn {
    width: 100%;
    height: 88rpx;
    line-height: 88rpx;
    background-color: $uni-color-primary;
    color: $uni-bg-color;
    font-size: 16px;
    border-radius: 44rpx;
}
.footer-btn.clear {
    background-color: $uni-color-error;
}
</style>
