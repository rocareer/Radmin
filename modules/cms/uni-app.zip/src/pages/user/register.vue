<template>
    <view class="login-page" :style="{ height: `${get100vh()}` }">
        <view class="main">
            <view class="title">注册账号</view>
            <view class="subtitle">欢迎注册 BuildAdmin，精彩永不丢失~</view>

            <view class="form">
                <view class="input-group">
                    <input class="form-item-input" type="text" v-model="state.username" placeholder="请输入用户名" />
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" :password="true" v-model="state.password" placeholder="请输入密码" />
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" v-model="state.mobile" placeholder="请输入手机号" :maxlength="11" />
                </view>
                <view class="input-group">
                    <input class="form-item-input" type="text" v-model="state.code" placeholder="请输入验证码" :maxlength="6" />
                    <view class="get-btn" :class="{ 'get-btn-active': canGetCode }" @click="onGetCodePre">
                        {{ state.codeSendCountdown <= 0 ? '获取验证码' : state.codeSendCountdown + '秒' }}
                    </view>
                </view>
                <button
                    class="submit-btn"
                    :disabled="state.submitLoading"
                    :loading="state.submitLoading"
                    :class="{ 'submit-btn-active': canSubmit }"
                    @click="onSubmit"
                >
                    立即注册
                </button>
            </view>

            <Agreement v-model="state.agree" />
        </view>

        <FormFooter :buttonNames="['login', 'retrievePassword']" class="footer" />

        <ClickCaptcha v-model="state.showClickCaptcha" :uuid="state.captchaId" :callback="onGetCode" />
    </view>
</template>

<script lang="ts" setup>
import { sendSms } from '@/api/common'
import { checkIn } from '@/api/user/login'
import ClickCaptcha from '@/components/clickCaptcha/clickCaptcha.vue'
import { useUserInfo } from '@/stores/userInfo'
import { get100vh } from '@/utils/common'
import { uuid } from '@/utils/random'
import { computed, reactive } from 'vue'
import Agreement from './components/agreement.vue'
import FormFooter from './components/formFooter.vue'

let timer: number
const userInfo = useUserInfo()
const state: {
    mobile: string
    username: string
    password: string
    code: string
    agree: boolean
    captchaId: string
    userLoginCaptchaSwitch: boolean
    accountVerificationType: string[]
    codeSendCountdown: number
    submitLoading: boolean
    showClickCaptcha: boolean
} = reactive({
    mobile: '',
    username: '',
    password: '',
    code: '',
    agree: true,
    captchaId: uuid(),
    userLoginCaptchaSwitch: true,
    accountVerificationType: [],
    codeSendCountdown: 0,
    submitLoading: false,
    showClickCaptcha: false,
})

const canGetCode = computed(() => {
    return state.mobile.length === 11 && state.codeSendCountdown <= 0
})

const canSubmit = computed(() => {
    return state.username.length >= 2 && state.password.length >= 6 && state.mobile.length === 11 && state.code.length === 6 && state.agree
})

const onGetCodePre = () => {
    if (!state.accountVerificationType.includes('mobile')) {
        uni.showToast({
            title: '请于后台安装和配置短信模块',
            icon: 'none',
        })
        return
    }

    if (state.codeSendCountdown > 0 || !canGetCode.value) return

    if (state.userLoginCaptchaSwitch) {
        state.showClickCaptcha = true
    } else {
        onGetCode()
    }
}

const onGetCode = (captchaInfo = '') => {
    sendSms(state.mobile, 'user_register', {
        captchaId: state.captchaId,
        captchaInfo: captchaInfo,
    }).then((res) => {
        if (res.code == 1) {
            uni.showToast({
                title: '验证码已发送',
                icon: 'none',
            })
            startTiming(60)
        }
    })
}

const startTiming = (seconds: number) => {
    state.codeSendCountdown = seconds
    timer = setInterval(() => {
        state.codeSendCountdown--
        if (state.codeSendCountdown <= 0) {
            endTiming()
        }
    }, 1000)
}

const endTiming = () => {
    state.codeSendCountdown = 0
    clearInterval(timer)
}

const onSubmit = () => {
    if (!state.agree) {
        uni.showToast({
            title: '请先同意服务条款和隐私政策',
            icon: 'none',
        })
        return
    }

    if (!canSubmit.value) return

    state.submitLoading = true
    checkIn('POST', {
        tab: 'register',
        username: state.username,
        password: state.password,
        mobile: state.mobile,
        email: '',
        captcha: state.code,
        registerType: 'mobile',
    })
        .then((res) => {
            if (res.code == 1) {
                uni.showToast({
                    title: '注册成功~',
                    icon: 'none',
                })
                userInfo.dataFill(res.data.userInfo, false)
                setTimeout(() => {
                    uni.switchTab({
                        url: '/pages/user/user',
                    })
                }, 1500)
            }
        })
        .finally(() => {
            state.submitLoading = false
        })
}

checkIn().then((res) => {
    state.userLoginCaptchaSwitch = res.data.userLoginCaptchaSwitch
    state.accountVerificationType = res.data.accountVerificationType
    if (!state.accountVerificationType.includes('mobile')) {
        uni.showToast({
            title: '请于后台安装和配置短信模块',
            icon: 'none',
        })
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style scoped lang="scss">
.login-page {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.main {
    padding: 0 60rpx;
}
.title {
    padding-top: 5%;
    font-size: 20px;
    color: $uni-text-color;
    font-weight: 600;
    margin-bottom: 20rpx;
}
.subtitle {
    font-size: 14px;
    color: $uni-text-color-grey;
    margin-bottom: 50rpx;
}
.input-group {
    display: flex;
    align-items: center;
    position: relative;
    margin-bottom: 40rpx;
    border-bottom: 1px solid $uni-border-color;
    transition: border-color 0.3s ease;
}
.input-group:focus-within {
    border-color: $uni-color-primary;
}
.form-item-input {
    font-size: 15px;
    color: $uni-text-color;
    flex: 1;
    height: 60rpx;
    padding: 20rpx 0;
    transition: all 0.3s ease;
}
.form-item-input:focus {
    border-color: $uni-color-primary;
}
.get-btn {
    margin-left: auto;
    font-size: 13px;
    color: $uni-text-color-grey;
    transition: all 0.3s ease;
}
.get-btn-active {
    color: $uni-color-primary;
}
.submit-btn {
    width: 100%;
    height: 88rpx;
    background: #e6e6e6;
    color: $uni-text-color-inverse;
    font-size: 16px;
    border-radius: 44rpx;
    margin-top: 60rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 4rpx 12rpx rgba(230, 230, 230, 1);
}
.submit-btn:after {
    border: none;
}
.submit-btn[disabled] {
    box-shadow: 0 0.125rem 0.375rem rgb(230, 230, 230);
}
.submit-btn-active {
    background: $uni-color-primary;
    box-shadow: 0 8rpx 16rpx rgba(25, 137, 250, 0.3);
}
.submit-btn:active {
    transform: scale(0.98);
    opacity: 0.9;
}
.submit-btn-active:active {
    transform: scale(0.98);
    opacity: 0.9;
}
</style>
