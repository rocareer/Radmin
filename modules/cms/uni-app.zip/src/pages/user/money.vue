<template>
    <view>
        <!-- 余额展示区 -->
        <view class="balance-header">
            <view class="balance-title">当前余额</view>
            <view class="balance-amount">
                <text class="currency">¥</text>
                <text class="amount">{{ formatAmount(userInfo.money.toString()) }}</text>
            </view>
        </view>

        <!-- 交易记录区 -->
        <view class="transaction-list">
            <view class="transaction-items">
                <view v-for="(item, idx) in state.logs" :key="idx" class="transaction-card">
                    <view class="transaction-main">
                        <view class="transaction-info">
                            <text class="transaction-time">{{ timeFormat(item.create_time) }}</text>
                            <text class="transaction-remark">{{ item.memo }}</text>
                        </view>
                        <text :class="['transaction-amount', parseFloat(item.money) > 0 ? 'income' : 'expense']">
                            {{ parseFloat(item.money) > 0 ? '+' : '' }}{{ formatAmount(item.money) }}
                        </text>
                    </view>
                    <view class="balance-change">
                        <text class="label">变更前</text>
                        <text class="value">¥{{ formatAmount(item.before) }}</text>
                        <text class="label">变更后</text>
                        <text class="value">¥{{ formatAmount(item.after) }}</text>
                    </view>
                </view>
            </view>

            <uni-load-more class="ba-load-more mt-0" :status="state.loadingStatus"></uni-load-more>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { getBalanceLog, index } from '@/api/user/index'
import { useUserInfo } from '@/stores/userInfo'
import { timeFormat } from '@/utils/common'
import { onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const userInfo = useUserInfo()
const state: {
    logs: any[]
    total: number
    currentPage: number
    pageSize: number
    loadingStatus: string
} = reactive({
    logs: [],
    total: 0,
    currentPage: 1,
    pageSize: 10,
    loadingStatus: 'more',
})

const formatAmount = (amount: string): string => {
    return parseFloat(amount).toFixed(2)
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    loadData()
}

const onInit = () => {
    state.loadingStatus = 'more'
    state.currentPage = 1
    state.logs = []
    loadData()

    index().then((res) => {
        userInfo.dataFill(res.data.userInfo)
    })
}

const loadData = () => {
    state.loadingStatus = 'loading'
    getBalanceLog(state.currentPage, state.pageSize)
        .then((res) => {
            state.logs = state.currentPage == 1 ? res.data.list : [...state.logs, ...res.data.list]
            state.total = res.data.total

            uni.stopPullDownRefresh()
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

onInit()

onPullDownRefresh(() => {
    onInit()
})

onReachBottom(() => {
    loadMore()
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color-grey;
}
</style>

<style scoped lang="scss">
.balance-header {
    padding: 20px;
    background: linear-gradient(to bottom, #ffffff, #f8f8f8);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.balance-title {
    font-size: 14px;
    line-height: 15px;
    color: #666666;
    text-align: center;
    margin-bottom: 10px;
}

.balance-amount {
    text-align: center;
}

.currency {
    font-size: 24px;
    color: $uni-text-color;
    margin-right: 8rpx;
}

.amount {
    font-size: 40px;
    line-height: 40px;
    color: $uni-text-color;
    font-weight: 500;
    font-family: monospace;
}

.transaction-list {
    overflow: auto;
    box-sizing: border-box;
    .transaction-items {
        padding: 20rpx;
    }
}

.transaction-card {
    background-color: $uni-bg-color;
    border-radius: 16rpx;
    padding: 30rpx;
    margin-bottom: 20rpx;
}

.transaction-main {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.transaction-info {
    flex: 1;
    margin-right: 20rpx;
}

.transaction-time {
    display: block;
    font-size: 12px;
    color: $uni-text-color-grey;
}

.transaction-remark {
    display: block;
    font-size: 14px;
    color: $uni-text-color;
    padding: 10rpx 0;
}

.transaction-amount {
    font-size: 16px;
    font-family: monospace;
    font-weight: 500;
}

.income {
    color: $uni-color-success;
}

.expense {
    color: $uni-color-error;
}

.balance-change {
    display: flex;
    align-items: center;
    font-size: 12px;
    color: $uni-text-color-grey;
}

.balance-change .label {
    margin-right: 8rpx;
}

.balance-change .value {
    margin-right: 20rpx;
    font-family: monospace;
}
</style>
