<template>
    <view
        class="container"
        :style="{
            height: get100vh(),
        }"
    >
        <view class="article-header">
            <text class="article-title">{{ state.info.title }}</text>
            <text class="article-date">{{ state.info.publish_time }}</text>
        </view>
        <view class="data-grid">
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="eye" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">浏览量</text>
                <text class="data-value">{{ state.info.views }}</text>
            </view>
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="chat" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">评论量</text>
                <text class="data-value">{{ state.info.comments }}</text>
            </view>
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="hand-up" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">点赞量</text>
                <text class="data-value">{{ state.info.likes }}</text>
            </view>
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="hand-down" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">点踩量</text>
                <text class="data-value">{{ state.info.dislikes }}</text>
            </view>
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="shop" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">销量</text>
                <text class="data-value">{{ state.info.sales }}</text>
            </view>
            <view class="data-item">
                <view class="data-icon">
                    <uni-icons type="vip" size="24" color="#666"></uni-icons>
                </view>
                <text class="data-label">赞赏</text>
                <text class="data-value" v-if="!state.loading">￥{{ parseFloat(state.info.admireSum) }}</text>
            </view>
        </view>
        <view class="button-group-box">
            <view class="button-group">
                <button class="action-button delete-button" @click="onDelete" type="default">删除文章</button>
                <navigator :url="`/pages/info/info?id=${state.id}`" class="action-button view-button" type="primary">查看原文</navigator>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { contentStatistics, delContent } from '@/api/user/index'
import { get100vh } from '@/utils/common'
import { onLoad } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state: {
    id: string
    info: anyObj
    loading: boolean
} = reactive({
    id: '',
    info: {},
    loading: true,
})

const getInfo = () => {
    state.loading = true
    contentStatistics(state.id)
        .then((res) => {
            state.info = res.data.info
        })
        .finally(() => {
            state.loading = false
        })
}

const onDelete = () => {
    uni.showModal({
        title: '提示',
        content: '确定删除该文章吗？',
        success: (res) => {
            if (res.confirm) {
                delContent(state.id).then((res) => {
                    if (res.code == 1) {
                        uni.navigateBack({
                            delta: 1,
                        })
                    }
                })
            }
        },
    })
}

onLoad((query) => {
    if (query && query.id) {
        state.id = query.id
        getInfo()
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style scoped lang="scss">
.container {
    padding: 20rpx;
    box-sizing: border-box;
    position: relative;
}
.article-header {
    margin-bottom: 32rpx;
}
.article-title {
    display: block;
    font-size: 16px;
    color: $uni-text-color;
    line-height: 1.4;
    font-weight: 500;
    margin-bottom: 16rpx;
}
.article-date {
    display: block;
    font-size: 14px;
    color: $uni-text-color-grey;
}
.data-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20rpx;
}
.data-item {
    background-color: $uni-bg-color;
    border-radius: 12rpx;
    padding: 24rpx;
    display: flex;
    flex-direction: column;
    border: 1px solid #eee;
}
.data-icon {
    margin-bottom: 10rpx;
}
.data-label {
    font-size: 14px;
    color: #666;
    margin-bottom: 16rpx;
}
.data-value {
    font-size: 20px;
    color: $uni-text-color;
    font-weight: 500;
    margin-bottom: 16rpx;
}
.data-compare {
    display: flex;
    align-items: center;
}
.compare-text {
    font-size: 12px;
    color: $uni-text-color-grey;
}
.compare-icon {
    margin: 0 4rpx;
}
.compare-number {
    font-size: 12px;
    color: $uni-color-primary;
}
.button-group-box {
    position: fixed;
    bottom: 100rpx;
    left: 0;
    width: 100%;
}
.button-group {
    display: flex;
    justify-content: space-between;
    gap: 40rpx;
    margin: 0 40rpx;
}
.action-button {
    flex: 1;
    height: 88rpx;
    border-radius: 44rpx;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: $uni-text-color-inverse;
}
.view-button {
    background-color: $uni-color-primary;
}
.delete-button {
    background-color: $uni-color-error;
}
.view-button:after,
.delete-button:after {
    border: none;
}
</style>
