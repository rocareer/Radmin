<template>
    <view>
        <NavBar :box-shadow="false" />

        <!-- #ifndef WEB -->
        <view class="refresh-box" :style="{ marginTop: `${state.refreshBoxMarginTop}px` }">
            {{ state.isRefreshing ? '刷新中...' : '继续下拉刷新内容' }}
        </view>
        <!-- #endif -->

        <!-- 内容列表不使用 scroll-view，为了H5下的最好表现效果，特别是大部分手机浏览器在滑动后才能全屏（scroll-view 的滑动不能触发全屏） -->
        <!-- 自定义导航栏后下拉刷新微信小程序内不好用，自行实现 -->
        <view
            @mousedown="onSwitchStart"
            @mousemove="onSwitchMove"
            @mouseup="onSwitchEnd"
            @touchstart="onSwitchStart"
            @touchmove="onSwitchMove"
            @touchend="onSwitchEnd"
            @touchcancel="onSwitchEnd"
        >
            <view class="news-list">
                <!-- 轮播图 -->
                <swiper
                    class="swiper-section"
                    autoplay
                    circular
                    indicator-dots
                    :interval="3000"
                    indicator-color="rgba(255, 255, 255, .3)"
                    indicator-active-color="rgba(255, 255, 255, .6)"
                >
                    <swiper-item
                        v-for="(carousel, cIdx) in state.newCarousel"
                        :key="cIdx"
                        @click="
                            navigate(carousel.target as NavigateType, {
                                url: carousel.link,
                            })
                        "
                    >
                        <image class="swiper-img" :src="fullUrl(carousel.image)" mode="aspectFill"></image>
                        <view class="swiper-title">{{ carousel.title }}</view>
                    </swiper-item>
                </swiper>

                <ContentList :contents="state.contents.data" mode="tiled" />

                <uni-load-more class="ba-load-more" :status="state.loadingStatus"></uni-load-more>
            </view>
        </view>
    </view>
</template>

<script lang="ts" setup>
import { news } from '@/api/index'
import ContentList from '@/components/contentList/contentList.vue'
import NavBar from '@/components/navBar/navBar.vue'
import { useSiteConfig } from '@/stores/siteConfig'
import { fullUrl, navigate, onTabBarPageLoad } from '@/utils/common'
import { onLoad, onPageScroll, onReachBottom, onShareAppMessage, onShow } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const siteConfig = useSiteConfig()
const refreshBoxDefaultMarginTop = -50
const state: {
    scrollTop: number
    isRefreshing: boolean
    refreshBoxMarginTop: number
    contents: {
        total: number
        data: anyObj[]
        current_page: number
    }
    newCarousel: anyObj[]
    loadingStatus: string
    pageSize: number
} = reactive({
    scrollTop: 0,
    isRefreshing: false,
    refreshBoxMarginTop: refreshBoxDefaultMarginTop,
    contents: {
        total: 0,
        data: [],
        current_page: 1,
    },
    newCarousel: [],
    loadingStatus: 'more',
    pageSize: 10,
})

let isDragging = false
let touchStartY = 0

/**
 * PS：e 的类型在 H5 是 TouchEvent，同时微信小程序等平台，没有 MouseEvent 类型
 */
const onSwitchStart = (e: TouchEvent | MouseEvent | any) => {
    if (state.isRefreshing) return

    touchStartY = e.clientY || e.touches[0].clientY
    isDragging = true
}

const onSwitchMove = (e: TouchEvent | MouseEvent | any) => {
    if (!isDragging) return

    const deltaY = (e.clientY || e.touches[0].clientY) - touchStartY

    // #ifndef WEB
    if (state.scrollTop < 10 || state.refreshBoxMarginTop != refreshBoxDefaultMarginTop) {
        let top = refreshBoxDefaultMarginTop + deltaY
        state.refreshBoxMarginTop = top > 0 ? 0 : top < refreshBoxDefaultMarginTop ? refreshBoxDefaultMarginTop : top
    }
    // #endif
}

const onSwitchEnd = () => {
    if (!isDragging) return
    isDragging = false

    if (state.refreshBoxMarginTop >= 0) {
        state.isRefreshing = true
        onInit()
    } else {
        state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
    }
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    loadData(state.contents.current_page + 1)
}

/**
 * 刷新/初始化
 */
const onInit = () => {
    state.loadingStatus = 'more'
    state.contents = {
        total: 0,
        data: [],
        current_page: 1,
    }
    state.scrollTop = 0
    loadData(1)
}

const loadData = (page: number) => {
    state.loadingStatus = 'loading'
    news({
        page: page,
        limit: state.pageSize,
    })
        .then((res) => {
            if (page > 1) {
                state.contents.total = res.data.contents.total
                state.contents.current_page = res.data.contents.current_page
                state.contents.data = [...state.contents.data, ...res.data.contents.data]
            } else {
                state.contents = res.data.contents
                state.newCarousel = res.data.newCarousel
            }

            // 下拉刷新重置
            state.isRefreshing = false
            state.refreshBoxMarginTop = refreshBoxDefaultMarginTop
        })
        .finally(() => {
            state.loadingStatus = state.contents.total > state.pageSize * state.contents.current_page ? 'more' : 'noMore'
        })
}

onLoad(() => {
    onTabBarPageLoad()
})

onShow(() => {
    onTabBarPageLoad()
})

onPageScroll((e) => {
    state.scrollTop = e.scrollTop
})

onReachBottom(() => {
    loadMore()
})

onInit()

onShareAppMessage(() => {
    return {
        title: siteConfig.siteName,
        path: '/pages/news/news',
    }
})
</script>

<style lang="scss">
page {
    background-color: $uni-bg-color;
}
</style>

<style scoped lang="scss">
.refresh-box {
    font-size: 14px;
    color: $uni-text-color-grey;
    text-align: center;
    padding-top: 10px;
    line-height: 40px;
}
.swiper-section {
    position: relative;
    height: 400rpx;
    // 数值上的统一为 20px，但轮播通常为大图显得很宽，为了视觉上的统一，额外加了 2px
    margin: 20rpx 22rpx 10rpx 22rpx;
    border-radius: 12rpx;
    overflow: hidden;
}
.swiper-img {
    width: 100%;
    height: 100%;
    border-radius: 12rpx;
}
.swiper-title {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 20rpx;
    color: $uni-text-color-inverse;
    font-size: 16px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
}
.news-list {
    display: block;
    width: 100%;
    overflow: hidden;
}
</style>
