<template>
    <view class="filter-page">
        <NavBar :search-input-keywords="state.keywords" :handle-search="handleSearch" :back-btn="true" />
        <ContentList :contents="state.contents" mode="tiled" />
        <uni-load-more class="ba-load-more" :status="state.loadingStatus"></uni-load-more>
    </view>
</template>

<script lang="ts" setup>
import { articleList } from '@/api/content/index'
import ContentList from '@/components/contentList/contentList.vue'
import NavBar from '@/components/navBar/navBar.vue'
import { onLoad, onReachBottom } from '@dcloudio/uni-app'
import { reactive } from 'vue'

const state = reactive({
    total: 0,
    pageSize: 10,
    currentPage: 1,
    keywords: '',
    loadingStatus: '',
    contents: [] as any[],
})

const getData = () => {
    state.loadingStatus = 'loading'
    articleList({
        page: state.currentPage,
        limit: state.pageSize,
        keywords: state.keywords,
    })
        .then((res) => {
            state.contents = state.currentPage == 1 ? res.data.list : [...state.contents, ...res.data.list]
            state.total = res.data.total
        })
        .finally(() => {
            state.loadingStatus = state.total > state.pageSize * state.currentPage ? 'more' : 'noMore'
        })
}

const loadMore = () => {
    if (state.loadingStatus == 'noMore') {
        return
    }
    state.currentPage++
    getData()
}

onLoad((query) => {
    if (query && query.keywords) {
        state.keywords = query.keywords
        getData()
    }
})

onReachBottom(() => {
    loadMore()
})

const handleSearch = (keywords: string) => {
    state.currentPage = 1
    state.keywords = keywords
    state.contents = []
    getData()
    return false
}
</script>

<style lang="scss" scoped>
.filter-page {
    overflow: hidden;
}
</style>
