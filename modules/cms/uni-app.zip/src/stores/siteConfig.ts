import type { SiteConfig } from '@/stores/interface'
import { defineStore } from 'pinia'

export const useSiteConfig = defineStore('siteConfig', {
    state: (): SiteConfig => {
        return {
            siteName: '',
            version: '',
            cdnUrl: '',
            h5Domain: '',
            upload: {
                mode: 'local',
            },
        }
    },
    actions: {
        dataFill(state: SiteConfig) {
            this.$patch(state)
        },
    },
})
