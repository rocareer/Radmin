export interface UserInfo {
    id: number
    username: string
    nickname: string
    email: string
    mobile: string
    gender: number
    birthday: string
    money: number
    score: number
    avatar: string
    last_login_time: string
    last_login_ip: string
    join_time: string
    motto: string
    token: string
    refresh_token: string
}

export interface SiteConfig {
    siteName: string
    version: string
    cdnUrl: string
    h5Domain: string
    upload: {
        mode: string
        [key: string]: any
    }
}

export interface SwitchTabParams {
    navUrl: string
    navType?: NavigateType
}

export interface Runtime {
    switchTabParams: SwitchTabParams
    [key: string]: any
}
