import type { Runtime, SwitchTabParams } from '@/stores/interface'
import { defineStore } from 'pinia'

export const useRuntime = defineStore('runtime', {
    state: (): Runtime => {
        return {
            switchTabParams: {
                navUrl: '',
                navType: 'navigateTo',
            },
        }
    },
    actions: {
        setSwitchTabParams(data?: SwitchTabParams) {
            this.switchTabParams.navUrl = data && data.navUrl ? data.navUrl : ''
            this.switchTabParams.navType = data && data.navType ? data.navType : 'navigateTo'
        },
    },
})
