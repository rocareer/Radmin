/**
 * 本地缓存Key
 */

// 会员资料
export const USER_INFO = 'userInfo'
