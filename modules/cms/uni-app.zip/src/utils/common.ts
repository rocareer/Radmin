import noPic from '@/static/images/no-pic.jpg'
import { useRuntime } from '@/stores/runtime'
import { useSiteConfig } from '@/stores/siteConfig'
import { getBaseUrl } from './request'

/**
 * 获取资源完整地址
 * @param relativeUrl 资源相对地址
 * @param domain 指定域名
 */
export const fullUrl = (relativeUrl: string, domain = '') => {
    const siteConfig = useSiteConfig()
    if (!domain) {
        domain = siteConfig.cdnUrl ? siteConfig.cdnUrl : getBaseUrl()
    }

    // 如果 domain 不带协议头
    if (domain.startsWith('//')) {
        domain = getProtocol() + domain
    }

    if (!relativeUrl) return domain

    const regUrl = new RegExp(/^http(s)?:\/\//)
    const regexImg = new RegExp(/^((?:[a-z]+:)?\/\/|data:image\/)(.*)/i)
    if (!domain || regUrl.test(relativeUrl) || regexImg.test(relativeUrl)) {
        // 如果资源地址不带协议头
        if (relativeUrl.startsWith('//')) {
            relativeUrl = getProtocol() + relativeUrl
        }

        return relativeUrl
    }
    return domain + relativeUrl
}

/**
 * 本函数总是在 tabBar 页面的 onLoad 中调用，若 navUrl 存在，则立即跳转至 navUrl
 * 此时的页面堆栈：uni.switchTab > tabBar页面 > 自动转到navUrl（即清空页面堆栈，同时系统级返回键可回到 tabBar 而不是直接退出小程序）
 */
export const onTabBarPageLoad = () => {
    const runtime = useRuntime()
    const params = JSON.parse(JSON.stringify(runtime.switchTabParams))
    runtime.setSwitchTabParams()
    if (params.navUrl) {
        navigate(params.navType ? params.navType : 'navigateTo', {
            url: params.navUrl,
        })
    }
}

/**
 * 路由跳转
 * @param type 跳转方法
 * @param params 跳转方法参数
 */
export const navigate = (type: NavigateType = 'navigateTo', params: anyObj) => {
    // 以下写法虽然简洁，但是编译后的 H5 会报 is not a function
    // ;(uni[type])(params)

    // 改用 switch
    switch (type) {
        case 'switchTab':
            uni.switchTab(params as UniApp.SwitchTabOptions)
            break
        case 'reLaunch':
            uni.reLaunch(params as UniApp.ReLaunchOptions)
            break
        case 'redirectTo':
            uni.redirectTo(params as UniApp.RedirectToOptions)
            break
        case 'navigateBack':
            uni.navigateBack(params)
            break
        case 'navigateTo':
            uni.navigateTo(params as UniApp.NavigateToOptions)
            break
    }
}

/**
 * 获取窗口宽度
 */
export const getWindowWidth = () => {
    // #ifdef MP-WEIXIN
    return uni.getWindowInfo().windowWidth
    // #endif

    // #ifndef MP-WEIXIN
    return uni.getSystemInfoSync().windowWidth
    // #endif
}

/**
 * 获取窗口高度
 */
export const getWindowHeight = () => {
    // #ifdef MP-WEIXIN
    return uni.getWindowInfo().windowHeight
    // #endif

    // #ifndef MP-WEIXIN
    return uni.getSystemInfoSync().windowHeight
    // #endif
}

/**
 * 获取一致的 100vh（WEB 端的状态栏使用 div 模拟，因此使用 getWindowHeight）
 */
export const get100vh = () => {
    // #ifdef WEB
    return `${getWindowHeight()}px`
    // #endif

    // #ifndef WEB
    return '100vh'
    // #endif
}

/**
 * 获取状态栏高度
 */
export const getStatusBarHeight = () => {
    // #ifdef MP-WEIXIN
    return uni.getWindowInfo().statusBarHeight
    // #endif

    // #ifndef MP-WEIXIN
    return uni.getSystemInfoSync().statusBarHeight
    // #endif
}

/**
 * 格式化时间戳
 * @param dateTime 时间戳
 * @param fmt 格式化方式，默认：yyyy-mm-dd hh:MM:ss
 */
export const timeFormat = (dateTime: string | number | null = null, fmt = 'yyyy-mm-dd hh:MM:ss') => {
    if (dateTime == 'none') return '-'
    if (!dateTime) dateTime = Number(new Date())
    if (dateTime.toString().length === 10) {
        dateTime = +dateTime * 1000
    }

    const date = new Date(dateTime)
    let ret
    const opt: anyObj = {
        'y+': date.getFullYear().toString(), // 年
        'm+': (date.getMonth() + 1).toString(), // 月
        'd+': date.getDate().toString(), // 日
        'h+': date.getHours().toString(), // 时
        'M+': date.getMinutes().toString(), // 分
        's+': date.getSeconds().toString(), // 秒
    }
    for (const k in opt) {
        ret = new RegExp('(' + k + ')').exec(fmt)
        if (ret) {
            fmt = fmt.replace(ret[1], ret[1].length == 1 ? opt[k] : padStart(opt[k], ret[1].length, '0'))
        }
    }
    return fmt
}

/**
 * 获取协议头
 * 服务端资源 URL 不带协议头，正常情况下可自动取值当前协议头，但 uniapp 的 image 组件将固定取值为 https
 */
const getProtocol = () => {
    // #ifdef WEB
    return window.location.protocol
    // #endif

    const protocolMatch = getBaseUrl().match(/^(https?:)\/\//)
    return protocolMatch ? protocolMatch![1] : 'http:'
}

/**
 * 获取 tabbar 页面路径列表
 */
export const getTabbarPages = () => {
    return ['/pages/index/index', '/pages/news/news', '/pages/product/product', '/pages/user/user']
}

/**
 * 获取图片字符串或图片数组中的第一张
 */
export const getFirstImage = (images: string | string[]) => {
    let url = ''
    if (typeof images == 'string') {
        url = images.includes(',') ? images.split(',')[0] : images
    } else if (Array.isArray(images) && images.length > 0) {
        url = images[0]
    }
    return url ? fullUrl(url) : noPic
}

/**
 * 是否是微信内置浏览器
 */
export const isWeixinBrowser = () => {
    // #ifndef WEB
    return false
    // #endif

    const userAgent = navigator.userAgent
    if (!userAgent) return false

    const ua = userAgent.toLowerCase()
    return /micromessenger/.test(ua)
}

export const refresh = () => {
    const pages = getCurrentPages()
    const lastPage: any = pages[pages.length - 1]
    uni.redirectTo({
        url: lastPage.$page.fullPath,
    })
}

/**
 * 字符串补位
 */
const padStart = (str: string, maxLength: number, fillString = ' ') => {
    if (str.length >= maxLength) return str

    const fillLength = maxLength - str.length
    let times = Math.ceil(fillLength / fillString.length)
    while ((times >>= 1)) {
        fillString += fillString
        if (times === 1) {
            fillString += fillString
        }
    }
    return fillString.slice(0, fillLength) + str
}
