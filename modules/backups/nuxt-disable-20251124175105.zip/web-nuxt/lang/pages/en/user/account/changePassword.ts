export default {
    'Change Password': 'Change Password',
    'Old password': 'Old password',
    'New password': 'New password',
    'Confirm new password': 'Confirm new password',
    'Please enter your current password': 'Please enter your current password',
    'The duplicate password does not match the new password': 'The duplicate password does not match the new password',
}
