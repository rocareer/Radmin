export default {
    title: 'Welcome BuildAdmin-WebNuxt！',
}
