export default {
    'Change Password': '修改密码',
    'Old password': '旧密码',
    'New password': '新密码',
    'Confirm new password': '确认新密码',
    'Please enter your current password': '请输入现在的密码',
    'The duplicate password does not match the new password': '重复密码与新密码不相符',
}
