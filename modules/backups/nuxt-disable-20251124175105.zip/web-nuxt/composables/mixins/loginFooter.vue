<template>
    <div class="login-footer-buried-point"></div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss"></style>
