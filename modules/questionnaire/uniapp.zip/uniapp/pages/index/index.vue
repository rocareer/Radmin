<template>
	<view>
		<block v-if="status==1">
			<view class="top">
				<view class="title">
					<h5>{{row.title}}</h5>
				</view>
				<view class="desc">{{row.description}}</view>
			</view>
			<view class="question">
				<view v-for="(item, index) in questions" :key="index">
					<view class="title">
						<text v-if="item.must == 1" class="must">*</text>
						<text>{{ index + 1 }}.</text>
						<p>【{{ item.type_str }}】{{ item.title }}</p>
					</view>

					<view class="options">
						<!-- 单选题 -->
						<block v-if="item.type == 0">
							<u-radio-group v-model="item.checked" placement="column" size="42">
								<u-radio :customStyle="{marginBottom: '10px'}" v-for="(ite, inde) in item.options"
									:key="inde" :label="ite.name" :name="ite.name" labelSize="30" iconSize="30">
								</u-radio>
							</u-radio-group>
						</block>
						<!-- 多选题 -->
						<block v-if="item.type == 1">
							<u-checkbox-group v-model="item.checked" placement="column" size="38">
								<u-checkbox :customStyle="{marginBottom: '8px'}" v-for="(ite, inde) in item.options"
									:key="inde" :label="ite.name" :name="ite.name" labelSize="30" iconSize="30">
								</u-checkbox>
							</u-checkbox-group>
						</block>
						<!-- 填空题 -->
						<block v-if="item.type == 2">
							<u-input placeholder="请输入" class="input" v-model="item.checked" maxlength="200"></u-input>
						</block>
						<!-- 简答题 -->
						<block v-if="item.type == 3">
							<u-textarea v-model="item.checked" class="textarea" height="120" count maxlength="200"
								placeholder="请输入"></u-textarea>
						</block>
						<!-- 下拉框 -->
						<block v-if="item.type == 4">
							<view class="u-demo-block__content">
								<u-input placeholder="请选择" v-model="item.checked" readonly>
									<template slot="suffix">
										<view class="picker" @click="showPickerFu(index,item.subscript,item.options)">
											<view style="flex: 1;"></view>
											<view>
												<u-icon name="arrow-down"></u-icon>
											</view>
										</view>
									</template>
								</u-input>
							</view>
						</block>
						<!-- 图片 -->
						<block v-if="item.type == 5">
							<u-upload @delete="deleteFile" :name="String(index)" multiple width="120" height="120"
								:fileList="item.checked" :maxCount="item.file_num" accept="image" @afterRead="afterRead"
								uploadIcon="photo">
							</u-upload>
						</block>
						<!-- 视频 -->
						<block v-if="item.type == 6">
							<u-upload @afterRead="afterRead" @delete="deleteFile" multiple :name="String(index)"
								width="120" height="120" :fileList="item.checked" :maxCount="item.file_num"
								accept="video" uploadIcon="play-circle">
							</u-upload>
						</block>
						<!-- 文件 -->
						<block v-if="item.type == 7">
							<u-upload @afterRead="afterRead" @delete="deleteFile" multiple :name="String(index)"
								width="120" height="120" :fileList="item.checked" :maxCount="item.file_num"
								accept="file" uploadIcon="file-text">
							</u-upload>
						</block>
					</view>
				</view>
			</view>

			<!-- 下拉框 -->
			<u-picker ref="uPicker" :show="showPicker" :columns="pickerOptions" keyName="name" itemHeight="60"
				:defaultIndex="defaultIndex" @confirm="confirmFu" @cancel="cancelFu" :closeOnClickOverlay="true"
				@close="cancelFu"></u-picker>

			<view class="bottom">
				<u-button type="primary" shape="circle" @click="submit()">
					<text class="text">提交</text>
				</u-button>
			</view>
		</block>

		<view class="tu">
			<block v-if="status==0">
				<u-empty mode="data" icon="/static/status0.png" :text="msg" :textSize="30" :width="500" :height="500" />
			</block>
			<block v-if="status==2">
				<u-empty mode="data" icon="/static/status2.png" :text="msg" :textSize="30" :width="500" :height="500" />
			</block>
			<block v-if="status==3">
				<u-empty mode="data" icon="/static/status3.png" :text="msg" :textSize="30" :width="500" :height="500" />
			</block>
			<block v-if="status==4">
				<u-empty mode="data" icon="/static/status4.png" :text="msg" :textSize="30" :width="500" :height="500" />
			</block>
		</view>
		<u-toast ref="uToast"></u-toast>
	</view>

</template>

<script>
	import {
		getExaminationApi,
		submitAnswerApi
	} from '@/config/api'
	import {
		basrUrl
	} from '@/config/base';
	export default {
		data() {
			return {
				id: '',
				status: 0,
				row: [],
				questions: [],
				msg: '',
				user: '',
				platform: 0,
				showPicker: false,
				pickerOptions: [],
				defaultIndex: [0],
				fileList: [],
			}
		},
		onLoad(options) {
			this.getEnv()
			let id = options.id ? options.id : '1';
			if (id) {
				this.id = id;
				this.getData();
			}
		},
		methods: {
			//环境区分
			getEnv() {
				var platform = 0; //默认H5网页
				// #ifdef MP-WEIXIN
				platform = 2; // 微信小程序
				// #endif

				// #ifdef H5
				const ua = navigator.userAgent.toLowerCase();
				if (/micromessenger/i.test(ua)) {
					platform = 1; // 微信公众号
				}
				// #endif

				var user = uni.getStorageSync('questionnaireUser');
				if (!user) {
					user = uni.$u.guid();
					uni.setStorageSync('questionnaireUser', user);
				}

				this.user = user;
				this.platform = platform;
			},

			//删除
			deleteFile(event) {
				this.questions[event.name]['checked'].splice(event.index, 1);
			},
			//上传
			async afterRead(event) {

				const file = event.file;
				const index = event.name;

				const item = this.questions[index];
				const allowTypes = item.file_suffix || [];
				const maxSize = item.file_size || 5;

				const suffix_string = allowTypes.join(',');

				const lists = [].concat(file);

				for (let f of lists) {

					// #ifdef H5
					const suffix_judge = f.name;
					// #endif

					// #ifdef MP-WEIXIN
					const suffix_judge = f.url;
					// #endif

					const ext = suffix_judge.slice(suffix_judge.lastIndexOf('.') + 1).toLowerCase();

					if (allowTypes.includes(ext) == false) {
						this.$refs.uToast.show({
							message: `不支持 ${ext} 格式，仅支持：${suffix_string}`,
							duration: 2500
						});
						return false;
					}

					const fileSizeInMB = f.size / 1024 / 1024;
					if (fileSizeInMB > maxSize) {
						this.$refs.uToast.show({
							message: `超出大小限制（最大 ${maxSize}M）`,
							duration: 2500
						});
						return false;
					}
				}

				const checked = item['checked'];
				const startIndex = checked.length; // 记录起始索引

				// 先全部添加到列表，标记为上传中
				lists.forEach(file => {
					checked.push({
						...file,
						status: "uploading",
						message: "上传中",
					});
				});

				// 逐个上传，更新对应索引的项
				for (let i = 0; i < lists.length; i++) {
					const file = lists[i];
					const result = await this.uploadFilePromise(file.url, suffix_string, maxSize);
					const updateIndex = startIndex + i;
					if (result.code == 1) {

						this.$set(checked, updateIndex, {
							...checked[updateIndex],
							status: 'success',
							message: '',
							url: result.data.url,
						});
					} else {
						checked.splice(index, 1);
						this.$refs.uToast.show({
							message: result.msg || '上传失败',
							duration: 3000
						});
					}
				}
			},
			uploadFilePromise(url, suffix, size) {
				return new Promise((resolve) => {
					uni.uploadFile({
						url: basrUrl + "/api/questionnaire.AnswerSheet/upFile?server=1",
						filePath: url,
						name: "file",
						formData: {
							size: size,
							suffix: suffix
						},
						success: (res) => {
							let data;
							try {
								data = JSON.parse(res.data);
							} catch (err) {
								return resolve({
									code: 0,
									msg: '服务器返回格式错误',
									data: null
								});
							}
							resolve(data);
						},
						fail: (err) => {

							resolve({
								code: 0,
								msg: '网络错误或上传失败，请检查网络',
								data: null
							});
						}
					});
				});
			},
			//拉框的选择
			confirmFu(e) {
				let i = e.indexs[0];
				let v = e.value[0]['name'];
				this.row.questions[this.i]['checked'] = v;
				this.row.questions[this.i]['subscript'] = i;
				this.showPicker = false;
				this.pickerOptions = [];
				this.i = 0;
			},
			//关闭下拉框
			cancelFu() {
				this.showPicker = false;
				this.pickerOptions = [];
				this.i = 0;
			},
			//展示下拉框
			showPickerFu(i, subscript, options) {
				this.i = i;
				this.defaultIndex = [subscript];
				this.pickerOptions.push(options);
				this.showPicker = true;
			},
			//获取数据
			getData() {
				getExaminationApi({
					id: this.id,
					user: this.user
				}, {
					custom: {
						toast: false,
						loading: true
					}
				}).then((res) => {
					if (res.status == 1) {
						this.row = res.row;
						this.questions = res.row.questions;
					}
					this.msg = res.msg;
					this.status = res.status;

				}).catch((err) => {
					console.log(err)
				})
			},
			//提交
			submit() {

				let check = this.checkData();
				if (check == false) {
					this.$refs.uToast.show({
						message: '请完善必答题'
					});
					return false;
				}
				this.row.user = this.user;
				this.row.platform = this.platform;
				submitAnswerApi(this.row, {
					custom: {
						toast: true,
						loading: true
					}
				}).then((res) => {
					this.status = 2;
					this.msg = '已提交'

				}).catch(() => {

				})
			},
			//验证必填
			checkData() {
				let check = true;
				let questions = this.row.questions;
				for (let i = 0; i < questions.length; i++) {
					if (questions[i]['must'] == 1) {
						if (questions[i]['type'] == 1) {
							if (questions[i]['checked'].length == 0) {
								check = false;
								break;
							}
						} else {
							if (questions[i]['checked'] == '') {
								check = false;
								break;
							}
						}
					}
				}
				return check;
			}
		}
	}
</script>

<style lang="scss">
	.top {
		margin-top: 10rpx;
		text-align: center;

		.title {
			font-size: 50rpx;
			padding: 0rpx 20rpx;
		}

		.desc {
			font-size: 28rpx;
			color: #909399;
			padding: 6rpx 100rpx 10rpx 100rpx;
		}
	}

	.question {
		margin: 20rpx 30rpx;

		.title {
			margin-top: 20rpx;
			margin-bottom: 20rpx;
			display: flex;
			line-height: 48rpx;
			align-items: baseline;

			.must {
				color: red;
			}
		}

		.options {
			margin-left: 40rpx;

			.textarea {
				margin-bottom: 20rpx;
			}

			.input {
				margin-bottom: 20rpx;
			}

			.picker {
				display: flex;
				justify-content: space-between;
				width: 300rpx;
			}

			::v-deep .u-icon__icon {
				font-size: 46rpx !important;
			}

		}
	}

	.bottom {
		position: fixed;
		bottom: 20rpx;
		left: 24rpx;
		right: 24rpx;

		.text {
			font-size: 40rpx;
		}
	}

	.tu {
		padding-top: 150rpx;
	}
</style>