import {
	basrUrl
} from '@/config/base';
// 此vm参数为页面的实例，可以通过它引用vuex中的变量
module.exports = (vm) => {
	// 初始化请求配置
	uni.$u.http.setConfig((config) => {
		/* config 为默认全局配置*/
		config.baseURL = basrUrl; /* 根域名 */
		return config;
	})

	// 请求拦截
	uni.$u.http.interceptors.request.use((config) => { // 可使用async await 做异步操作
		// 初始化请求拦截器时，会执行此方法，此时data为undefined，赋予默认{}
		config.data = config.data || {}
		// 根据custom参数中配置的是否需要token，添加对应的请求头
		if (config.custom.loading) {
			uni.showLoading({
				title: '加载中',
				mask: true
			});
		}
		config.header.server = 1;

		return config
	}, config => { // 可使用async await 做异步操作
		return Promise.reject(config)
	})

	// 响应拦截
	uni.$u.http.interceptors.response.use(
		// 响应成功 (statusCode === 200)
		(response) => {
			uni.hideLoading();

			const data = response.data;
			const code = data.code;
			const custom = response.config?.custom;

			if (code !== 1) {
				if (code == 3 || code == 0) {
					uni.$u.toast(data.msg);
				}

				if (custom?.catch) {
					return Promise.reject(data);
				} else {
					return new Promise(() => {});
				}
			}

			// 成功提示
			if (custom.toast !== false && code === 1) {
				uni.$u.toast(data.msg ? data.msg : '操作成功');
			}

			return data.data === undefined ? {} : data.data;
		},
		// 响应失败 (statusCode !== 200)
		(error) => {
			uni.hideLoading();
			uni.$u.toast('服务端异常');
			return Promise.reject(error);
		}
	);
}