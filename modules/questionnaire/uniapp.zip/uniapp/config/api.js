const http = uni.$u.http

//获取问卷
export const getExaminationApi = (params, config = {}) => http.post('/api/questionnaire.Examination/getExamination',
	params, config);
//提交答案
export const submitAnswerApi = (params, config = {}) => http.post('/api/questionnaire.AnswerSheet/submitAnswer',
	params, config);